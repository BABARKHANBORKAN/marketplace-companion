import { config } from '../config/env';

/**
 * Minimal PostgREST client for the one thing we need from Supabase: atomically redeeming an
 * "Apps Code". No SDK dependency — this is two REST calls, and the codebase already avoids
 * pulling in client libraries for things `fetch` handles directly (see: every other repository
 * here uses raw SQL over an ORM).
 *
 * Calls the bare global `fetch` identifier at call time (not captured at module load), so tests
 * can stub it via `global.fetch = ...` instead of hitting a real Supabase project whose
 * schema/data we don't control from here and shouldn't mutate in CI.
 */
export class SupabaseCodeClient {
  private get baseUrl(): string {
    return config.supabaseUrl.replace(/\/+$/, '');
  }

  private get headers(): Record<string, string> {
    return {
      apikey: config.supabaseAnonKey,
      Authorization: `Bearer ${config.supabaseAnonKey}`,
      'Content-Type': 'application/json',
    };
  }

  /**
   * Redeems a code. When an "active" column is configured (SUPABASE_CODES_ACTIVE_COLUMN is
   * non-empty), this atomically flips it from active to inactive in a single PATCH whose filter
   * requires it to still be active — a compare-and-swap, not a check-then-write, so two
   * simultaneous requests for the same code can never both succeed. Returns true only if a row
   * was actually flipped just now.
   *
   * When no active column is configured (the table has no consumed/used flag — just a list of
   * valid codes), this instead does a plain existence check (SELECT) and never mutates the row:
   * codes stay valid for repeated use, since there's no column to track consumption against.
   *
   * The code match is case-insensitive (PostgREST `ilike` with no wildcards behaves as an exact
   * match ignoring case): codes aren't forced to any particular case client- or server-side, so
   * this is what actually makes matching reliable regardless of how the code was originally
   * generated/stored. The table name is URL-encoded since it may contain spaces or other
   * characters that aren't valid unescaped in a URL path segment.
   */
  async redeemCode(rawCode: string): Promise<boolean> {
    if (!config.supabaseUrl || !config.supabaseAnonKey) {
      throw new Error('Supabase is not configured (SUPABASE_URL / SUPABASE_ANON_KEY missing)');
    }

    const codeCol = config.supabaseCodesCodeColumn;
    const activeCol = config.supabaseCodesActiveColumn;
    const table = encodeURIComponent(config.supabaseCodesTable);
    const codeFilter = `${codeCol}=ilike.${encodeURIComponent(rawCode)}`;

    if (!activeCol) {
      const url = `${this.baseUrl}/rest/v1/${table}?select=${codeCol}&${codeFilter}&limit=1`;
      const response = await fetch(url, { headers: this.headers });
      if (!response.ok) {
        throw new Error(`Supabase lookup request failed: ${response.status} ${response.statusText}`);
      }
      const rows = (await response.json()) as unknown[];
      return Array.isArray(rows) && rows.length > 0;
    }

    const url = `${this.baseUrl}/rest/v1/${table}?${codeFilter}&${activeCol}=eq.true`;

    const response = await fetch(url, {
      method: 'PATCH',
      headers: {
        ...this.headers,
        Prefer: 'return=representation',
      },
      body: JSON.stringify({ [activeCol]: false }),
    });

    if (!response.ok) {
      // Any Supabase-side error (bad schema, network issue reported as non-2xx, etc.) is treated
      // as "could not redeem" rather than crashing the login flow — surfaced to the caller as a
      // plain failed redemption; the caller logs the detail.
      throw new Error(`Supabase redeem request failed: ${response.status} ${response.statusText}`);
    }

    const rows = (await response.json()) as unknown[];
    return Array.isArray(rows) && rows.length > 0;
  }
}

export const supabaseCodeClient = new SupabaseCodeClient();
