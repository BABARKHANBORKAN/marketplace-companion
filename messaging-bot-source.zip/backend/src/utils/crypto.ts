import crypto from 'node:crypto';
import { config } from '../config/env';

/**
 * Hash password securely using Node.js scrypt
 */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

/**
 * Verify password against stored scrypt hash
 */
export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const [salt, key] = storedHash.split(':');
    if (!salt || !key) return false;
    const keyBuffer = Buffer.from(key, 'hex');
    const derivedKey = crypto.scryptSync(password, salt, keyBuffer.length);
    return crypto.timingSafeEqual(keyBuffer, derivedKey);
  } catch {
    return false;
  }
}

/**
 * Generate a high-entropy Bot API Key
 * Returns the raw key (shown only once) and prefix/last4 for storage
 */
export function generateBotApiKey(): {
  rawKey: string;
  keyPrefix: string;
  keyLastFour: string;
  keyHash: string;
  maskedKey: string;
} {
  const prefix = 'mpc_live_';
  // 32 bytes of secure random bytes => 64 hex chars
  const randomHex = crypto.randomBytes(32).toString('hex');
  const rawKey = `${prefix}${randomHex}`;
  const keyLastFour = rawKey.slice(-4);
  const keyHash = hashBotApiKey(rawKey);
  const maskedKey = `${prefix}${'•'.repeat(16)}${keyLastFour}`;

  return {
    rawKey,
    keyPrefix: prefix,
    keyLastFour,
    keyHash,
    maskedKey,
  };
}

/**
 * Hash Bot API Key with pepper to prevent preimage attacks
 */
export function hashBotApiKey(rawKey: string): string {
  return crypto
    .createHmac('sha256', config.botKeyPepper)
    .update(rawKey)
    .digest('hex');
}

/**
 * Generate secure random token (e.g. for refresh tokens)
 */
export function generateSecureToken(length = 48): string {
  return crypto.randomBytes(length).toString('base64url');
}

/**
 * Hash a refresh token before storing in the database
 */
export function hashRefreshToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/**
 * Encode / decode opaque cursor for delta-sync
 */
export function encodeCursor(sequence: number): string {
  const payload = JSON.stringify({ seq: sequence, ts: Date.now() });
  return Buffer.from(payload, 'utf-8').toString('base64url');
}

export function decodeCursor(cursor: string): number {
  try {
    const raw = Buffer.from(cursor, 'base64url').toString('utf-8');
    const parsed = JSON.parse(raw);
    return typeof parsed.seq === 'number' ? parsed.seq : 0;
  } catch {
    return 0;
  }
}
