import jwt from 'jsonwebtoken';
import { config } from '../config/env';

export interface JwtUserPayload {
  userId: string;
  email: string;
  name: string;
}

export function generateAccessToken(payload: JwtUserPayload): { token: string; expiresInSeconds: number } {
  const expiresInSeconds = 7200; // 2 hours
  const token = jwt.sign(payload, config.jwtSecret, {
    expiresIn: '2h',
    algorithm: 'HS256',
  });
  return { token, expiresInSeconds };
}

export function verifyAccessToken(token: string): JwtUserPayload | null {
  try {
    const decoded = jwt.verify(token, config.jwtSecret, {
      algorithms: ['HS256'],
    }) as JwtUserPayload;
    return decoded;
  } catch {
    return null;
  }
}
