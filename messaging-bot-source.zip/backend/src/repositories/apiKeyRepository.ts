import { getDatabase } from '../db/database';
import { BotApiKey } from '../types';

export class ApiKeyRepository {
  createKey(key: {
    id: string;
    botId: string;
    userId: string;
    profileId: string;
    keyHash: string;
    keyPrefix: string;
    keyLastFour: string;
    serverUrl: string;
  }): BotApiKey {
    const db = getDatabase();
    const now = Date.now();

    db.prepare(`
      INSERT INTO bot_api_keys (
        id, bot_id, user_id, profile_id, key_hash, key_prefix, key_last_four, server_url, status, last_used_at, revoked_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', NULL, NULL, ?)
    `).run(
      key.id,
      key.botId,
      key.userId,
      key.profileId,
      key.keyHash,
      key.keyPrefix,
      key.keyLastFour,
      key.serverUrl,
      now
    );

    return {
      id: key.id,
      bot_id: key.botId,
      user_id: key.userId,
      profile_id: key.profileId,
      key_hash: key.keyHash,
      key_prefix: key.keyPrefix,
      key_last_four: key.keyLastFour,
      server_url: key.serverUrl,
      status: 'ACTIVE',
      last_used_at: null,
      revoked_at: null,
      created_at: now,
    };
  }

  findByUserId(userId: string): BotApiKey[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM bot_api_keys 
      WHERE user_id = ? 
      ORDER BY created_at DESC
    `).all(userId) as unknown as BotApiKey[];
  }

  findById(id: string, userId: string): BotApiKey | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM bot_api_keys WHERE id = ? AND user_id = ?').get(id, userId) as BotApiKey | undefined;
    return row || null;
  }

  findByBotId(botId: string, userId: string): BotApiKey[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM bot_api_keys
      WHERE bot_id = ? AND user_id = ?
      ORDER BY created_at DESC
    `).all(botId, userId) as unknown as BotApiKey[];
  }

  findByProfileId(profileId: string, userId: string): BotApiKey[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM bot_api_keys
      WHERE profile_id = ? AND user_id = ?
      ORDER BY created_at DESC
    `).all(profileId, userId) as unknown as BotApiKey[];
  }

  revokeKey(id: string, userId: string): boolean {
    const db = getDatabase();
    const result = db.prepare(`
      UPDATE bot_api_keys 
      SET status = 'REVOKED', revoked_at = ? 
      WHERE id = ? AND user_id = ?
    `).run(Date.now(), id, userId);
    return Number(result.changes) > 0;
  }

  deleteKey(id: string, userId: string): boolean {
    const db = getDatabase();
    const result = db.prepare('DELETE FROM bot_api_keys WHERE id = ? AND user_id = ?').run(id, userId);
    return Number(result.changes) > 0;
  }
}

export const apiKeyRepository = new ApiKeyRepository();
