import { getDatabase } from '../db/database';
import { User } from '../types';

export class UserRepository {
  create(user: { id: string; email: string; passwordHash: string; name: string; plan?: string }): User {
    const db = getDatabase();
    const now = Date.now();
    const plan = user.plan || 'Pro';
    const status = 'ACTIVE';

    db.prepare(`
      INSERT INTO users (id, email, password_hash, name, plan, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(user.id, user.email.toLowerCase().trim(), user.passwordHash, user.name.trim(), plan, status, now, now);

    return {
      id: user.id,
      email: user.email.toLowerCase().trim(),
      password_hash: user.passwordHash,
      name: user.name.trim(),
      plan,
      status,
      created_at: now,
      updated_at: now,
    };
  }

  findByEmail(email: string): User | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim()) as User | undefined;
    return row || null;
  }

  findById(id: string): User | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as User | undefined;
    return row || null;
  }
}

export const userRepository = new UserRepository();
