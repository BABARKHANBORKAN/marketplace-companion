import { getDatabase } from '../db/database';
import { Listing } from '../types';

export class ListingRepository {
  createListing(listing: {
    id: string;
    userId: string;
    profileId: string;
    externalListingId?: string | null;
    title: string;
    price: number;
    currency?: string;
    category?: string;
    description?: string;
    location?: string;
    imageUrl?: string;
  }): Listing {
    const db = getDatabase();
    const now = Date.now();
    const currency = listing.currency || 'USD';
    const category = listing.category || 'Electronics';
    const description = listing.description || '';
    const location = listing.location || 'Local Area';
    const imageUrl = listing.imageUrl || '';

    db.prepare(`
      INSERT INTO listings (
        id, user_id, profile_id, external_listing_id, title, price, currency, status,
        category, description, location, conversation_count, message_count, image_url,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?, 0, 0, ?, ?, ?)
    `).run(
      listing.id,
      listing.userId,
      listing.profileId,
      listing.externalListingId || null,
      listing.title.trim(),
      listing.price,
      currency,
      category,
      description,
      location,
      imageUrl,
      now,
      now
    );

    return {
      id: listing.id,
      user_id: listing.userId,
      profile_id: listing.profileId,
      external_listing_id: listing.externalListingId || null,
      title: listing.title.trim(),
      price: listing.price,
      currency,
      status: 'ACTIVE',
      category,
      description,
      location,
      conversation_count: 0,
      message_count: 0,
      image_url: imageUrl,
      created_at: now,
      updated_at: now,
    };
  }

  findByUserId(userId: string): Listing[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM listings 
      WHERE user_id = ? 
      ORDER BY created_at DESC
    `).all(userId) as unknown as Listing[];
  }

  findById(id: string, userId: string): Listing | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM listings WHERE id = ? AND user_id = ?').get(id, userId) as Listing | undefined;
    return row || null;
  }

  deleteListing(id: string, userId: string): boolean {
    const db = getDatabase();
    const result = db.prepare('DELETE FROM listings WHERE id = ? AND user_id = ?').run(id, userId);
    return Number(result.changes) > 0;
  }

  incrementCounts(id: string, userId: string, convInc = 0, msgInc = 0): void {
    const db = getDatabase();
    db.prepare(`
      UPDATE listings 
      SET conversation_count = conversation_count + ?, 
          message_count = message_count + ?,
          updated_at = ?
      WHERE id = ? AND user_id = ?
    `).run(convInc, msgInc, Date.now(), id, userId);
  }
}

export const listingRepository = new ListingRepository();
