import { getDatabase } from '../db/database';
import { Message, MessageDto } from '../types';

export class MessageRepository {
  createMessage(msg: {
    id: string;
    userId: string;
    conversationId: string;
    clientMessageId?: string | null;
    externalMessageId?: string | null;
    commandId?: string | null;
    idempotencyKey?: string | null;
    sender: 'CUSTOMER' | 'USER_APP' | 'BOT_AUTO';
    text: string;
    status?: 'PENDING' | 'PROCESSING' | 'SENT' | 'FAILED' | 'CANCELLED';
    timestamp?: number;
  }): Message {
    const db = getDatabase();
    const now = Date.now();
    const status = msg.status || 'SENT';
    const timestamp = msg.timestamp || now;

    db.prepare(`
      INSERT INTO messages (
        id, user_id, conversation_id, client_message_id, external_message_id,
        command_id, idempotency_key, sender, text, status, timestamp, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      msg.id,
      msg.userId,
      msg.conversationId,
      msg.clientMessageId || null,
      msg.externalMessageId || null,
      msg.commandId || null,
      msg.idempotencyKey || null,
      msg.sender,
      msg.text,
      status,
      timestamp,
      now,
      now
    );

    return {
      id: msg.id,
      user_id: msg.userId,
      conversation_id: msg.conversationId,
      client_message_id: msg.clientMessageId || null,
      external_message_id: msg.externalMessageId || null,
      command_id: msg.commandId || null,
      idempotency_key: msg.idempotencyKey || null,
      sender: msg.sender,
      text: msg.text,
      status,
      timestamp,
      created_at: now,
      updated_at: now,
    };
  }

  findById(id: string, userId: string): Message | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM messages WHERE id = ? AND user_id = ?').get(id, userId) as Message | undefined;
    return row || null;
  }

  findByIdempotencyKey(userId: string, idempotencyKey: string): Message | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM messages WHERE user_id = ? AND idempotency_key = ?').get(userId, idempotencyKey) as Message | undefined;
    return row || null;
  }

  /**
   * Durable idempotency key for BOT-REPORTED (customer) messages. A Desktop Bot that reconnects
   * and re-scrapes/re-reports the same Marketplace message must not create a duplicate — the
   * bot supplies the platform's own message id as externalMessageId, and this lookup is what
   * lets the caller detect "already have this one" before inserting.
   */
  findByExternalMessageId(userId: string, externalMessageId: string): Message | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM messages WHERE user_id = ? AND external_message_id = ?').get(userId, externalMessageId) as Message | undefined;
    return row || null;
  }

  findByConversationId(conversationId: string, userId: string): MessageDto[] {
    const db = getDatabase();
    const rows = db.prepare(`
      SELECT id, conversation_id, sender, text, status, timestamp, command_id, idempotency_key
      FROM messages 
      WHERE conversation_id = ? AND user_id = ?
      ORDER BY timestamp ASC
    `).all(conversationId, userId) as any[];

    return rows.map(r => ({
      id: r.id,
      conversation_id: r.conversation_id,
      sender: r.sender,
      text: r.text,
      status: r.status,
      timestamp: r.timestamp,
      command_id: r.command_id || null,
      idempotency_key: r.idempotency_key || null,
    }));
  }

  updateStatus(id: string, userId: string, status: 'PENDING' | 'PROCESSING' | 'SENT' | 'FAILED' | 'CANCELLED'): boolean {
    const db = getDatabase();
    const result = db.prepare(`
      UPDATE messages 
      SET status = ?, updated_at = ?
      WHERE id = ? AND user_id = ?
    `).run(status, Date.now(), id, userId);
    return Number(result.changes) > 0;
  }

  updateStatusByCommandId(commandId: string, status: 'PENDING' | 'PROCESSING' | 'SENT' | 'FAILED' | 'CANCELLED'): void {
    const db = getDatabase();
    db.prepare(`
      UPDATE messages 
      SET status = ?, updated_at = ?
      WHERE command_id = ?
    `).run(status, Date.now(), commandId);
  }
}

export const messageRepository = new MessageRepository();
