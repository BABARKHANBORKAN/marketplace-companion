import { getDatabase } from '../db/database';
import { Command, CommandResponse } from '../types';

export class CommandRepository {
  createCommand(cmd: {
    id: string;
    userId: string;
    botId?: string | null;
    profileId: string;
    conversationId?: string;
    customerId?: string;
    listingId?: string;
    messageId?: string;
    commandType: string;
    payload?: string;
    status?: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
    idempotencyKey?: string | null;
  }): Command {
    const db = getDatabase();
    const now = Date.now();
    const status = cmd.status || 'PENDING';
    const payload = cmd.payload || '{}';

    db.prepare(`
      INSERT INTO commands (
        id, user_id, bot_id, profile_id, conversation_id, customer_id, listing_id,
        message_id, command_type, payload, status, idempotency_key, attempts,
        max_retries, error_code, error_message, result_message, completed_at,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 5, NULL, NULL, NULL, NULL, ?, ?)
    `).run(
      cmd.id,
      cmd.userId,
      cmd.botId || null,
      cmd.profileId,
      cmd.conversationId || '',
      cmd.customerId || '',
      cmd.listingId || '',
      cmd.messageId || '',
      cmd.commandType,
      payload,
      status,
      cmd.idempotencyKey || null,
      now,
      now
    );

    return {
      id: cmd.id,
      user_id: cmd.userId,
      bot_id: cmd.botId || null,
      profile_id: cmd.profileId,
      conversation_id: cmd.conversationId || '',
      customer_id: cmd.customerId || '',
      listing_id: cmd.listingId || '',
      message_id: cmd.messageId || '',
      command_type: cmd.commandType,
      payload,
      status,
      idempotency_key: cmd.idempotencyKey || null,
      attempts: 0,
      max_retries: 5,
      error_code: null,
      error_message: null,
      result_message: null,
      completed_at: null,
      dispatched_at: null,
      created_at: now,
      updated_at: now,
    };
  }

  /**
   * Records that a command was actually pushed over a live bot WebSocket connection — as
   * distinct from merely sitting PENDING waiting for the bot to poll GET /commands/pending.
   * Updated on every push (initial dispatch and any later reconnect resume), so it always
   * reflects the most recent delivery attempt.
   */
  markDispatched(id: string): void {
    const db = getDatabase();
    db.prepare('UPDATE commands SET dispatched_at = ? WHERE id = ?').run(Date.now(), id);
  }

  /**
   * Purges every command queued against a profile — used when the profile itself is being
   * deleted, since commands.profile_id has no FK/cascade to chrome_profiles (unlike listings/
   * conversations), so without this they'd linger indefinitely referencing a profile that no
   * longer exists.
   */
  deleteByProfile(profileId: string, userId: string): number {
    const db = getDatabase();
    const result = db.prepare('DELETE FROM commands WHERE profile_id = ? AND user_id = ?').run(profileId, userId);
    return Number(result.changes);
  }

  findById(id: string, userId: string): Command | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM commands WHERE id = ? AND user_id = ?').get(id, userId) as Command | undefined;
    return row || null;
  }

  /**
   * Scoped lookup for the authenticated Bot API Key's context. A key is minted for exactly
   * one (user, profile) pair, so both must match; bot_id is checked only when the command
   * already has one assigned (commands are created with bot_id = NULL and claimed by whichever
   * bot is currently connected for that profile).
   */
  findForBot(id: string, scope: { userId: string; profileId: string; botId: string }): Command | null {
    const db = getDatabase();
    const row = db.prepare(`
      SELECT * FROM commands WHERE id = ? AND user_id = ? AND profile_id = ?
    `).get(id, scope.userId, scope.profileId) as Command | undefined;
    if (!row) return null;
    if (row.bot_id && row.bot_id !== scope.botId) return null;
    return row;
  }

  findByIdempotencyKey(userId: string, idempotencyKey: string): Command | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM commands WHERE user_id = ? AND idempotency_key = ?').get(userId, idempotencyKey) as Command | undefined;
    return row || null;
  }

  /**
   * Pending/in-flight commands visible to a bot polling for work. Scoped by the FULL
   * authenticated context (user_id, profile_id, and bot_id when the command has already been
   * claimed) rather than profile_id alone, so a bot can never see another bot's in-flight work
   * even if a profile_id were somehow guessed or reused.
   */
  findPendingForBot(userId: string, profileId: string, botId: string): Command[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM commands
      WHERE user_id = ? AND profile_id = ? AND status IN ('PENDING', 'PROCESSING')
        AND (bot_id IS NULL OR bot_id = ?)
      ORDER BY created_at ASC
    `).all(userId, profileId, botId) as unknown as Command[];
  }

  findTerminalByUserId(userId: string): Command[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM commands
      WHERE user_id = ? AND status IN ('COMPLETED', 'FAILED', 'CANCELLED')
      ORDER BY updated_at ASC
    `).all(userId) as unknown as Command[];
  }

  /**
   * Strict server-side command state machine (mirrors the Android client's own
   * CommandStateMachine, minus the FAILED -> PENDING manual-retry escape hatch, which is a
   * local-only concept for the app's own outgoing-command queue, not something a Desktop Bot
   * should be able to do to a command it already reported as failed):
   *
   *   PENDING -> PROCESSING -> COMPLETED / FAILED / CANCELLED
   *
   * PROCESSING may also revert to PENDING (a bot voluntarily un-claiming), and a command may be
   * failed/cancelled directly from PENDING (never claimed at all). Every other transition —
   * including the PENDING -> COMPLETED example this table exists to prevent — is rejected.
   */
  private static readonly ALLOWED_SOURCE_STATUSES: Record<string, string[]> = {
    PROCESSING: ['PENDING'],
    COMPLETED: ['PROCESSING'],
    FAILED: ['PENDING', 'PROCESSING'],
    CANCELLED: ['PENDING', 'PROCESSING'],
    PENDING: ['PROCESSING'],
  };

  updateStatus(
    id: string,
    scope: { userId: string; profileId: string; botId: string },
    status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED',
    resultMessage?: string | null,
    completedAt?: number | null,
    errorCode?: string | null,
    errorMessage?: string | null
  ): Command | null {
    const db = getDatabase();
    const now = Date.now();
    const allowedSources = CommandRepository.ALLOWED_SOURCE_STATUSES[status] || [];

    if (allowedSources.length > 0) {
      const sourcePlaceholders = allowedSources.map(() => '?').join(', ');

      // Single atomic compare-and-swap: the row only mutates if it is CURRENTLY in an allowed
      // source state for this transition AND owned by this exact (user, profile) scope AND not
      // already claimed by a different bot. This is what makes PENDING -> PROCESSING claiming
      // race-proof between two bot connections — there is no separate read-then-write window for
      // a second claim to land in. COALESCE preserves the previous value for any field the caller
      // didn't supply, exactly as before.
      const result = db.prepare(`
        UPDATE commands
        SET status = ?,
            bot_id = ?,
            result_message = COALESCE(?, result_message),
            completed_at = ?,
            error_code = COALESCE(?, error_code),
            error_message = COALESCE(?, error_message),
            updated_at = ?
        WHERE id = ? AND user_id = ? AND profile_id = ?
          AND (bot_id IS NULL OR bot_id = ?)
          AND status IN (${sourcePlaceholders})
      `).run(
        status,
        scope.botId,
        resultMessage ?? null,
        completedAt !== undefined ? completedAt : (status === 'COMPLETED' ? now : null),
        errorCode ?? null,
        errorMessage ?? null,
        now,
        id, scope.userId, scope.profileId,
        scope.botId,
        ...allowedSources
      );

      if (Number(result.changes) > 0) {
        return db.prepare('SELECT * FROM commands WHERE id = ?').get(id) as unknown as Command;
      }
    }

    // The atomic update matched nothing — read-only lookup to explain why: not found / wrong
    // scope / wrong bot (all return null, a 404, without leaking which); an idempotent replay of
    // a status the command is already in (returned unchanged, not an error); or a genuinely
    // invalid transition (e.g. PENDING -> COMPLETED directly), which is also rejected.
    const existing = this.findForBot(id, scope);
    if (!existing) return null;
    return existing.status === status ? existing : null;
  }

  /**
   * Recovers commands a bot claimed (PROCESSING) and then never finished — e.g. the bot process
   * died mid-task. Reverts to PENDING (bot_id cleared, so any bot currently connected for that
   * profile can pick it back up) unless the retry budget is exhausted, in which case it's marked
   * FAILED for good. System-initiated, so it bypasses the bot-scoped CAS above entirely.
   */
  recoverStaleProcessingCommands(cutoffTimestamp: number): Command[] {
    const db = getDatabase();
    const now = Date.now();

    const stale = db.prepare(`
      SELECT * FROM commands WHERE status = 'PROCESSING' AND updated_at < ?
    `).all(cutoffTimestamp) as unknown as Command[];

    const recovered: Command[] = [];
    for (const cmd of stale) {
      const exhausted = cmd.attempts + 1 >= cmd.max_retries;
      const newStatus = exhausted ? 'FAILED' : 'PENDING';
      const errCode = exhausted ? 'BOT_TIMEOUT' : cmd.error_code;
      const errMsg = exhausted ? 'Bot did not complete the command before timeout' : cmd.error_message;
      const compAt = exhausted ? now : null;

      const result = db.prepare(`
        UPDATE commands
        SET status = ?,
            bot_id = CASE WHEN ? = 'PENDING' THEN NULL ELSE bot_id END,
            attempts = attempts + 1,
            error_code = ?,
            error_message = ?,
            completed_at = ?,
            updated_at = ?
        WHERE id = ? AND status = 'PROCESSING'
      `).run(newStatus, newStatus, errCode, errMsg, compAt, now, cmd.id);

      if (Number(result.changes) > 0) {
        recovered.push({
          ...cmd,
          status: newStatus,
          bot_id: newStatus === 'PENDING' ? null : cmd.bot_id,
          attempts: cmd.attempts + 1,
          error_code: errCode,
          error_message: errMsg,
          completed_at: compAt,
          updated_at: now,
        });
      }
    }
    return recovered;
  }

  toResponse(cmd: Command): CommandResponse {
    return {
      id: cmd.id,
      idempotency_key: cmd.idempotency_key,
      status: cmd.status,
      result_message: cmd.result_message,
      completed_at: cmd.completed_at,
      error_code: cmd.error_code,
      error_message: cmd.error_message,
    };
  }
}

export const commandRepository = new CommandRepository();
