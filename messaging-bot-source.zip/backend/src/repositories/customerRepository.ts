import { getDatabase } from '../db/database';
import { Customer } from '../types';
import { v4 as uuidv4 } from 'uuid';

export class CustomerRepository {
  findOrCreateCustomer(userId: string, externalCustomerId: string, name: string, avatarUrl = ''): Customer {
    const db = getDatabase();
    const existing = db.prepare(`
      SELECT * FROM customers 
      WHERE user_id = ? AND external_customer_id = ?
    `).get(userId, externalCustomerId) as Customer | undefined;

    if (existing) {
      if (name && existing.name !== name) {
        db.prepare('UPDATE customers SET name = ?, updated_at = ? WHERE id = ?').run(name, Date.now(), existing.id);
        existing.name = name;
      }
      return existing;
    }

    const id = `cust_${uuidv4().substring(0, 8)}`;
    const now = Date.now();
    db.prepare(`
      INSERT INTO customers (id, user_id, external_customer_id, name, avatar_url, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, userId, externalCustomerId, name || 'Customer', avatarUrl, now, now);

    return {
      id,
      user_id: userId,
      external_customer_id: externalCustomerId,
      name: name || 'Customer',
      avatar_url: avatarUrl,
      created_at: now,
      updated_at: now,
    };
  }

  findById(id: string, userId: string): Customer | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM customers WHERE id = ? AND user_id = ?').get(id, userId) as Customer | undefined;
    return row || null;
  }
}

export const customerRepository = new CustomerRepository();
