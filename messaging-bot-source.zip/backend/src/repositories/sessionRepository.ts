import { getDatabase } from '../db/database';
import { RefreshSession } from '../types';

export class SessionRepository {
  createSession(session: {
    id: string;
    userId: string;
    refreshTokenHash: string;
    deviceInfo?: string;
    expiresAt: number;
  }): RefreshSession {
    const db = getDatabase();
    const now = Date.now();

    db.prepare(`
      INSERT INTO refresh_sessions (id, user_id, refresh_token_hash, device_info, expires_at, revoked_at, created_at)
      VALUES (?, ?, ?, ?, ?, NULL, ?)
    `).run(
      session.id,
      session.userId,
      session.refreshTokenHash,
      session.deviceInfo || null,
      session.expiresAt,
      now
    );

    return {
      id: session.id,
      user_id: session.userId,
      refresh_token_hash: session.refreshTokenHash,
      device_info: session.deviceInfo || null,
      expires_at: session.expiresAt,
      revoked_at: null,
      created_at: now,
    };
  }

  findByHash(refreshTokenHash: string): RefreshSession | null {
    const db = getDatabase();
    const row = db.prepare(`
      SELECT * FROM refresh_sessions 
      WHERE refresh_token_hash = ? AND revoked_at IS NULL AND expires_at > ?
    `).get(refreshTokenHash, Date.now()) as RefreshSession | undefined;
    return row || null;
  }

  revokeSession(id: string): void {
    const db = getDatabase();
    db.prepare('UPDATE refresh_sessions SET revoked_at = ? WHERE id = ?').run(Date.now(), id);
  }

  revokeAllForUser(userId: string): void {
    const db = getDatabase();
    db.prepare('UPDATE refresh_sessions SET revoked_at = ? WHERE user_id = ?').run(Date.now(), userId);
  }
}

export const sessionRepository = new SessionRepository();
