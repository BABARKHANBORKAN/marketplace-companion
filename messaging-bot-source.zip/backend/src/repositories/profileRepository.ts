import { getDatabase } from '../db/database';
import { ChromeProfile } from '../types';

export class ProfileRepository {
  createProfile(profile: {
    id: string;
    userId: string;
    botId?: string | null;
    name: string;
    accountLabel: string;
    chromeWindowName?: string;
  }): ChromeProfile {
    const db = getDatabase();
    const now = Date.now();
    const windowName = profile.chromeWindowName || `Google Chrome - ${profile.name}`;

    // A freshly created profile has no bot connected yet — it must start OFFLINE with no
    // heartbeat on record. Only a real heartbeat via botService.recordHeartbeat() (or an
    // active WebSocket registration) should ever flip it to ONLINE / bot_connected = 1.
    db.prepare(`
      INSERT INTO chrome_profiles (
        id, user_id, bot_id, name, account_label, status, current_task,
        last_seen, last_heartbeat, listing_count, conversation_count, unread_count,
        chrome_window_name, bot_connected, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 'OFFLINE', 'Idle', ?, 0, 0, 0, 0, ?, 0, ?, ?)
    `).run(
      profile.id,
      profile.userId,
      profile.botId || null,
      profile.name.trim(),
      profile.accountLabel.trim(),
      now,
      windowName,
      now,
      now
    );

    return {
      id: profile.id,
      user_id: profile.userId,
      bot_id: profile.botId || null,
      name: profile.name.trim(),
      account_label: profile.accountLabel.trim(),
      status: 'OFFLINE',
      current_task: 'Idle',
      last_seen: now,
      last_heartbeat: 0,
      listing_count: 0,
      conversation_count: 0,
      unread_count: 0,
      chrome_window_name: windowName,
      bot_connected: 0,
      created_at: now,
      updated_at: now,
    };
  }

  findByUserId(userId: string): ChromeProfile[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM chrome_profiles 
      WHERE user_id = ? 
      ORDER BY created_at ASC
    `).all(userId) as unknown as ChromeProfile[];
  }

  findById(id: string, userId: string): ChromeProfile | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM chrome_profiles WHERE id = ? AND user_id = ?').get(id, userId) as ChromeProfile | undefined;
    return row || null;
  }

  updateProfile(id: string, userId: string, fields: Partial<ChromeProfile>): ChromeProfile | null {
    const db = getDatabase();
    const existing = this.findById(id, userId);
    if (!existing) return null;

    const updated = { ...existing, ...fields, updated_at: Date.now() };

    db.prepare(`
      UPDATE chrome_profiles 
      SET bot_id = ?, name = ?, account_label = ?, status = ?, current_task = ?,
          last_seen = ?, last_heartbeat = ?, listing_count = ?, conversation_count = ?, unread_count = ?,
          chrome_window_name = ?, bot_connected = ?, updated_at = ?
      WHERE id = ? AND user_id = ?
    `).run(
      updated.bot_id,
      updated.name,
      updated.account_label,
      updated.status,
      updated.current_task,
      updated.last_seen,
      updated.last_heartbeat,
      updated.listing_count,
      updated.conversation_count,
      updated.unread_count,
      updated.chrome_window_name,
      updated.bot_connected,
      updated.updated_at,
      id,
      userId
    );

    return updated;
  }

  updateCounts(id: string, userId: string): void {
    const db = getDatabase();
    const listingRow = db.prepare('SELECT COUNT(*) as cnt FROM listings WHERE profile_id = ? AND user_id = ?').get(id, userId) as { cnt: number };
    const convRow = db.prepare('SELECT COUNT(*) as cnt, COALESCE(SUM(unread_count), 0) as unread FROM conversations WHERE profile_id = ? AND user_id = ?').get(id, userId) as { cnt: number; unread: number };

    db.prepare(`
      UPDATE chrome_profiles
      SET listing_count = ?, conversation_count = ?, unread_count = ?, updated_at = ?
      WHERE id = ? AND user_id = ?
    `).run(listingRow?.cnt || 0, convRow?.cnt || 0, convRow?.unread || 0, Date.now(), id, userId);
  }

  /**
   * Marks any profile OFFLINE whose bot hasn't heartbeated within the timeout window. Mirrors
   * botRepository.markStaleBotsOffline() for the chrome_profiles table, which previously had no
   * server-side timeout at all — a profile would stay ONLINE forever once heartbeated, even after
   * the bot process actually died, until a new heartbeat happened to arrive.
   */
  markStaleProfilesOffline(cutoffTimestamp: number): number {
    const db = getDatabase();
    const res = db.prepare(`
      UPDATE chrome_profiles
      SET status = 'OFFLINE', bot_connected = 0, updated_at = ?
      WHERE last_heartbeat > 0 AND last_heartbeat < ? AND status != 'OFFLINE'
    `).run(Date.now(), cutoffTimestamp);
    return Number(res.changes);
  }

  deleteProfile(id: string, userId: string): boolean {
    const db = getDatabase();
    const result = db.prepare('DELETE FROM chrome_profiles WHERE id = ? AND user_id = ?').run(id, userId);
    return Number(result.changes) > 0;
  }
}

export const profileRepository = new ProfileRepository();
