import { getDatabase } from '../db/database';
import { EventRecord } from '../types';

export class EventRepository {
  createEvent(event: {
    eventId: string;
    userId: string;
    eventType: EventRecord['event_type'];
    aggregateType: EventRecord['aggregate_type'];
    aggregateId: string;
    payload: string;
    createdAt?: number;
  }): EventRecord {
    const db = getDatabase();
    const now = event.createdAt || Date.now();

    const result = db.prepare(`
      INSERT INTO events (event_id, user_id, event_type, aggregate_type, aggregate_id, payload, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      event.eventId,
      event.userId,
      event.eventType,
      event.aggregateType,
      event.aggregateId,
      event.payload,
      now
    );

    const sequence = Number(result.lastInsertRowid);

    return {
      sequence,
      event_id: event.eventId,
      user_id: event.userId,
      event_type: event.eventType,
      aggregate_type: event.aggregateType,
      aggregate_id: event.aggregateId,
      payload: event.payload,
      created_at: now,
    };
  }

  findEventsSince(userId: string, sequence: number, limit = 100): EventRecord[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT sequence, event_id, user_id, event_type, aggregate_type, aggregate_id, payload, created_at
      FROM events 
      WHERE user_id = ? AND sequence > ?
      ORDER BY sequence ASC
      LIMIT ?
    `).all(userId, sequence, limit) as unknown as EventRecord[];
  }

  getLatestSequence(userId: string): number {
    const db = getDatabase();
    const row = db.prepare('SELECT MAX(sequence) as max_seq FROM events WHERE user_id = ?').get(userId) as { max_seq: number | null };
    return row?.max_seq || 0;
  }
}

export const eventRepository = new EventRepository();
