import { getDatabase } from '../db/database';
import { Conversation, ConversationDto } from '../types';

export class ConversationRepository {
  createConversation(conv: {
    id: string;
    userId: string;
    profileId: string;
    listingId: string;
    customerId: string;
  }): Conversation {
    const db = getDatabase();
    const now = Date.now();

    db.prepare(`
      INSERT INTO conversations (
        id, user_id, profile_id, listing_id, customer_id, status, unread_count,
        last_message, last_message_at, is_pinned, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 'OPEN', 0, '', ?, 0, ?, ?)
    `).run(conv.id, conv.userId, conv.profileId, conv.listingId, conv.customerId, now, now, now);

    return {
      id: conv.id,
      user_id: conv.userId,
      profile_id: conv.profileId,
      listing_id: conv.listingId,
      customer_id: conv.customerId,
      status: 'OPEN',
      unread_count: 0,
      last_message: '',
      last_message_at: now,
      is_pinned: 0,
      created_at: now,
      updated_at: now,
    };
  }

  findByUserId(userId: string): ConversationDto[] {
    const db = getDatabase();
    const rows = db.prepare(`
      SELECT 
        c.id, c.profile_id, c.customer_id, c.listing_id, 
        c.unread_count, c.last_message, c.last_message_at, c.is_pinned,
        cust.name as customer_name,
        l.title as listing_title
      FROM conversations c
      LEFT JOIN customers cust ON c.customer_id = cust.id
      LEFT JOIN listings l ON c.listing_id = l.id
      WHERE c.user_id = ?
      ORDER BY c.last_message_at DESC
    `).all(userId) as any[];

    return rows.map(r => ({
      id: r.id,
      profile_id: r.profile_id,
      customer_id: r.customer_id,
      customer_name: r.customer_name || 'Customer',
      listing_id: r.listing_id,
      listing_title: r.listing_title || 'Listing',
      unread_count: r.unread_count || 0,
      last_message: r.last_message || '',
      last_message_at: r.last_message_at || 0,
      is_pinned: Boolean(r.is_pinned),
    }));
  }

  findById(id: string, userId: string): Conversation | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM conversations WHERE id = ? AND user_id = ?').get(id, userId) as Conversation | undefined;
    return row || null;
  }

  updateLastMessage(id: string, userId: string, text: string, timestamp: number, incUnread = false): void {
    const db = getDatabase();
    if (incUnread) {
      db.prepare(`
        UPDATE conversations 
        SET last_message = ?, last_message_at = ?, unread_count = unread_count + 1, updated_at = ?
        WHERE id = ? AND user_id = ?
      `).run(text, timestamp, Date.now(), id, userId);
    } else {
      db.prepare(`
        UPDATE conversations 
        SET last_message = ?, last_message_at = ?, updated_at = ?
        WHERE id = ? AND user_id = ?
      `).run(text, timestamp, Date.now(), id, userId);
    }
  }

  markRead(id: string, userId: string): void {
    const db = getDatabase();
    db.prepare('UPDATE conversations SET unread_count = 0, updated_at = ? WHERE id = ? AND user_id = ?').run(Date.now(), id, userId);
  }
}

export const conversationRepository = new ConversationRepository();
