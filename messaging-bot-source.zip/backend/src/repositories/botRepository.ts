import { getDatabase } from '../db/database';
import { Bot } from '../types';

export class BotRepository {
  createBot(bot: { id: string; userId: string; name: string; version?: string }): Bot {
    const db = getDatabase();
    const now = Date.now();
    const version = bot.version || 'DesktopBot v1.0';

    db.prepare(`
      INSERT INTO bots (id, user_id, name, status, current_task, version, last_heartbeat_at, created_at, updated_at)
      VALUES (?, ?, ?, 'OFFLINE', 'Idle', ?, NULL, ?, ?)
    `).run(bot.id, bot.userId, bot.name, version, now, now);

    return {
      id: bot.id,
      user_id: bot.userId,
      name: bot.name,
      status: 'OFFLINE',
      current_task: 'Idle',
      version,
      last_heartbeat_at: null,
      created_at: now,
      updated_at: now,
    };
  }

  findById(id: string, userId: string): Bot | null {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM bots WHERE id = ? AND user_id = ?').get(id, userId) as Bot | undefined;
    return row || null;
  }

  findByUserId(userId: string): Bot[] {
    const db = getDatabase();
    return db.prepare('SELECT * FROM bots WHERE user_id = ? ORDER BY created_at DESC').all(userId) as unknown as Bot[];
  }

  updateHeartbeat(botId: string, status: 'ONLINE' | 'OFFLINE' | 'BUSY', currentTask: string, version: string, timestamp: number): void {
    const db = getDatabase();
    db.prepare(`
      UPDATE bots 
      SET status = ?, current_task = ?, version = ?, last_heartbeat_at = ?, updated_at = ?
      WHERE id = ?
    `).run(status, currentTask, version, timestamp, Date.now(), botId);
  }

  markStaleBotsOffline(cutoffTimestamp: number): number {
    const db = getDatabase();
    const res = db.prepare(`
      UPDATE bots 
      SET status = 'OFFLINE', updated_at = ?
      WHERE (last_heartbeat_at IS NULL OR last_heartbeat_at < ?) AND status != 'OFFLINE'
    `).run(Date.now(), cutoffTimestamp);
    return Number(res.changes);
  }
}

export const botRepository = new BotRepository();
