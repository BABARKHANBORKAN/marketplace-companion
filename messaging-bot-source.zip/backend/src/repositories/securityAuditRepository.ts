import { getDatabase } from '../db/database';
import { v4 as uuidv4 } from 'uuid';
import { SecurityEvent } from '../types';

/**
 * Narrow, append-only log of security-relevant events — failed authentication, key revocation,
 * cross-tenant rejections. Not a general request log (that's requestLogger + logger.*); this is
 * specifically the subset worth being able to query as "what happened, security-wise."
 */
export class SecurityAuditRepository {
  log(event: {
    eventType: string;
    userId?: string | null;
    botId?: string | null;
    keyId?: string | null;
    ipAddress?: string | null;
    detail?: string | null;
  }): void {
    const db = getDatabase();
    db.prepare(`
      INSERT INTO security_events (id, event_type, user_id, bot_id, key_id, ip_address, detail, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      `sec_${uuidv4().substring(0, 12)}`,
      event.eventType,
      event.userId || null,
      event.botId || null,
      event.keyId || null,
      event.ipAddress || null,
      event.detail || null,
      Date.now()
    );
  }

  findRecent(limit = 100): SecurityEvent[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM security_events ORDER BY created_at DESC LIMIT ?
    `).all(limit) as unknown as SecurityEvent[];
  }

  findByType(eventType: string, limit = 100): SecurityEvent[] {
    const db = getDatabase();
    return db.prepare(`
      SELECT * FROM security_events WHERE event_type = ? ORDER BY created_at DESC LIMIT ?
    `).all(eventType, limit) as unknown as SecurityEvent[];
  }
}

export const securityAuditRepository = new SecurityAuditRepository();
