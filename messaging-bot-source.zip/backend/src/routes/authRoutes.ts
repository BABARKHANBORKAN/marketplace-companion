import { Router, Request, Response, NextFunction } from 'express';
import { authService } from '../services/authService';
import { authenticateUser } from '../middleware/auth';
import { appsCodeRateLimiter } from '../middleware/appsCodeRateLimiter';

const router = Router();

router.post('/register', (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = authService.register(req.body);
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
});

router.post('/login', (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = authService.login(req.body);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.post('/apps-code', appsCodeRateLimiter, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await authService.loginWithAppsCode({
      code: req.body.code,
      deviceInfo: req.body.deviceInfo,
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.post('/refresh', (req: Request, res: Response, next: NextFunction) => {
  try {
    const refreshToken = req.body.refreshToken || req.body.refresh_token;
    const result = authService.refresh({ refreshToken, deviceInfo: req.body.deviceInfo });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.post('/logout', authenticateUser, (req: Request, res: Response, next: NextFunction) => {
  try {
    const refreshToken = req.body.refreshToken || req.body.refresh_token;
    authService.logout(req.user!.userId, refreshToken);
    res.json({ success: true, message: 'Logged out successfully' });
  } catch (err) {
    next(err);
  }
});

router.post('/forgot-password', (req: Request, res: Response, next: NextFunction) => {
  try {
    // Return standard success to avoid user enumeration
    res.json({ success: true, message: 'If that email exists, password reset instructions have been sent.' });
  } catch (err) {
    next(err);
  }
});

router.get('/me', authenticateUser, (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = authService.getCurrentUser(req.user!.userId);
    res.json(user);
  } catch (err) {
    next(err);
  }
});

export default router;
