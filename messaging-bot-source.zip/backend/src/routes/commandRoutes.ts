import { Router, Request, Response, NextFunction } from 'express';
import { commandService } from '../services/commandService';
import { authenticateUser } from '../middleware/auth';

const router = Router();
router.use(authenticateUser);

router.post('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = commandService.dispatchCommand(req.user!.userId, {
      commandId: req.body.command_id || req.body.commandId,
      idempotencyKey: req.body.idempotency_key || req.body.idempotencyKey,
      profileId: req.body.profile_id || req.body.profileId,
      type: req.body.type,
      payload: typeof req.body.payload === 'object' ? JSON.stringify(req.body.payload) : req.body.payload,
      conversationId: req.body.conversation_id || req.body.conversationId,
      customerId: req.body.customer_id || req.body.customerId,
      listingId: req.body.listing_id || req.body.listingId,
      messageId: req.body.message_id || req.body.messageId,
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const command = commandService.getCommand(req.user!.userId, req.params.id as string);
    res.json(command);
  } catch (err) {
    next(err);
  }
});

export default router;
