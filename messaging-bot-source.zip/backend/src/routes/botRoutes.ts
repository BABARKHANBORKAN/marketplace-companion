import { Router, Request, Response, NextFunction } from 'express';
import { botService } from '../services/botService';
import { commandService } from '../services/commandService';
import { commandRepository } from '../repositories/commandRepository';
import { authenticateBot } from '../middleware/botAuth';
import { authenticateUser } from '../middleware/auth';
import { ApiError } from '../utils/errors';

const router = Router();

const VALID_HEARTBEAT_STATUSES = ['ONLINE', 'BUSY', 'OFFLINE'];
const VALID_COMMAND_STATUSES = ['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED'] as const;
type CommandStatusValue = (typeof VALID_COMMAND_STATUSES)[number];
const MAX_TASK_LENGTH = 500;
const MAX_RESULT_MESSAGE_LENGTH = 2000;
const MAX_ERROR_FIELD_LENGTH = 500;

// Heartbeat endpoint - authenticated via Bot API Key
router.post('/heartbeat', authenticateBot, (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = req.body.status;
    if (status !== undefined && (typeof status !== 'string' || !VALID_HEARTBEAT_STATUSES.includes(status.toUpperCase()))) {
      throw ApiError.badRequest(`Invalid status. Must be one of: ${VALID_HEARTBEAT_STATUSES.join(', ')}`);
    }
    const currentTask = req.body.current_task || req.body.currentTask;
    if (currentTask !== undefined && (typeof currentTask !== 'string' || currentTask.length > MAX_TASK_LENGTH)) {
      throw ApiError.badRequest(`current_task must be a string of at most ${MAX_TASK_LENGTH} characters`);
    }

    const result = botService.recordHeartbeat({
      botId: req.bot!.botId,
      profileId: req.bot!.profileId,
      userId: req.bot!.userId,
      botVersion: req.body.bot_version || req.body.botVersion,
      status,
      currentTask,
      timestamp: req.body.timestamp,
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

// Bot reporting status on a command
router.post('/commands/:id/status', authenticateBot, (req: Request, res: Response, next: NextFunction) => {
  try {
    const commandId = req.params.id as string;
    const status = req.body.status;
    if (!status || typeof status !== 'string') {
      throw ApiError.badRequest('Status is required');
    }
    const normalizedStatus = status.toUpperCase();
    if (!VALID_COMMAND_STATUSES.includes(normalizedStatus as CommandStatusValue)) {
      throw ApiError.badRequest(`Invalid status. Must be one of: ${VALID_COMMAND_STATUSES.join(', ')}`);
    }

    const resultMessage = req.body.resultMessage || req.body.result_message;
    if (resultMessage !== undefined && (typeof resultMessage !== 'string' || resultMessage.length > MAX_RESULT_MESSAGE_LENGTH)) {
      throw ApiError.badRequest(`result_message must be a string of at most ${MAX_RESULT_MESSAGE_LENGTH} characters`);
    }
    const errorCode = req.body.errorCode || req.body.error_code;
    if (errorCode !== undefined && (typeof errorCode !== 'string' || errorCode.length > MAX_ERROR_FIELD_LENGTH)) {
      throw ApiError.badRequest(`error_code must be a string of at most ${MAX_ERROR_FIELD_LENGTH} characters`);
    }
    const errorMessage = req.body.errorMessage || req.body.error_message;
    if (errorMessage !== undefined && (typeof errorMessage !== 'string' || errorMessage.length > MAX_RESULT_MESSAGE_LENGTH)) {
      throw ApiError.badRequest(`error_message must be a string of at most ${MAX_RESULT_MESSAGE_LENGTH} characters`);
    }

    const updated = commandService.updateCommandStatus(
      { userId: req.bot!.userId, profileId: req.bot!.profileId, botId: req.bot!.botId },
      commandId,
      normalizedStatus as CommandStatusValue,
      resultMessage,
      errorCode,
      errorMessage
    );
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

// Bot fetching pending commands for its assigned profile
router.get('/commands/pending', authenticateBot, (req: Request, res: Response, next: NextFunction) => {
  try {
    const pending = commandRepository.findPendingForBot(req.bot!.userId, req.bot!.profileId, req.bot!.botId);
    res.json(pending.map(c => commandRepository.toResponse(c)));
  } catch (err) {
    next(err);
  }
});

// Bot pushing an incoming message from Facebook Marketplace
router.post('/messages', authenticateBot, (req: Request, res: Response, next: NextFunction) => {
  try {
    const { conversationId, customerId, customerName, text, externalMessageId } = req.body;

    const created = botService.reportIncomingMessage({
      userId: req.bot!.userId,
      profileId: req.bot!.profileId,
      conversationId,
      customerId,
      customerName,
      text,
      externalMessageId,
    });

    res.status(201).json(created);
  } catch (err) {
    next(err);
  }
});

// --- User-facing Bot Management endpoints ---
router.post('/bots', authenticateUser, (req: Request, res: Response, next: NextFunction) => {
  try {
    const name = req.body.name || 'Desktop Bot';
    const version = req.body.version;
    const bot = botService.registerBot(req.user!.userId, name, version);
    res.status(201).json(bot);
  } catch (err) {
    next(err);
  }
});

router.get('/bots', authenticateUser, (req: Request, res: Response, next: NextFunction) => {
  try {
    const bots = botService.listBots(req.user!.userId);
    res.json(bots);
  } catch (err) {
    next(err);
  }
});

router.post('/bots/:botId/api-keys', authenticateUser, (req: Request, res: Response, next: NextFunction) => {
  try {
    const profileId = req.body.profile_id || req.body.profileId;
    const serverUrl = req.body.server_url || req.body.serverUrl;
    const key = botService.generateApiKey({
      userId: req.user!.userId,
      profileId,
      serverUrl,
      botId: req.params.botId as string,
    });
    res.status(201).json(key);
  } catch (err) {
    next(err);
  }
});

export default router;
