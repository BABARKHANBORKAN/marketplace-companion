import { Router, Request, Response, NextFunction } from 'express';
import { conversationService } from '../services/conversationService';
import { authenticateUser } from '../middleware/auth';

const router = Router();
router.use(authenticateUser);

router.get('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const convs = conversationService.listConversations(req.user!.userId);
    res.json(convs);
  } catch (err) {
    next(err);
  }
});

router.get('/:id/messages', (req: Request, res: Response, next: NextFunction) => {
  try {
    const messages = conversationService.getMessages(req.user!.userId, req.params.id as string);
    res.json(messages);
  } catch (err) {
    next(err);
  }
});

router.post('/:id/messages', (req: Request, res: Response, next: NextFunction) => {
  try {
    const message = conversationService.sendMessage(req.user!.userId, req.params.id as string, {
      text: req.body.text,
      commandId: req.body.command_id || req.body.commandId,
      idempotencyKey: req.body.idempotency_key || req.body.idempotencyKey,
      stopTaskFirst: req.body.stop_task_first || req.body.stopTaskFirst,
      reopenChromeFirst: req.body.reopen_chrome_first || req.body.reopenChromeFirst,
    });
    res.status(201).json(message);
  } catch (err) {
    next(err);
  }
});

export default router;
