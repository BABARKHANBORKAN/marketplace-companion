import { Router, Request, Response, NextFunction } from 'express';
import { botService } from '../services/botService';
import { authenticateUser } from '../middleware/auth';

const router = Router();
router.use(authenticateUser);

router.get('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const keys = botService.listApiKeys(req.user!.userId);
    res.json(keys);
  } catch (err) {
    next(err);
  }
});

router.post('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const profileId = req.body.profile_id || req.body.profileId;
    const serverUrl = req.body.server_url || req.body.serverUrl;
    const key = botService.generateApiKey({
      userId: req.user!.userId,
      profileId,
      serverUrl,
    });
    res.status(201).json(key);
  } catch (err) {
    next(err);
  }
});

router.post('/:id/revoke', (req: Request, res: Response, next: NextFunction) => {
  try {
    botService.revokeApiKey(req.user!.userId, req.params.id as string);
    res.json({ success: true, message: 'API key revoked' });
  } catch (err) {
    next(err);
  }
});

// Rotation: mint a fresh key for the same (bot, profile) and immediately revoke the old one
// (disconnecting it right away if it's currently connected). The new raw key is returned once.
router.post('/:id/rotate', (req: Request, res: Response, next: NextFunction) => {
  try {
    const rotated = botService.rotateApiKey(req.user!.userId, req.params.id as string);
    res.status(201).json(rotated);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    botService.deleteApiKey(req.user!.userId, req.params.id as string);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

export default router;
