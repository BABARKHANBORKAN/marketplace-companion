import { Router, Request, Response, NextFunction } from 'express';
import { syncService } from '../services/syncService';
import { authenticateUser } from '../middleware/auth';

const router = Router();
router.use(authenticateUser);

router.get('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const cursor = typeof req.query.cursor === 'string' ? req.query.cursor : undefined;
    const sinceStr = typeof req.query.since === 'string' ? req.query.since : undefined;
    const since = sinceStr ? parseInt(sinceStr, 10) : undefined;

    const response = syncService.deltaSync(req.user!.userId, cursor, since);
    res.json(response);
  } catch (err) {
    next(err);
  }
});

export default router;
