import { Router, Request, Response, NextFunction } from 'express';
import { listingService } from '../services/listingService';
import { authenticateUser } from '../middleware/auth';

const router = Router();
router.use(authenticateUser);

router.get('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const listings = listingService.listListings(req.user!.userId);
    res.json(listings);
  } catch (err) {
    next(err);
  }
});

router.post('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const listing = listingService.createListing(req.user!.userId, {
      profileId: req.body.profile_id || req.body.profileId,
      title: req.body.title,
      price: req.body.price,
      category: req.body.category,
      description: req.body.description,
      location: req.body.location,
      imageUrl: req.body.image_url || req.body.imageUrl,
    });
    res.status(201).json(listing);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    listingService.deleteListing(req.user!.userId, req.params.id as string);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

export default router;
