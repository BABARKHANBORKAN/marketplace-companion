import { Router, Request, Response, NextFunction } from 'express';
import { profileService } from '../services/profileService';
import { authenticateUser } from '../middleware/auth';

const router = Router();
router.use(authenticateUser);

router.get('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const profiles = profileService.listProfiles(req.user!.userId);
    res.json(profiles);
  } catch (err) {
    next(err);
  }
});

router.post('/', (req: Request, res: Response, next: NextFunction) => {
  try {
    const name = req.body.name;
    const accountLabel = req.body.account_label || req.body.accountLabel;
    const profile = profileService.createProfile(req.user!.userId, name, accountLabel);
    res.status(201).json(profile);
  } catch (err) {
    next(err);
  }
});

router.get('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const profile = profileService.getProfile(req.user!.userId, req.params.id as string);
    res.json(profile);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    profileService.deleteProfile(req.user!.userId, req.params.id as string);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

export default router;
