import dotenv from 'dotenv';
import path from 'path';

// Load .env from backend directory or project root
dotenv.config({ path: path.resolve(process.cwd(), '.env') });
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

export const config = {
  env: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '8080', 10),
  host: process.env.HOST || '0.0.0.0',
  databaseFile: process.env.DATABASE_FILE || path.resolve(__dirname, '../../marketplace.db'),
  jwtSecret: process.env.JWT_SECRET || 'mpc_jwt_production_secret_key_change_in_prod_!@#$',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '2h',
  refreshTokenExpiresDays: parseInt(process.env.REFRESH_TOKEN_EXPIRES_DAYS || '30', 10),
  botKeyPepper: process.env.BOT_KEY_PEPPER || 'mpc_bot_pepper_secret_salting_hash_999!',
  corsOrigins: process.env.CORS_ORIGINS || '*',
  serverUrl: process.env.SERVER_URL || 'https://api.marketplace-companion.local/',
  logLevel: process.env.LOG_LEVEL || 'info',
  botHeartbeatTimeoutMs: parseInt(process.env.BOT_HEARTBEAT_TIMEOUT_MS || '90000', 10),
  commandProcessingTimeoutMs: parseInt(process.env.COMMAND_PROCESSING_TIMEOUT_MS || '120000', 10),

  // "Apps Code" alternate login: a code stored in Supabase grants access to one shared account.
  // Table/column names are configurable since the exact schema of the user's Supabase project
  // isn't known here — adjust these to match without touching code.
  supabaseUrl: process.env.SUPABASE_URL || '',
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '',
  supabaseCodesTable: process.env.SUPABASE_CODES_TABLE || 'app_codes',
  supabaseCodesCodeColumn: process.env.SUPABASE_CODES_CODE_COLUMN || 'code',
  // Nullish coalescing (not ||): an explicit empty value means "no active column" (see
  // supabaseClient.ts), which must be distinguishable from the variable being unset entirely.
  supabaseCodesActiveColumn: process.env.SUPABASE_CODES_ACTIVE_COLUMN ?? 'is_active',
  appsCodeSharedAccountEmail: process.env.APPS_CODE_SHARED_ACCOUNT_EMAIL || 'apps-code@system.local',
  appsCodeSharedAccountName: process.env.APPS_CODE_SHARED_ACCOUNT_NAME || 'Apps Code User',
};
