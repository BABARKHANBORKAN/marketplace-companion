import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/errors';
import { logger } from '../utils/logger';

export function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  const requestId = req.id;

  if (err instanceof ApiError) {
    logger.warn(`API Error [${err.code}] ${err.message}`, {
      path: req.originalUrl,
      requestId,
      statusCode: err.statusCode,
    });

    return res.status(err.statusCode).json({
      error: {
        code: err.code,
        message: err.message,
        requestId,
        ...(err.details ? { details: err.details } : {}),
      },
    });
  }

  // Handle syntax/parsing errors (e.g. malformed JSON)
  if (err instanceof SyntaxError && 'status' in err && (err as any).status === 400) {
    return res.status(400).json({
      error: {
        code: 'MALFORMED_JSON',
        message: 'Request body contains invalid JSON',
        requestId,
      },
    });
  }

  logger.error(`Unhandled Server Error: ${err?.message || err}`, {
    stack: err?.stack,
    path: req.originalUrl,
    requestId,
  });

  return res.status(500).json({
    error: {
      code: 'INTERNAL_SERVER_ERROR',
      message: 'An unexpected internal server error occurred',
      requestId,
    },
  });
}
