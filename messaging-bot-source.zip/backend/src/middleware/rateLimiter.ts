import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/errors';
import { hashBotApiKey } from '../utils/crypto';

interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const windowMs = 60 * 1000; // 1 minute
const maxRequestsPerWindow = 300; // 300 requests per minute per identity
const ipRecords = new Map<string, RateLimitRecord>();

export function rateLimiter(req: Request, res: Response, next: NextFunction) {
  // This middleware runs before route-specific auth (authenticateUser/authenticateBot), so
  // req.user/req.bot aren't populated yet. For a Bot API key, hash the raw key directly (no DB
  // lookup needed) so each bot is limited independently of every other bot sharing an IP — and
  // independently of the user-facing API sharing that same IP, if they're behind the same NAT.
  const identifier = req.user?.userId || botKeyIdentifier(req) || req.ip || req.socket.remoteAddress || 'anonymous';
  const now = Date.now();

  const record = ipRecords.get(identifier);
  if (!record || now > record.resetAt) {
    ipRecords.set(identifier, { count: 1, resetAt: now + windowMs });
    return next();
  }

  record.count++;
  if (record.count > maxRequestsPerWindow) {
    return next(ApiError.tooManyRequests('Too many requests, please slow down'));
  }

  next();
}

function botKeyIdentifier(req: Request): string | null {
  const authHeader = req.headers['authorization'];
  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer mpc_')) {
    return `bot:${hashBotApiKey(authHeader.substring(7).trim())}`;
  }
  return null;
}

// Periodic cleanup of stale rate-limit records
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of ipRecords.entries()) {
    if (now > val.resetAt) {
      ipRecords.delete(key);
    }
  }
}, 60 * 1000).unref();
