import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken, JwtUserPayload } from '../utils/jwt';
import { ApiError } from '../utils/errors';

declare global {
  namespace Express {
    interface Request {
      user?: JwtUserPayload;
    }
  }
}

export function authenticateUser(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next(ApiError.unauthorized('Missing or invalid Authorization header'));
  }

  const token = authHeader.substring(7).trim();
  if (!token) {
    return next(ApiError.unauthorized('Bearer token is empty'));
  }

  const payload = verifyAccessToken(token);
  if (!payload) {
    return next(ApiError.unauthorized('Token is expired or invalid'));
  }

  req.user = payload;
  next();
}
