import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/errors';

// Much tighter than the global rateLimiter: this endpoint grants a session on success, so it's
// a brute-force-guessing surface for short codes and needs its own stricter ceiling regardless
// of how much other traffic that IP is otherwise allowed.
const windowMs = 15 * 60 * 1000; // 15 minutes
const maxAttemptsPerWindow = 8;
const attempts = new Map<string, { count: number; resetAt: number }>();

export function appsCodeRateLimiter(req: Request, res: Response, next: NextFunction) {
  const identifier = req.ip || req.socket.remoteAddress || 'anonymous';
  const now = Date.now();

  const record = attempts.get(identifier);
  if (!record || now > record.resetAt) {
    attempts.set(identifier, { count: 1, resetAt: now + windowMs });
    return next();
  }

  record.count++;
  if (record.count > maxAttemptsPerWindow) {
    return next(ApiError.tooManyRequests('Too many Apps Code attempts, please try again later'));
  }

  next();
}

setInterval(() => {
  const now = Date.now();
  for (const [key, val] of attempts.entries()) {
    if (now > val.resetAt) attempts.delete(key);
  }
}, 60 * 1000).unref();
