import { Request, Response, NextFunction } from 'express';
import { hashBotApiKey } from '../utils/crypto';
import { ApiError } from '../utils/errors';
import { getDatabase } from '../db/database';
import { BotApiKey } from '../types';
import { securityAuditRepository } from '../repositories/securityAuditRepository';

export interface BotContext {
  keyId: string;
  botId: string;
  userId: string;
  profileId: string;
}

declare global {
  namespace Express {
    interface Request {
      bot?: BotContext;
    }
  }
}

export function authenticateBot(req: Request, res: Response, next: NextFunction) {
  // Bot authentication uses exactly one convention everywhere (HTTP and WebSocket):
  // Authorization: Bearer mpc_live_... — no alternate header.
  let rawKey: string | null = null;

  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    rawKey = authHeader.substring(7).trim();
  }

  if (!rawKey) {
    return next(ApiError.unauthorized('Missing Bot API Key in Authorization header (expected: Bearer mpc_live_...)'));
  }

  const keyHash = hashBotApiKey(rawKey);
  const db = getDatabase();

  const row = db.prepare(`
    SELECT id, bot_id, user_id, profile_id, status 
    FROM bot_api_keys 
    WHERE key_hash = ?
  `).get(keyHash) as { id: string; bot_id: string; user_id: string; profile_id: string; status: string } | undefined;

  if (!row) {
    securityAuditRepository.log({
      eventType: 'BOT_AUTH_INVALID_KEY',
      ipAddress: req.ip,
      detail: `${req.method} ${req.originalUrl}`,
    });
    return next(ApiError.unauthorized('Invalid Bot API Key'));
  }

  if (row.status !== 'ACTIVE') {
    securityAuditRepository.log({
      eventType: 'BOT_AUTH_REVOKED_KEY_USED',
      userId: row.user_id,
      botId: row.bot_id,
      keyId: row.id,
      ipAddress: req.ip,
      detail: `status=${row.status}, ${req.method} ${req.originalUrl}`,
    });
    return next(ApiError.forbidden(`Bot API Key is ${row.status.toLowerCase()}`));
  }

  // Update last_used_at timestamp
  db.prepare('UPDATE bot_api_keys SET last_used_at = ? WHERE id = ?').run(Date.now(), row.id);

  req.bot = {
    keyId: row.id,
    botId: row.bot_id,
    userId: row.user_id,
    profileId: row.profile_id,
  };

  next();
}
