import { v4 as uuidv4 } from 'uuid';
import { conversationRepository } from '../repositories/conversationRepository';
import { messageRepository } from '../repositories/messageRepository';
import { commandRepository } from '../repositories/commandRepository';
import { profileRepository } from '../repositories/profileRepository';
import { eventHub } from '../websocket/eventHub';
import { ApiError } from '../utils/errors';
import { ConversationDto, MessageDto } from '../types';
import { MAX_MESSAGE_LENGTH } from './botService';

export class ConversationService {
  listConversations(userId: string): ConversationDto[] {
    return conversationRepository.findByUserId(userId);
  }

  getMessages(userId: string, conversationId: string): MessageDto[] {
    const conv = conversationRepository.findById(conversationId, userId);
    if (!conv) {
      throw ApiError.notFound('Conversation not found');
    }
    return messageRepository.findByConversationId(conversationId, userId);
  }

  sendMessage(
    userId: string,
    conversationId: string,
    data: {
      text: string;
      commandId?: string;
      idempotencyKey?: string;
      stopTaskFirst?: boolean;
      reopenChromeFirst?: boolean;
    }
  ): MessageDto {
    const { text, commandId, idempotencyKey } = data;
    if (!text || !text.trim()) {
      throw ApiError.badRequest('Message text is required');
    }
    if (text.length > MAX_MESSAGE_LENGTH) {
      throw ApiError.badRequest(`Message text exceeds maximum length of ${MAX_MESSAGE_LENGTH} characters`);
    }

    const conv = conversationRepository.findById(conversationId, userId);
    if (!conv) {
      throw ApiError.notFound('Conversation not found');
    }

    // Idempotency check
    if (idempotencyKey) {
      const existing = messageRepository.findByIdempotencyKey(userId, idempotencyKey);
      if (existing) {
        return {
          id: existing.id,
          conversation_id: existing.conversation_id,
          sender: existing.sender,
          text: existing.text,
          status: existing.status,
          timestamp: existing.timestamp,
          command_id: existing.command_id,
          idempotency_key: existing.idempotency_key,
        };
      }
    }

    const messageId = `msg_${uuidv4().substring(0, 10)}`;
    const effectiveCommandId = commandId || `cmd_${uuidv4().substring(0, 10)}`;
    const now = Date.now();

    const createdMsg = messageRepository.createMessage({
      id: messageId,
      userId,
      conversationId,
      commandId: effectiveCommandId,
      idempotencyKey: idempotencyKey || null,
      sender: 'USER_APP',
      text: text.trim(),
      status: 'PROCESSING',
      timestamp: now,
    });

    // Update conversation last message
    conversationRepository.updateLastMessage(conversationId, userId, text.trim(), now, false);

    // Queue command for Desktop Bot
    const cmdPayload = JSON.stringify({
      action: 'SEND_MESSAGE',
      conversationId,
      messageId,
      text: text.trim(),
      profileId: conv.profile_id,
      stopTaskFirst: Boolean(data.stopTaskFirst),
      reopenChromeFirst: Boolean(data.reopenChromeFirst),
    });

    const command = commandRepository.createCommand({
      id: effectiveCommandId,
      userId,
      profileId: conv.profile_id,
      conversationId,
      customerId: conv.customer_id,
      listingId: conv.listing_id,
      messageId,
      commandType: 'SEND_MESSAGE',
      payload: cmdPayload,
      status: 'PENDING',
      idempotencyKey: idempotencyKey || null,
    });

    // Dispatch command to bot if connected (push wake-up; command remains PENDING until the bot claims it)
    const delivered = eventHub.dispatchToBot(conv.profile_id, {
      type: 'EXECUTE_COMMAND',
      commandId: command.id,
      commandType: command.command_type,
      profileId: conv.profile_id,
      payload: cmdPayload,
      conversationId,
      messageId,
    });
    if (delivered) {
      commandRepository.markDispatched(command.id);
    }

    // Record in the event log (and push to the user's other connected devices) so cursor-based
    // delta sync sees this message without relying on a broader timestamp scan. The sending
    // device already has this message locally, so it will simply no-op on receipt.
    eventHub.publish({
      eventId: `evt_${uuidv4().substring(0, 10)}`,
      userId,
      eventType: 'NEW_MESSAGE',
      aggregateType: 'conversation',
      aggregateId: conversationId,
      payload: {
        id: createdMsg.id,
        conversationId: createdMsg.conversation_id,
        sender: createdMsg.sender,
        text: createdMsg.text,
        status: createdMsg.status,
        timestamp: createdMsg.timestamp,
      },
    });

    return {
      id: createdMsg.id,
      conversation_id: createdMsg.conversation_id,
      sender: createdMsg.sender,
      text: createdMsg.text,
      status: createdMsg.status,
      timestamp: createdMsg.timestamp,
      command_id: createdMsg.command_id,
      idempotency_key: createdMsg.idempotency_key,
    };
  }
}

export const conversationService = new ConversationService();
