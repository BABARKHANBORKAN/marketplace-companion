import { v4 as uuidv4 } from 'uuid';
import { listingRepository } from '../repositories/listingRepository';
import { profileRepository } from '../repositories/profileRepository';
import { ApiError } from '../utils/errors';
import { ListingDto } from '../types';
import { eventHub } from '../websocket/eventHub';

export class ListingService {
  listListings(userId: string): ListingDto[] {
    const listings = listingRepository.findByUserId(userId);
    return listings.map(l => this.toDto(l));
  }

  createListing(userId: string, data: {
    profileId: string;
    title: string;
    price: number;
    category?: string;
    description?: string;
    location?: string;
    imageUrl?: string;
  }): ListingDto {
    const { profileId, title, price, category, description, location, imageUrl } = data;
    if (!profileId || !title || price === undefined) {
      throw ApiError.badRequest('Profile ID, title, and price are required');
    }

    const profile = profileRepository.findById(profileId, userId);
    if (!profile) {
      throw ApiError.notFound('Chrome profile not found');
    }

    const id = `lst_${uuidv4().substring(0, 10)}`;
    const listing = listingRepository.createListing({
      id,
      userId,
      profileId,
      title,
      price: Number(price),
      category,
      description,
      location,
      imageUrl,
    });

    profileRepository.updateCounts(profileId, userId);

    const dto = this.toDto(listing);

    // Record the creation in the event log so cursor-based delta sync picks it up.
    eventHub.publish({
      eventId: `evt_${uuidv4().substring(0, 10)}`,
      userId,
      eventType: 'LISTING_CREATED',
      aggregateType: 'listing',
      aggregateId: listing.id,
      payload: dto,
    });

    return dto;
  }

  deleteListing(userId: string, id: string): void {
    const listing = listingRepository.findById(id, userId);
    if (!listing) {
      throw ApiError.notFound('Listing not found');
    }

    listingRepository.deleteListing(id, userId);
    profileRepository.updateCounts(listing.profile_id, userId);
  }

  private toDto(l: any): ListingDto {
    return {
      id: l.id,
      profile_id: l.profile_id,
      title: l.title,
      price: l.price,
      currency: l.currency,
      status: l.status,
      category: l.category,
      description: l.description,
      location: l.location,
      conversation_count: l.conversation_count,
      message_count: l.message_count,
      created_at: l.created_at,
      image_url: l.image_url,
    };
  }
}

export const listingService = new ListingService();
