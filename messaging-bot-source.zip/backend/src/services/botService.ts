import { v4 as uuidv4 } from 'uuid';
import { botRepository } from '../repositories/botRepository';
import { apiKeyRepository } from '../repositories/apiKeyRepository';
import { profileRepository } from '../repositories/profileRepository';
import { commandRepository } from '../repositories/commandRepository';
import { conversationRepository } from '../repositories/conversationRepository';
import { customerRepository } from '../repositories/customerRepository';
import { messageRepository } from '../repositories/messageRepository';
import { generateBotApiKey } from '../utils/crypto';
import { ApiError } from '../utils/errors';
import { Bot, BotConnectionDto, MessageDto } from '../types';
import { eventHub } from '../websocket/eventHub';
import { logger } from '../utils/logger';
import { securityAuditRepository } from '../repositories/securityAuditRepository';

// A chat message has no legitimate reason to be enormous; caps abuse/accidental huge payloads
// independent of the blanket 5mb JSON body limit (which exists to bound parsing cost, not to
// validate any individual field).
export const MAX_MESSAGE_LENGTH = 10000;

export class BotService {
  registerBot(userId: string, name: string, version?: string): Bot {
    const id = `bot_${uuidv4().substring(0, 10)}`;
    return botRepository.createBot({
      id,
      userId,
      name,
      version,
    });
  }

  generateApiKey(params: {
    userId: string;
    profileId: string;
    serverUrl?: string;
    botId?: string;
  }): BotConnectionDto {
    const { userId, profileId, serverUrl } = params;
    if (!profileId) {
      throw ApiError.badRequest('Profile ID is required');
    }

    // Verify profile ownership
    const profile = profileRepository.findById(profileId, userId);
    if (!profile) {
      throw ApiError.notFound('Chrome profile not found');
    }

    // Use or create a bot record. A caller-supplied botId must be verified to belong to this
    // user before it's trusted — otherwise a client could mint a key that associates their own
    // profile with someone else's bot, and later heartbeats/commands would write to that bot.
    let botId = params.botId;
    if (botId) {
      const ownedBot = botRepository.findById(botId, userId);
      if (!ownedBot) {
        throw ApiError.notFound('Bot not found');
      }
    } else {
      const existingBots = botRepository.findByUserId(userId);
      if (existingBots.length > 0) {
        botId = existingBots[0].id;
      } else {
        const newBot = this.registerBot(userId, `Desktop Bot (${profile.name})`);
        botId = newBot.id;
      }
    }

    const { rawKey, keyPrefix, keyLastFour, keyHash, maskedKey } = generateBotApiKey();
    const keyId = `key_${uuidv4().substring(0, 10)}`;
    const effectiveServerUrl = serverUrl || 'https://api.marketplace-companion.local/';

    const apiKey = apiKeyRepository.createKey({
      id: keyId,
      botId,
      userId,
      profileId,
      keyHash,
      keyPrefix,
      keyLastFour,
      serverUrl: effectiveServerUrl,
    });

    profileRepository.updateProfile(profileId, userId, { bot_id: botId });

    return {
      id: apiKey.id,
      profile_id: apiKey.profile_id,
      masked_key: apiKey.key_prefix + '••••••••••••' + apiKey.key_last_four,
      api_key: rawKey, // Plaintext returned ONLY ONCE upon creation!
      server_url: apiKey.server_url,
      status: apiKey.status,
      last_heartbeat: 0,
      bot_version: 'DesktopBot v2.4.1',
      created_at: apiKey.created_at,
    };
  }

  listApiKeys(userId: string): BotConnectionDto[] {
    const keys = apiKeyRepository.findByUserId(userId);
    return keys.map((k) => ({
      id: k.id,
      profile_id: k.profile_id,
      masked_key: k.key_prefix + '••••••••••••' + k.key_last_four,
      server_url: k.server_url,
      status: k.status,
      last_heartbeat: k.last_used_at || 0,
      bot_version: 'DesktopBot v2.4.1',
      created_at: k.created_at,
    }));
  }

  revokeApiKey(userId: string, keyId: string): void {
    const key = apiKeyRepository.findById(keyId, userId);
    const success = apiKeyRepository.revokeKey(keyId, userId);
    if (!success) {
      throw ApiError.notFound('API key not found');
    }
    // A revoked key must stop working immediately, not just on the bot's next reconnect — if
    // it's currently connected, disconnect it right now.
    if (key) {
      eventHub.disconnectBotKey(key.profile_id, keyId);
      securityAuditRepository.log({
        eventType: 'BOT_API_KEY_REVOKED',
        userId,
        botId: key.bot_id,
        keyId,
      });
    }
  }

  /**
   * Deletes every Bot API key assigned to a profile (and disconnects any currently-connected
   * bot using one), so a deleted profile doesn't leave a dangling-but-still-ACTIVE key behind —
   * profile_id has no cascade to bot_api_keys, so this must be done explicitly. Called from
   * profileService.deleteProfile() before the profile row itself is removed.
   */
  deleteKeysForProfile(userId: string, profileId: string): void {
    const keys = apiKeyRepository.findByProfileId(profileId, userId);
    for (const key of keys) {
      apiKeyRepository.deleteKey(key.id, userId);
      eventHub.disconnectBotKey(profileId, key.id);
      securityAuditRepository.log({
        eventType: 'BOT_API_KEY_DELETED',
        userId,
        botId: key.bot_id,
        keyId: key.id,
        detail: 'Deleted as part of profile deletion',
      });
    }
  }

  deleteApiKey(userId: string, keyId: string): void {
    const key = apiKeyRepository.findById(keyId, userId);
    const success = apiKeyRepository.deleteKey(keyId, userId);
    if (!success) {
      throw ApiError.notFound('API key not found');
    }
    if (key) {
      eventHub.disconnectBotKey(key.profile_id, keyId);
      securityAuditRepository.log({
        eventType: 'BOT_API_KEY_DELETED',
        userId,
        botId: key.bot_id,
        keyId,
      });
    }
  }

  /**
   * Rotates a Bot API Key: mints a fresh key for the exact same (bot, profile), then revokes
   * the old one (which also disconnects it immediately if it's live). Atomic from the caller's
   * point of view — either both happen or neither does.
   */
  rotateApiKey(userId: string, keyId: string): BotConnectionDto {
    const existing = apiKeyRepository.findById(keyId, userId);
    if (!existing) {
      throw ApiError.notFound('API key not found');
    }

    const rotated = this.generateApiKey({
      userId,
      profileId: existing.profile_id,
      serverUrl: existing.server_url,
      botId: existing.bot_id,
    });

    this.revokeApiKey(userId, keyId);

    return rotated;
  }

  recordHeartbeat(params: {
    userId: string;
    profileId: string;
    botId?: string;
    botVersion?: string;
    status?: string;
    currentTask?: string;
    timestamp?: number;
  }): { acknowledged: boolean; timestamp: number; pending_commands_count: number } {
    const { userId, profileId, botId, botVersion, status, currentTask } = params;
    const now = Date.now();
    const effectiveStatus = (status?.toUpperCase() === 'BUSY' ? 'BUSY' : 'ONLINE') as 'ONLINE' | 'BUSY';
    const effectiveTask = currentTask || 'Idle';
    const effectiveVersion = botVersion || 'DesktopBot v2.4.1';

    if (!userId || !profileId) {
      throw ApiError.badRequest('User ID and Profile ID are required');
    }

    const profile = profileRepository.findById(profileId, userId);
    if (!profile) {
      throw ApiError.notFound('Chrome profile not found');
    }

    const effectiveBotId = botId || profile.bot_id;

    profileRepository.updateProfile(profileId, userId, {
      status: effectiveStatus,
      current_task: effectiveTask,
      last_seen: now,
      last_heartbeat: now,
      bot_connected: 1,
    });

    if (effectiveBotId) {
      botRepository.updateHeartbeat(effectiveBotId, effectiveStatus, effectiveTask, effectiveVersion, now);
    }

    const pendingCmds = commandRepository.findPendingForBot(userId, profileId, effectiveBotId || '');
    const pendingCount = pendingCmds.length;

    // Broadcast BOT_HEARTBEAT event to user sockets
    eventHub.publish({
      eventId: `evt_${uuidv4().substring(0, 10)}`,
      userId,
      eventType: 'BOT_HEARTBEAT',
      aggregateType: 'profile',
      aggregateId: profileId,
      payload: {
        profileId,
        botId: effectiveBotId || '',
        status: effectiveStatus,
        currentTask: effectiveTask,
        botVersion: effectiveVersion,
        timestamp: now,
        pendingCommandsCount: pendingCount,
      },
    });

    return {
      acknowledged: true,
      timestamp: now,
      pending_commands_count: pendingCount,
    };
  }

  listBots(userId: string): Bot[] {
    return botRepository.findByUserId(userId);
  }

  /**
   * Ingests a customer message reported by a Desktop Bot. The caller (HTTP route or
   * WebSocket handler) supplies the authenticated Bot API Key's (userId, profileId) scope;
   * when a conversationId is given explicitly, it must resolve to a conversation owned by
   * that exact (user, profile) pair, otherwise the bot could inject messages into another
   * tenant's conversation, or another profile's conversation within the same tenant.
   */
  reportIncomingMessage(params: {
    userId: string;
    profileId: string;
    conversationId?: string;
    customerId?: string;
    customerName?: string;
    text: string;
    externalMessageId?: string;
  }): MessageDto {
    const { userId, profileId, text } = params;
    if (!text) {
      throw ApiError.badRequest('Text is required');
    }
    if (text.length > MAX_MESSAGE_LENGTH) {
      throw ApiError.badRequest(`Message text exceeds maximum length of ${MAX_MESSAGE_LENGTH} characters`);
    }

    // Durable idempotency: if the bot already reported this exact platform message (its own
    // reconnect/replay, a lost ack it's retrying, etc.), return the existing record unchanged
    // rather than inserting a duplicate Marketplace message into the conversation.
    if (params.externalMessageId) {
      const existing = messageRepository.findByExternalMessageId(userId, params.externalMessageId);
      if (existing) {
        return {
          id: existing.id,
          conversation_id: existing.conversation_id,
          sender: existing.sender,
          text: existing.text,
          status: existing.status,
          timestamp: existing.timestamp,
        };
      }
    }

    let targetConvId: string | undefined;
    if (params.conversationId) {
      const conv = conversationRepository.findById(params.conversationId, userId);
      if (!conv || conv.profile_id !== profileId) {
        securityAuditRepository.log({
          eventType: 'BOT_CROSS_SCOPE_MESSAGE_REJECTED',
          userId,
          detail: `attempted conversationId=${params.conversationId} from profile=${profileId}`,
        });
        throw ApiError.notFound('Conversation not found for this bot profile');
      }
      targetConvId = conv.id;
    } else if (params.customerId) {
      const cust = customerRepository.findOrCreateCustomer(userId, params.customerId, params.customerName || 'Customer');
      const conv = conversationRepository.findByUserId(userId).find(c => c.profile_id === profileId && c.customer_id === cust.id);
      targetConvId = conv?.id;
    }

    if (!targetConvId) {
      throw ApiError.badRequest('Unable to find matching conversation');
    }

    const msgId = `msg_${uuidv4().substring(0, 10)}`;
    const now = Date.now();
    const createdMsg = messageRepository.createMessage({
      id: msgId,
      userId,
      conversationId: targetConvId,
      externalMessageId: params.externalMessageId || null,
      sender: 'CUSTOMER',
      text,
      status: 'SENT',
      timestamp: now,
    });

    conversationRepository.updateLastMessage(targetConvId, userId, text, now, true);
    profileRepository.updateCounts(profileId, userId);

    eventHub.publish({
      eventId: `evt_${uuidv4().substring(0, 10)}`,
      userId,
      eventType: 'NEW_MESSAGE',
      aggregateType: 'conversation',
      aggregateId: targetConvId,
      payload: {
        id: createdMsg.id,
        conversationId: createdMsg.conversation_id,
        sender: 'CUSTOMER',
        text: createdMsg.text,
        status: 'SENT',
        timestamp: createdMsg.timestamp,
      },
    });

    return {
      id: createdMsg.id,
      conversation_id: createdMsg.conversation_id,
      sender: createdMsg.sender,
      text: createdMsg.text,
      status: createdMsg.status,
      timestamp: createdMsg.timestamp,
    };
  }

  /**
   * Called right after a bot's WebSocket connection is (re-)established. Re-sends any command
   * still PENDING or PROCESSING for this exact (user, profile, bot) scope, so a bot that
   * reconnects after a crash/restart doesn't have to guess what it still owes — it gets pushed
   * again automatically. This is safe against duplicate execution: the bot must still explicitly
   * claim (or re-confirm) each command through the same atomic, state-machine-guarded status
   * endpoint as any other dispatch, so re-pushing a command someone else already completed is a
   * no-op at the claim step, not a re-execution.
   */
  resumePendingCommands(userId: string, profileId: string, botId: string): number {
    const pending = commandRepository.findPendingForBot(userId, profileId, botId);
    let resumedCount = 0;

    for (const cmd of pending) {
      const delivered = eventHub.dispatchToBot(profileId, {
        type: 'EXECUTE_COMMAND',
        commandId: cmd.id,
        commandType: cmd.command_type,
        profileId: cmd.profile_id,
        payload: cmd.payload,
        conversationId: cmd.conversation_id,
        messageId: cmd.message_id,
        resumed: true,
      });
      if (delivered) {
        commandRepository.markDispatched(cmd.id);
        resumedCount++;
      }
    }

    if (resumedCount > 0) {
      logger.info(`Resumed ${resumedCount} pending command(s) for profile [${profileId}] after bot reconnect`);
    }

    return resumedCount;
  }

  /**
   * Called the moment a bot's WebSocket connection actually closes (not superseded by a newer
   * one) — an immediate, event-driven complement to the periodic heartbeat-timeout auditor.
   * A clean/explicit disconnect no longer has to wait up to the full heartbeat timeout before
   * the profile is shown as OFFLINE.
   */
  handleBotDisconnect(userId: string, profileId: string): void {
    const profile = profileRepository.findById(profileId, userId);
    if (!profile || profile.status === 'OFFLINE') return;

    profileRepository.updateProfile(profileId, userId, {
      status: 'OFFLINE',
      current_task: 'Desktop Bot Disconnected',
      bot_connected: 0,
    });

    eventHub.publish({
      eventId: `evt_${uuidv4().substring(0, 10)}`,
      userId,
      eventType: 'BOT_HEARTBEAT',
      aggregateType: 'profile',
      aggregateId: profileId,
      payload: {
        profileId,
        botId: profile.bot_id || '',
        status: 'OFFLINE',
        currentTask: 'Desktop Bot Disconnected',
        botVersion: '',
        timestamp: Date.now(),
        pendingCommandsCount: 0,
      },
    });
  }
}

export const botService = new BotService();
