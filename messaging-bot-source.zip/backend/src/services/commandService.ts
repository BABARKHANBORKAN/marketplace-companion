import { v4 as uuidv4 } from 'uuid';
import { commandRepository } from '../repositories/commandRepository';
import { profileRepository } from '../repositories/profileRepository';
import { messageRepository } from '../repositories/messageRepository';
import { eventHub } from '../websocket/eventHub';
import { ApiError } from '../utils/errors';
import { CommandResponse } from '../types';

export class CommandService {
  dispatchCommand(
    userId: string,
    data: {
      commandId?: string;
      idempotencyKey?: string;
      profileId: string;
      type: string;
      payload?: string;
      conversationId?: string;
      customerId?: string;
      listingId?: string;
      messageId?: string;
    }
  ): CommandResponse {
    const { profileId, type, idempotencyKey, commandId } = data;
    if (!profileId || !type) {
      throw ApiError.badRequest('Profile ID and command type are required');
    }

    // Verify profile ownership
    const profile = profileRepository.findById(profileId, userId);
    if (!profile) {
      throw ApiError.notFound('Chrome profile not found');
    }

    // Idempotency check by key
    if (idempotencyKey) {
      const existing = commandRepository.findByIdempotencyKey(userId, idempotencyKey);
      if (existing) {
        return commandRepository.toResponse(existing);
      }
    }

    // Check by commandId
    if (commandId) {
      const existing = commandRepository.findById(commandId, userId);
      if (existing) {
        return commandRepository.toResponse(existing);
      }
    }

    const effectiveId = commandId || `cmd_${uuidv4().substring(0, 10)}`;
    const created = commandRepository.createCommand({
      id: effectiveId,
      userId,
      profileId,
      conversationId: data.conversationId,
      customerId: data.customerId,
      listingId: data.listingId,
      messageId: data.messageId,
      commandType: type,
      payload: data.payload || '{}',
      status: 'PENDING',
      idempotencyKey: idempotencyKey || null,
    });

    // Notify connected Desktop Bot (push wake-up; command remains PENDING until the bot claims it)
    const delivered = eventHub.dispatchToBot(profileId, {
      type: 'EXECUTE_COMMAND',
      commandId: created.id,
      commandType: created.command_type,
      profileId: created.profile_id,
      payload: created.payload,
      conversationId: created.conversation_id,
      messageId: created.message_id,
    });
    if (delivered) {
      commandRepository.markDispatched(created.id);
    }

    return {
      id: created.id,
      idempotency_key: created.idempotency_key,
      status: created.status,
      result_message: `Command ${type} queued for bot execution`,
      completed_at: null,
    };
  }

  getCommand(userId: string, id: string): CommandResponse {
    const cmd = commandRepository.findById(id, userId);
    if (!cmd) {
      throw ApiError.notFound('Command not found');
    }
    return commandRepository.toResponse(cmd);
  }

  updateCommandStatus(
    scope: { userId: string; profileId: string; botId: string },
    commandId: string,
    status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED',
    resultMessage?: string | null,
    errorCode?: string | null,
    errorMessage?: string | null
  ): CommandResponse {
    const updated = commandRepository.updateStatus(
      commandId,
      scope,
      status,
      resultMessage,
      status === 'COMPLETED' ? Date.now() : null,
      errorCode,
      errorMessage
    );

    if (!updated) {
      throw ApiError.notFound('Command not found');
    }

    // If message linked, update message status
    if (updated.message_id) {
      const msgStatus = status === 'COMPLETED' ? 'SENT' : (status === 'FAILED' ? 'FAILED' : 'PROCESSING');
      messageRepository.updateStatus(updated.message_id, updated.user_id, msgStatus);

      eventHub.publish({
        eventId: `evt_${uuidv4().substring(0, 10)}`,
        userId: updated.user_id,
        eventType: 'MESSAGE_STATUS_UPDATE',
        aggregateType: 'message',
        aggregateId: updated.message_id,
        payload: {
          messageId: updated.message_id,
          status: msgStatus,
          commandId,
          timestamp: Date.now(),
        },
      });
    }

    eventHub.publish({
      eventId: `evt_${uuidv4().substring(0, 10)}`,
      userId: updated.user_id,
      eventType: 'COMMAND_STATUS_UPDATE',
      aggregateType: 'command',
      aggregateId: commandId,
      payload: {
        commandId,
        status,
        resultMessage: updated.result_message,
        completedAt: updated.completed_at,
        errorCode: updated.error_code,
        errorMessage: updated.error_message,
      },
    });

    return commandRepository.toResponse(updated);
  }

  /**
   * System-initiated recovery for commands a bot claimed (PROCESSING) and never finished —
   * called periodically from the server's audit interval, not from any bot-authenticated route.
   * Reuses the same message-linking and event-publishing shape as updateCommandStatus so clients
   * see a recovered command exactly the way they'd see any other status change.
   */
  recoverStaleCommands(cutoffTimestamp: number): number {
    const recovered = commandRepository.recoverStaleProcessingCommands(cutoffTimestamp);

    for (const cmd of recovered) {
      if (cmd.message_id) {
        const msgStatus = cmd.status === 'FAILED' ? 'FAILED' : 'PENDING';
        messageRepository.updateStatus(cmd.message_id, cmd.user_id, msgStatus);

        eventHub.publish({
          eventId: `evt_${uuidv4().substring(0, 10)}`,
          userId: cmd.user_id,
          eventType: 'MESSAGE_STATUS_UPDATE',
          aggregateType: 'message',
          aggregateId: cmd.message_id,
          payload: {
            messageId: cmd.message_id,
            status: msgStatus,
            commandId: cmd.id,
            timestamp: Date.now(),
          },
        });
      }

      eventHub.publish({
        eventId: `evt_${uuidv4().substring(0, 10)}`,
        userId: cmd.user_id,
        eventType: 'COMMAND_STATUS_UPDATE',
        aggregateType: 'command',
        aggregateId: cmd.id,
        payload: {
          commandId: cmd.id,
          status: cmd.status,
          resultMessage: cmd.result_message,
          completedAt: cmd.completed_at,
          errorCode: cmd.error_code,
          errorMessage: cmd.error_message,
        },
      });
    }

    return recovered.length;
  }
}

export const commandService = new CommandService();
