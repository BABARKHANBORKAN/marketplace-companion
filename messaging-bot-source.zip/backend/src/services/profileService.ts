import { v4 as uuidv4 } from 'uuid';
import { profileRepository } from '../repositories/profileRepository';
import { commandRepository } from '../repositories/commandRepository';
import { botService } from './botService';
import { ApiError } from '../utils/errors';
import { ChromeProfileDto } from '../types';
import { eventHub } from '../websocket/eventHub';

export class ProfileService {
  listProfiles(userId: string): ChromeProfileDto[] {
    const profiles = profileRepository.findByUserId(userId);
    return profiles.map(p => this.toDto(p));
  }

  getProfile(userId: string, id: string): ChromeProfileDto {
    const profile = profileRepository.findById(id, userId);
    if (!profile) {
      throw ApiError.notFound('Chrome profile not found');
    }
    return this.toDto(profile);
  }

  createProfile(userId: string, name: string, accountLabel: string): ChromeProfileDto {
    if (!name || !accountLabel) {
      throw ApiError.badRequest('Profile name and account label are required');
    }

    const id = `profile_${uuidv4().substring(0, 8)}`;
    const profile = profileRepository.createProfile({
      id,
      userId,
      name,
      accountLabel,
    });

    const dto = this.toDto(profile);

    // Record the creation in the event log so cursor-based delta sync (and any other connected
    // device for this user) picks it up without relying on a broader timestamp scan.
    eventHub.publish({
      eventId: `evt_${uuidv4().substring(0, 10)}`,
      userId,
      eventType: 'PROFILE_CREATED',
      aggregateType: 'profile',
      aggregateId: profile.id,
      payload: dto,
    });

    return dto;
  }

  deleteProfile(userId: string, id: string): void {
    // Neither bot_api_keys nor commands cascade from chrome_profiles (no FK relationship), so a
    // plain profile delete would leave a dangling-but-ACTIVE bot key and orphaned queued commands
    // behind. Clean both up first — order doesn't matter for FK correctness here since neither
    // references chrome_profiles, but doing it before confirms profile ownership via the same
    // userId scoping before any destructive action runs.
    botService.deleteKeysForProfile(userId, id);
    commandRepository.deleteByProfile(id, userId);

    const success = profileRepository.deleteProfile(id, userId);
    if (!success) {
      throw ApiError.notFound('Chrome profile not found');
    }
  }

  private toDto(p: any): ChromeProfileDto {
    return {
      id: p.id,
      user_id: p.user_id,
      name: p.name,
      account_label: p.account_label,
      status: p.status,
      current_task: p.current_task,
      last_seen: p.last_seen,
      last_heartbeat: p.last_heartbeat,
      listing_count: p.listing_count,
      conversation_count: p.conversation_count,
      unread_count: p.unread_count,
      chrome_window_name: p.chrome_window_name,
      bot_connected: Boolean(p.bot_connected),
    };
  }
}

export const profileService = new ProfileService();
