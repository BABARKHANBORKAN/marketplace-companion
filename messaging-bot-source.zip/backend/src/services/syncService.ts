import { profileRepository } from '../repositories/profileRepository';
import { conversationRepository } from '../repositories/conversationRepository';
import { messageRepository } from '../repositories/messageRepository';
import { listingRepository } from '../repositories/listingRepository';
import { commandRepository } from '../repositories/commandRepository';
import { eventRepository } from '../repositories/eventRepository';
import { encodeCursor, decodeCursor } from '../utils/crypto';
import { DeltaSyncResponse, ChromeProfileDto, ListingDto, MessageDto, ChromeProfile, Listing, Message } from '../types';

// Cap on how many event-log rows a single cursor sync will scan. If more events than this are
// pending, has_more is set so the client re-syncs with the freshest cursor and drains the backlog
// over a few calls instead of one unbounded query.
const CURSOR_EVENT_BATCH_LIMIT = 500;

export class SyncService {
  deltaSync(userId: string, cursorStr?: string, sinceTimestamp?: number): DeltaSyncResponse {
    const serverTime = Date.now();

    // A cursor always represents the backend event sequence and takes priority when supplied.
    // `since` (a plain timestamp) is a fallback the Android client uses only when it has no
    // cursor yet (e.g. right after an app restart, before the first sync of this session).
    if (cursorStr) {
      return this.cursorBasedSync(userId, cursorStr, serverTime);
    }

    return this.timestampBasedSync(userId, sinceTimestamp, serverTime);
  }

  /**
   * Real cursor-based delta sync: returns only the aggregates touched by events strictly after
   * the decoded sequence number, and advances the cursor to the latest sequence actually seen.
   */
  private cursorBasedSync(userId: string, cursorStr: string, serverTime: number): DeltaSyncResponse {
    const fromSeq = decodeCursor(cursorStr);
    const events = eventRepository.findEventsSince(userId, fromSeq, CURSOR_EVENT_BATCH_LIMIT);

    const profileIds = new Set<string>();
    const listingIds = new Set<string>();
    const conversationIds = new Set<string>();
    const commandIds = new Set<string>();
    const messageIds = new Set<string>();

    for (const ev of events) {
      switch (ev.aggregate_type) {
        case 'profile':
          profileIds.add(ev.aggregate_id);
          break;
        case 'listing':
          listingIds.add(ev.aggregate_id);
          break;
        case 'conversation':
          conversationIds.add(ev.aggregate_id);
          break;
        case 'command':
          commandIds.add(ev.aggregate_id);
          break;
        case 'message':
          messageIds.add(ev.aggregate_id);
          break;
      }
    }

    const profileDtos: ChromeProfileDto[] = [...profileIds]
      .map(id => profileRepository.findById(id, userId))
      .filter((p): p is ChromeProfile => p !== null)
      .map(toProfileDto);

    const listingDtos: ListingDto[] = [...listingIds]
      .map(id => listingRepository.findById(id, userId))
      .filter((l): l is Listing => l !== null)
      .map(toListingDto);

    // Conversations touched (dataset is bounded to this user's own conversations, consistent
    // with how the rest of this service already fetches them).
    const allConversations = conversationRepository.findByUserId(userId);
    const convDtos = allConversations.filter(c => conversationIds.has(c.id));

    // Messages: a true minimal delta. A NEW_MESSAGE event's own payload already IS the full
    // message (id, conversationId, sender, text, status, timestamp) — read it straight from the
    // event log instead of re-querying the conversation's entire history just because one
    // message in it changed. Only a status-only update (MESSAGE_STATUS_UPDATE, whose payload
    // doesn't carry the message text) needs an actual single-row lookup.
    const recentMessages: MessageDto[] = [];
    const seenMessageIds = new Set<string>();
    for (const ev of events) {
      if (ev.event_type !== 'NEW_MESSAGE') continue;
      try {
        const payload = JSON.parse(ev.payload);
        if (payload.id && !seenMessageIds.has(payload.id)) {
          seenMessageIds.add(payload.id);
          recentMessages.push({
            id: payload.id,
            conversation_id: payload.conversationId,
            sender: payload.sender,
            text: payload.text,
            status: payload.status,
            timestamp: payload.timestamp,
          });
        }
      } catch {
        // Malformed payload should never happen (we control every writer) — skip rather than fail the whole sync
      }
    }
    for (const msgId of messageIds) {
      if (seenMessageIds.has(msgId)) continue;
      const m = messageRepository.findById(msgId, userId);
      if (m) {
        seenMessageIds.add(msgId);
        recentMessages.push(toMessageDto(m));
      }
    }

    const completedCommands = [...commandIds]
      .map(id => commandRepository.findById(id, userId))
      .filter((c): c is NonNullable<typeof c> => c !== null && (c.status === 'COMPLETED' || c.status === 'FAILED' || c.status === 'CANCELLED'))
      .map(c => commandRepository.toResponse(c));

    // Advance the cursor to the latest sequence actually observed in this batch (not the global
    // latest), so a client that only received a partial batch (has_more) resumes exactly where
    // it left off instead of skipping events still pending beyond CURSOR_EVENT_BATCH_LIMIT.
    const latestSeqInBatch = events.length > 0 ? events[events.length - 1].sequence : fromSeq;
    const nextCursor = encodeCursor(latestSeqInBatch);

    return {
      profiles: profileDtos,
      conversations: convDtos,
      messages: recentMessages,
      listings: listingDtos,
      completed_commands: completedCommands,
      cursor: nextCursor,
      has_more: events.length >= CURSOR_EVENT_BATCH_LIMIT,
      server_time: serverTime,
    };
  }

  /**
   * Legacy/fallback path used only for a true initial sync (no cursor, no timestamp) or when the
   * client has a persisted lastSyncTime but no cursor yet. Preserved as-is for backward
   * compatibility with the existing Android calling convention.
   */
  private timestampBasedSync(userId: string, sinceTimestamp: number | undefined, serverTime: number): DeltaSyncResponse {
    const latestSeq = eventRepository.getLatestSequence(userId);
    const isInitialSync = !sinceTimestamp;
    const sinceTime = sinceTimestamp || 0;

    const allProfiles = profileRepository.findByUserId(userId);
    const profileDtos: ChromeProfileDto[] = allProfiles
      .filter(p => isInitialSync || p.updated_at >= sinceTime)
      .map(toProfileDto);

    const allConversations = conversationRepository.findByUserId(userId);
    const convDtos = isInitialSync
      ? allConversations
      : allConversations.filter(c => c.last_message_at >= sinceTime);

    const allListings = listingRepository.findByUserId(userId);
    const listingDtos: ListingDto[] = allListings
      .filter(l => isInitialSync || l.updated_at >= sinceTime)
      .map(toListingDto);

    const recentMessages: MessageDto[] = [];
    for (const conv of allConversations) {
      const msgs = messageRepository.findByConversationId(conv.id, userId);
      const filtered = isInitialSync ? msgs : msgs.filter(m => m.timestamp >= sinceTime);
      recentMessages.push(...filtered);
    }

    const terminalCommands = commandRepository.findTerminalByUserId(userId);
    const completedCommands = terminalCommands
      .filter(c => isInitialSync || c.updated_at >= sinceTime)
      .map(c => commandRepository.toResponse(c));

    const nextCursor = encodeCursor(latestSeq);

    return {
      profiles: profileDtos,
      conversations: convDtos,
      messages: recentMessages,
      listings: listingDtos,
      completed_commands: completedCommands,
      cursor: nextCursor,
      has_more: false,
      server_time: serverTime,
    };
  }
}

function toProfileDto(p: ChromeProfile): ChromeProfileDto {
  return {
    id: p.id,
    user_id: p.user_id,
    name: p.name,
    account_label: p.account_label,
    status: p.status,
    current_task: p.current_task,
    last_seen: p.last_seen,
    last_heartbeat: p.last_heartbeat,
    listing_count: p.listing_count,
    conversation_count: p.conversation_count,
    unread_count: p.unread_count,
    chrome_window_name: p.chrome_window_name,
    bot_connected: Boolean(p.bot_connected),
  };
}

function toListingDto(l: Listing): ListingDto {
  return {
    id: l.id,
    profile_id: l.profile_id,
    title: l.title,
    price: l.price,
    currency: l.currency,
    status: l.status,
    category: l.category,
    description: l.description,
    location: l.location,
    conversation_count: l.conversation_count,
    message_count: l.message_count,
    created_at: l.created_at,
    image_url: l.image_url,
  };
}

function toMessageDto(m: Message): MessageDto {
  return {
    id: m.id,
    conversation_id: m.conversation_id,
    sender: m.sender,
    text: m.text,
    status: m.status,
    timestamp: m.timestamp,
    command_id: m.command_id,
    idempotency_key: m.idempotency_key,
  };
}

export const syncService = new SyncService();
