import http from 'http';
import { createApp } from './app';
import { getDatabase, closeDatabase } from './db/database';
import { setupWebSocketServer } from './websocket/wsServer';
import { config } from './config/env';
import { logger } from './utils/logger';
import { botRepository } from './repositories/botRepository';
import { profileRepository } from './repositories/profileRepository';
import { commandService } from './services/commandService';

export function startServer() {
  // 1. Initialize SQLite Database & apply migrations
  logger.info('Initializing SQLite database and applying migrations...');
  const db = getDatabase();
  logger.info('Database initialized successfully.');

  // 2. Create Express app
  const app = createApp();

  // 3. Create HTTP server
  const server = http.createServer(app);

  // 4. Attach WebSocket Server
  const wss = setupWebSocketServer(server);
  logger.info('WebSocket server attached to /api/v1/events');

  // 5. Periodic Heartbeat Audit (every 30 seconds)
  const auditInterval = setInterval(() => {
    const cutoff = Date.now() - config.botHeartbeatTimeoutMs;
    const botCount = botRepository.markStaleBotsOffline(cutoff);
    if (botCount > 0) {
      logger.info(`Heartbeat auditor: Marked ${botCount} stale bot(s) OFFLINE`);
    }
    const profileCount = profileRepository.markStaleProfilesOffline(cutoff);
    if (profileCount > 0) {
      logger.info(`Heartbeat auditor: Marked ${profileCount} stale profile(s) OFFLINE`);
    }

    const commandCutoff = Date.now() - config.commandProcessingTimeoutMs;
    const recoveredCount = commandService.recoverStaleCommands(commandCutoff);
    if (recoveredCount > 0) {
      logger.info(`Command auditor: Recovered ${recoveredCount} stale PROCESSING command(s)`);
    }
  }, 30000);

  // 6. Listen on configured port
  server.listen(config.port, config.host, () => {
    logger.info(`Marketplace Companion Production Backend listening on http://${config.host}:${config.port}`);
  });

  // Graceful shutdown
  const shutdown = () => {
    logger.info('Shutting down server gracefully...');
    clearInterval(auditInterval);
    wss.close(() => {
      server.close(() => {
        closeDatabase();
        logger.info('Server closed. Database connections released.');
        process.exit(0);
      });
    });
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  return { server, wss, db };
}

// Run directly if invoked as main module
if (require.main === module) {
  startServer();
}
