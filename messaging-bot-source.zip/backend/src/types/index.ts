export interface User {
  id: string;
  email: string;
  password_hash: string;
  name: string;
  plan: string;
  status: string;
  created_at: number;
  updated_at: number;
}

export interface UserDto {
  id: string;
  name: string;
  email: string;
  plan: string;
}

export interface AuthResponse {
  accessToken: string;
  token: string;
  refreshToken: string;
  refresh_token: string;
  expiresIn: number;
  user: UserDto;
}

export interface RefreshSession {
  id: string;
  user_id: string;
  refresh_token_hash: string;
  device_info: string | null;
  expires_at: number;
  revoked_at: number | null;
  created_at: number;
}

export interface Bot {
  id: string;
  user_id: string;
  name: string;
  status: 'ONLINE' | 'OFFLINE' | 'BUSY';
  current_task: string;
  version: string;
  last_heartbeat_at: number | null;
  created_at: number;
  updated_at: number;
}

export interface BotApiKey {
  id: string;
  bot_id: string;
  user_id: string;
  profile_id: string;
  key_hash: string;
  key_prefix: string;
  key_last_four: string;
  server_url: string;
  status: 'ACTIVE' | 'REVOKED' | 'EXPIRED';
  last_used_at: number | null;
  revoked_at: number | null;
  created_at: number;
}

export interface BotConnectionDto {
  id: string;
  profile_id: string;
  masked_key: string;
  api_key?: string; // only present upon creation
  server_url: string;
  status: string;
  last_heartbeat: number;
  bot_version: string;
  created_at: number;
}

export interface ChromeProfile {
  id: string;
  user_id: string;
  bot_id: string | null;
  name: string;
  account_label: string;
  status: 'ONLINE' | 'OFFLINE' | 'BUSY';
  current_task: string;
  last_seen: number;
  last_heartbeat: number;
  listing_count: number;
  conversation_count: number;
  unread_count: number;
  chrome_window_name: string;
  bot_connected: number;
  created_at: number;
  updated_at: number;
}

export interface ChromeProfileDto {
  id: string;
  user_id?: string;
  name: string;
  account_label: string;
  status: string;
  current_task: string;
  last_seen: number;
  last_heartbeat: number;
  listing_count: number;
  conversation_count: number;
  unread_count: number;
  chrome_window_name: string;
  bot_connected: boolean;
}

export interface Listing {
  id: string;
  user_id: string;
  profile_id: string;
  external_listing_id: string | null;
  title: string;
  price: number;
  currency: string;
  status: 'ACTIVE' | 'PENDING_SYNC' | 'INACTIVE' | 'SOLD';
  category: string;
  description: string;
  location: string;
  conversation_count: number;
  message_count: number;
  image_url: string;
  created_at: number;
  updated_at: number;
}

export interface ListingDto {
  id: string;
  profile_id: string;
  title: string;
  price: number;
  currency: string;
  status: string;
  category: string;
  description: string;
  location: string;
  conversation_count: number;
  message_count: number;
  created_at: number;
  image_url: string;
}

export interface Customer {
  id: string;
  user_id: string;
  external_customer_id: string;
  name: string;
  avatar_url: string;
  created_at: number;
  updated_at: number;
}

export interface Conversation {
  id: string;
  user_id: string;
  profile_id: string;
  listing_id: string;
  customer_id: string;
  status: string;
  unread_count: number;
  last_message: string;
  last_message_at: number;
  is_pinned: number;
  created_at: number;
  updated_at: number;
}

export interface ConversationDto {
  id: string;
  profile_id: string;
  customer_id: string;
  customer_name?: string;
  listing_id: string;
  listing_title?: string;
  unread_count: number;
  last_message: string;
  last_message_at: number;
  is_pinned: boolean;
}

export interface Message {
  id: string;
  user_id: string;
  conversation_id: string;
  client_message_id: string | null;
  external_message_id: string | null;
  command_id: string | null;
  idempotency_key: string | null;
  sender: 'CUSTOMER' | 'USER_APP' | 'BOT_AUTO';
  text: string;
  status: 'PENDING' | 'PROCESSING' | 'SENT' | 'FAILED' | 'CANCELLED';
  timestamp: number;
  created_at: number;
  updated_at: number;
}

export interface MessageDto {
  id: string;
  conversation_id: string;
  sender: string;
  text: string;
  status: string;
  timestamp: number;
  command_id?: string | null;
  idempotency_key?: string | null;
}

export interface Command {
  id: string;
  user_id: string;
  bot_id: string | null;
  profile_id: string;
  conversation_id: string;
  customer_id: string;
  listing_id: string;
  message_id: string;
  command_type: string;
  payload: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  idempotency_key: string | null;
  attempts: number;
  max_retries: number;
  error_code: string | null;
  error_message: string | null;
  result_message: string | null;
  completed_at: number | null;
  dispatched_at: number | null;
  created_at: number;
  updated_at: number;
}

export interface CommandResponse {
  id: string;
  idempotency_key?: string | null;
  status: string;
  result_message?: string | null;
  completed_at?: number | null;
  error_code?: string | null;
  error_message?: string | null;
}

export interface EventRecord {
  sequence: number;
  event_id: string;
  user_id: string;
  event_type: 'NEW_MESSAGE' | 'MESSAGE_STATUS_UPDATE' | 'BOT_HEARTBEAT' | 'COMMAND_STATUS_UPDATE' | 'PROFILE_CREATED' | 'LISTING_CREATED';
  aggregate_type: 'conversation' | 'message' | 'profile' | 'bot' | 'command' | 'listing';
  aggregate_id: string;
  payload: string;
  created_at: number;
}

export interface InboundEventDto {
  eventId: string;
  id?: string;
  eventType: string;
  type?: string;
  userId?: string;
  aggregateType?: string;
  aggregateId?: string;
  cursor?: string;
  payload: string; // JSON-stringified object
  timestamp: number;
}

export interface DeltaSyncResponse {
  profiles: ChromeProfileDto[];
  conversations: ConversationDto[];
  messages: MessageDto[];
  listings: ListingDto[];
  completed_commands: CommandResponse[];
  cursor: string;
  has_more: boolean;
  server_time: number;
}

export interface SecurityEvent {
  id: string;
  event_type: string;
  user_id: string | null;
  bot_id: string | null;
  key_id: string | null;
  ip_address: string | null;
  detail: string | null;
  created_at: number;
}

export interface ApiErrorResponse {
  error: {
    code: string;
    message: string;
    requestId?: string;
    details?: any;
  };
}
