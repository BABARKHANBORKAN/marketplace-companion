import { Server as HttpServer, IncomingMessage } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { verifyAccessToken } from '../utils/jwt';
import { hashBotApiKey } from '../utils/crypto';
import { getDatabase } from '../db/database';
import { eventHub } from './eventHub';
import { commandService } from '../services/commandService';
import { botService } from '../services/botService';
import { logger } from '../utils/logger';
import { securityAuditRepository } from '../repositories/securityAuditRepository';

interface AuthenticatedSocket extends WebSocket {
  isAlive: boolean;
  userId?: string;
  botId?: string;
  profileId?: string;
  keyId?: string;
}

export function setupWebSocketServer(server: HttpServer): WebSocketServer {
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (req: IncomingMessage, socket, head) => {
    const url = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    if (pathname !== '/api/v1/events' && pathname !== '/api/v1/bot/ws') {
      socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
      socket.destroy();
      return;
    }

    let authHeader = req.headers['authorization'];
    let bearerToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : null;
    // Bot authentication uses exactly one convention everywhere (HTTP and WebSocket):
    // Authorization: Bearer mpc_live_... — no alternate header, and never a query string
    // (?botKey=...), since URLs are logged by proxies, servers, and browser history.

    // 1. Try User JWT Authentication
    if (bearerToken && !bearerToken.startsWith('mpc_')) {
      const userPayload = verifyAccessToken(bearerToken);
      if (userPayload) {
        wss.handleUpgrade(req, socket, head, (ws) => {
          const authWs = ws as AuthenticatedSocket;
          authWs.isAlive = true;
          authWs.userId = userPayload.userId;
          const accepted = eventHub.registerUserClient(userPayload.userId, authWs);
          if (!accepted) {
            authWs.close(4008, 'Too many connections for this user');
            return;
          }
          setupSocketHeartbeat(authWs);
        });
        return;
      }
    }

    // 2. Try Bot Key Authentication
    const botKey = bearerToken && bearerToken.startsWith('mpc_') ? bearerToken : null;
    if (botKey) {
      const keyHash = hashBotApiKey(botKey);
      const db = getDatabase();
      const botRow = db.prepare(`
        SELECT id, bot_id, user_id, profile_id, status
        FROM bot_api_keys
        WHERE key_hash = ? AND status = 'ACTIVE'
      `).get(keyHash) as { id: string; bot_id: string; user_id: string; profile_id: string } | undefined;

      if (botRow) {
        wss.handleUpgrade(req, socket, head, (ws) => {
          const authWs = ws as AuthenticatedSocket;
          authWs.isAlive = true;
          authWs.userId = botRow.user_id;
          authWs.botId = botRow.bot_id;
          authWs.profileId = botRow.profile_id;
          authWs.keyId = botRow.id;

          eventHub.registerBotClient(botRow.profile_id, botRow.id, authWs, () => {
            // Fires only for a REAL disconnect (not one superseded by a newer connection) —
            // brings the profile OFFLINE immediately instead of waiting for the heartbeat
            // timeout auditor to notice.
            botService.handleBotDisconnect(botRow.user_id, botRow.profile_id);
          });
          setupBotSocket(authWs);

          // Reconnect handling: a fresh connection is exactly as good as an explicit heartbeat
          // (it proves the bot is alive and authenticated again), so treat it as one — this
          // restores ONLINE state without waiting for the bot to separately call /heartbeat.
          // Then push anything this bot still owes so it can safely resume pending work.
          try {
            botService.recordHeartbeat({
              userId: botRow.user_id,
              profileId: botRow.profile_id,
              botId: botRow.bot_id,
              status: 'ONLINE',
              currentTask: 'Reconnected',
            });
            botService.resumePendingCommands(botRow.user_id, botRow.profile_id, botRow.bot_id);
          } catch (e) {
            logger.warn(`Failed to process bot reconnect for profile [${botRow.profile_id}]: ${e}`);
          }
        });
        return;
      }
    }

    // Unauthorized
    if (botKey) {
      securityAuditRepository.log({
        eventType: 'BOT_AUTH_INVALID_KEY',
        ipAddress: req.socket.remoteAddress || null,
        detail: `WebSocket upgrade ${pathname}`,
      });
    }
    socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
    socket.destroy();
  });

  // Setup periodic ping/pong
  const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
      const authWs = ws as AuthenticatedSocket;
      if (!authWs.isAlive) {
        return authWs.terminate();
      }
      authWs.isAlive = false;
      authWs.ping();
    });
  }, 30000);

  wss.on('close', () => clearInterval(interval));

  return wss;
}

function setupSocketHeartbeat(ws: AuthenticatedSocket): void {
  ws.on('pong', () => {
    ws.isAlive = true;
  });
}

function setupBotSocket(ws: AuthenticatedSocket): void {
  ws.on('pong', () => {
    ws.isAlive = true;
  });

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString('utf-8'));
      handleBotInboundMessage(ws, msg);
    } catch (e) {
      logger.warn(`Invalid JSON from bot socket: ${e}`);
    }
  });
}

function handleBotInboundMessage(ws: AuthenticatedSocket, msg: any): void {
  const userId = ws.userId;
  const profileId = ws.profileId;
  const botId = ws.botId;
  if (!userId || !profileId || !botId) return;

  const type = msg.type || msg.eventType;

  if (type === 'COMMAND_STATUS') {
    const { commandId, status, resultMessage, errorCode, errorMessage } = msg;
    if (!commandId || !status) return;

    // Delegates to commandService so the same (user, profile, bot) scoping and
    // event-publishing logic applies here as it does on the HTTP status route.
    try {
      commandService.updateCommandStatus(
        { userId, profileId, botId },
        commandId,
        status.toUpperCase(),
        resultMessage || `Command status updated to ${status.toUpperCase()}`,
        errorCode,
        errorMessage
      );
    } catch (e) {
      logger.warn(`Bot socket rejected COMMAND_STATUS for ${commandId}: ${e}`);
    }
  } else if (type === 'INCOMING_MESSAGE') {
    const { conversationId, customerId, customerName, text, externalMessageId } = msg;
    if (!text) return;

    // Delegates to botService so the same (user, profile) conversation-ownership check
    // applies here as it does on the HTTP /bot/messages route.
    try {
      botService.reportIncomingMessage({
        userId,
        profileId,
        conversationId,
        customerId,
        customerName,
        text,
        externalMessageId,
      });
    } catch (e) {
      logger.warn(`Bot socket rejected INCOMING_MESSAGE for conversation ${conversationId}: ${e}`);
    }
  }
}
