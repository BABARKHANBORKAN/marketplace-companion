import { WebSocket } from 'ws';
import { EventRecord, InboundEventDto } from '../types';
import { eventRepository } from '../repositories/eventRepository';
import { encodeCursor } from '../utils/crypto';
import { logger } from '../utils/logger';

// Caps concurrent WebSocket connections a single user can hold open (e.g. phone + tablet +
// a couple of stray/duplicate sessions is normal; unbounded growth is not).
const MAX_USER_CONNECTIONS = 8;

interface BotConnection {
  ws: WebSocket;
  keyId: string;
}

class EventHub {
  // userId -> Set<WebSocket> (Android user app connections; multiple devices per user is fine
  // since they only ever receive read-only events)
  private userClients = new Map<string, Set<WebSocket>>();

  // profileId -> { ws, keyId } (Desktop Bot connection; exactly ONE per profile). A command like
  // SEND_MESSAGE must be delivered to at most one bot process, or the same message could be
  // sent to Facebook Marketplace more than once by two connections racing each other. keyId is
  // tracked so a revoked API key can force-disconnect exactly the session it authenticated,
  // without guessing whether some OTHER still-valid key for the same profile is also connected.
  private botClients = new Map<string, BotConnection>();

  /**
   * Registers a user's WebSocket connection. Returns false (and does not register) if this user
   * is already at the connection cap — the caller must close the socket.
   */
  registerUserClient(userId: string, ws: WebSocket): boolean {
    const existingSet = this.userClients.get(userId);
    if (existingSet && existingSet.size >= MAX_USER_CONNECTIONS) {
      logger.warn(`Rejecting WebSocket connection for user [${userId}]: at connection limit (${MAX_USER_CONNECTIONS})`);
      return false;
    }

    if (!this.userClients.has(userId)) {
      this.userClients.set(userId, new Set());
    }
    this.userClients.get(userId)!.add(ws);
    logger.info(`User client connected [userId: ${userId}] (total: ${this.userClients.get(userId)!.size})`);

    ws.on('close', () => {
      const set = this.userClients.get(userId);
      if (set) {
        set.delete(ws);
        if (set.size === 0) this.userClients.delete(userId);
      }
      logger.info(`User client disconnected [userId: ${userId}]`);
    });

    return true;
  }

  /**
   * Registers a bot's WebSocket connection, evicting any existing connection for the same
   * profile first (only one bot process should ever be the live executor for a given Chrome
   * profile at a time). `onClose` fires only when THIS connection is the one actually closing
   * (not when it's being evicted by a newer one) — callers use it to react to a real disconnect,
   * e.g. marking the profile OFFLINE immediately rather than waiting for the heartbeat timeout.
   */
  registerBotClient(profileId: string, keyId: string, ws: WebSocket, onClose?: () => void): void {
    const existing = this.botClients.get(profileId);
    if (existing && existing.ws !== ws) {
      logger.warn(`Superseding existing bot connection for profile [${profileId}] with a new one`);
      try {
        existing.ws.close(4001, 'Replaced by a new bot connection for this profile');
      } catch (e) {
        logger.warn(`Failed to close superseded bot socket for profile [${profileId}]: ${e}`);
      }
    }

    this.botClients.set(profileId, { ws, keyId });
    logger.info(`Bot client connected [profileId: ${profileId}]`);

    ws.on('close', () => {
      // Only react if this socket is still the registered one — an even newer connection may
      // have already replaced it, and we must not evict/react to that one closing instead.
      const stillCurrent = this.botClients.get(profileId)?.ws === ws;
      if (stillCurrent) {
        this.botClients.delete(profileId);
      }
      logger.info(`Bot client disconnected [profileId: ${profileId}]`);
      if (stillCurrent && onClose) {
        onClose();
      }
    });
  }

  /**
   * Force-disconnects the live bot connection for a profile, but ONLY if it's still using the
   * given keyId — called right after a key is revoked/deleted. A profile with a different,
   * still-valid key connected is left alone.
   */
  disconnectBotKey(profileId: string, keyId: string): boolean {
    const conn = this.botClients.get(profileId);
    if (!conn || conn.keyId !== keyId) return false;

    logger.warn(`Disconnecting bot for profile [${profileId}]: its API key was revoked`);
    try {
      conn.ws.close(4003, 'API key revoked');
    } catch (e) {
      logger.warn(`Failed to close bot socket for profile [${profileId}] after key revocation: ${e}`);
    }
    return true;
  }

  isBotConnected(profileId: string): boolean {
    return this.botClients.has(profileId);
  }

  publish(event: {
    eventId: string;
    userId: string;
    eventType: EventRecord['event_type'];
    aggregateType: EventRecord['aggregate_type'];
    aggregateId: string;
    payload: string | object;
  }): EventRecord {
    const payloadStr = typeof event.payload === 'string' ? event.payload : JSON.stringify(event.payload);

    const record = eventRepository.createEvent({
      eventId: event.eventId,
      userId: event.userId,
      eventType: event.eventType,
      aggregateType: event.aggregateType,
      aggregateId: event.aggregateId,
      payload: payloadStr,
    });

    const inboundDto: InboundEventDto = {
      eventId: record.event_id,
      id: record.event_id,
      eventType: record.event_type,
      type: record.event_type,
      userId: record.user_id,
      aggregateType: record.aggregate_type,
      aggregateId: record.aggregate_id,
      cursor: encodeCursor(record.sequence),
      payload: payloadStr,
      timestamp: record.created_at,
    };

    const serialized = JSON.stringify(inboundDto);

    // Broadcast to user clients
    const clients = this.userClients.get(event.userId);
    if (clients) {
      for (const client of clients) {
        if (client.readyState === WebSocket.OPEN) {
          try {
            client.send(serialized);
          } catch (e) {
            logger.warn(`Failed to send event to user socket: ${e}`);
          }
        }
      }
    }

    return record;
  }

  dispatchToBot(profileId: string, message: object): boolean {
    const conn = this.botClients.get(profileId);
    if (!conn || conn.ws.readyState !== WebSocket.OPEN) return false;

    try {
      conn.ws.send(JSON.stringify(message));
      return true;
    } catch (e) {
      logger.warn(`Failed to dispatch command to bot socket for profile [${profileId}]: ${e}`);
      return false;
    }
  }
}

export const eventHub = new EventHub();
