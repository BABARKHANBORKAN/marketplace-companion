import { getDatabase, closeDatabase } from './database';

console.log('Running database migrations...');
try {
  const db = getDatabase();
  console.log('Database migrations applied successfully.');
  closeDatabase();
  process.exit(0);
} catch (error) {
  console.error('Migration failed:', error);
  process.exit(1);
}
