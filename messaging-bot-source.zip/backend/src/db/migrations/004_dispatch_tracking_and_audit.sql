-- Migration 004: Dispatch tracking + security audit log
--
-- dispatched_at records the last time a command was actually pushed over a live bot WebSocket
-- connection (as opposed to merely sitting PENDING waiting for the bot to poll for it). Nullable
-- because most of a command's life it hasn't been pushed yet, or was only ever picked up via
-- polling.

ALTER TABLE commands ADD COLUMN dispatched_at INTEGER;

-- Lightweight, append-only security audit trail for the events that actually matter for
-- incident review: failed bot/user authentication, key revocation, and cross-tenant rejections.
-- Deliberately narrow — this is not a general request log (that's requestLogger + logger.*),
-- just the subset worth being able to query specifically as "security events".
CREATE TABLE IF NOT EXISTS security_events (
    id TEXT PRIMARY KEY,
    event_type TEXT NOT NULL,
    user_id TEXT,
    bot_id TEXT,
    key_id TEXT,
    ip_address TEXT,
    detail TEXT,
    created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_security_events_created_at ON security_events(created_at);
CREATE INDEX IF NOT EXISTS idx_security_events_type ON security_events(event_type);
