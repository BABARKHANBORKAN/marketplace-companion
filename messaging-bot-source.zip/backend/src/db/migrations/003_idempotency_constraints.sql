-- Migration 003: Durable idempotency constraints
--
-- App-level check-then-insert already prevents duplicates for outgoing commands
-- (idempotency_key) and incoming bot-reported messages (external_message_id). These partial
-- unique indexes make that a real, DB-enforced guarantee rather than relying solely on
-- application logic: a bot that reconnects and replays the same report can never end up with
-- two rows for the same key, even if two processes ever wrote concurrently.
--
-- Partial (WHERE ... IS NOT NULL) because SQLite treats each NULL as distinct under a UNIQUE
-- index, and most rows legitimately have no key at all (only bot-reported/dispatched-with-a-key
-- rows do).

CREATE UNIQUE INDEX IF NOT EXISTS idx_commands_user_idempotency_unique
  ON commands(user_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_user_external_id_unique
  ON messages(user_id, external_message_id)
  WHERE external_message_id IS NOT NULL;
