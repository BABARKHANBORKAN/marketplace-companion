import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import { requestLogger } from './middleware/requestLogger';
import { rateLimiter } from './middleware/rateLimiter';
import { errorHandler } from './middleware/errorHandler';
import { config } from './config/env';

import authRoutes from './routes/authRoutes';
import profileRoutes from './routes/profileRoutes';
import commandRoutes from './routes/commandRoutes';
import conversationRoutes from './routes/conversationRoutes';
import listingRoutes from './routes/listingRoutes';
import apiKeyRoutes from './routes/apiKeyRoutes';
import botRoutes from './routes/botRoutes';
import syncRoutes from './routes/syncRoutes';

export function createApp(): Express {
  const app = express();

  // Basic security and parsing middlewares
  app.use(cors({
    origin: config.corsOrigins === '*' ? true : config.corsOrigins.split(','),
    credentials: true,
  }));
  app.use(express.json({ limit: '5mb' }));
  app.use(requestLogger);
  app.use(rateLimiter);

  // Health check endpoint
  app.get(['/health', '/api/v1/health'], (req: Request, res: Response) => {
    res.json({
      status: 'healthy',
      version: '1.0.0',
      uptime: process.uptime(),
      timestamp: Date.now(),
    });
  });

  // API v1 Routers
  app.use('/api/v1/auth', authRoutes);
  app.use('/api/v1/profiles', profileRoutes);
  app.use('/api/v1/commands', commandRoutes);
  app.use('/api/v1/conversations', conversationRoutes);
  app.use('/api/v1/listings', listingRoutes);
  app.use('/api/v1/api-keys', apiKeyRoutes);
  app.use('/api/v1/bot', botRoutes);
  app.use('/api/v1/bots', botRoutes);
  app.use('/api/v1/sync', syncRoutes);

  // Catch-all 404 for unhandled API routes
  app.use((req: Request, res: Response) => {
    res.status(404).json({
      error: {
        code: 'NOT_FOUND',
        message: `Endpoint ${req.method} ${req.originalUrl} not found`,
        requestId: req.id,
      },
    });
  });

  // Centralized error handler
  app.use(errorHandler);

  return app;
}
