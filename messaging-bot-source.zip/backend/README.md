# Marketplace Companion — Production Backend

A high-performance, hardened production backend built specifically for the **Marketplace Companion** Android application and Desktop Bot ecosystem.

---

## 1. Architecture Overview

- **Runtime**: Node.js (v22+) & Express 5
- **Language**: TypeScript (ES2022, strict type safety)
- **Database**: SQLite with WAL (Write-Ahead Logging) mode and foreign key constraints
- **Real-Time Communication**: WebSocket server on `/api/v1/events` and `/api/v1/bot/ws`
- **Security & Multi-Tenancy**: 
  - Complete multi-user tenant isolation across all resources
  - Scrypt password hashing with unique per-user salts
  - Bot API Key security: HMAC-SHA256 hashing with server-side pepper (plaintext keys are NEVER stored in the database)
  - Masked key presentation (`mpc_live_••••••••••••1234`)
  - Opaque base64url cursor synchronization
  - Strict command deduplication with idempotency keys

---

## 2. API Contract & Endpoints

### Authentication (`/api/v1/auth`)
| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/v1/auth/register` | Register new user (returns JWT access & refresh tokens) |
| `POST` | `/api/v1/auth/login` | Authenticate user with email and password |
| `POST` | `/api/v1/auth/refresh` | Rotate and issue new access & refresh tokens |
| `POST` | `/api/v1/auth/logout` | Revoke session / tokens |
| `GET` | `/api/v1/auth/me` | Fetch authenticated user profile |

### Chrome Profiles (`/api/v1/profiles`)
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/profiles` | List all profiles owned by user |
| `POST` | `/api/v1/profiles` | Create new profile mapping to Chrome desktop window |
| `GET` | `/api/v1/profiles/:id` | Fetch specific profile details |
| `DELETE` | `/api/v1/profiles/:id` | Delete profile and cascade dependencies |

### Commands (`/api/v1/commands`)
| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/v1/commands` | Dispatch command with idempotency key |
| `GET` | `/api/v1/commands/:id` | Poll command execution status |

### Conversations & Messages (`/api/v1/conversations`)
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/conversations` | List conversations with unread counts and customer names |
| `GET` | `/api/v1/conversations/:id/messages` | List chronologically sorted messages |
| `POST` | `/api/v1/conversations/:id/messages` | Send message (queues bot command with idempotency key) |

### Listings (`/api/v1/listings`)
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/listings` | List marketplace inventory items |
| `POST` | `/api/v1/listings` | Create listing associated with profile |
| `DELETE` | `/api/v1/listings/:id` | Remove listing |

### Bot Management & Communication (`/api/v1/bot` & `/api/v1/api-keys`)
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/api-keys` | List user's Bot API keys (masked) |
| `POST` | `/api/v1/api-keys` | Generate new API key (returns plaintext raw key ONCE) |
| `POST` | `/api/v1/api-keys/:id/revoke` | Revoke active API key |
| `POST` | `/api/v1/bot/heartbeat` | Bot heartbeat ping (updates status, returns pending command count) |
| `GET` | `/api/v1/bot/commands/pending` | Bot retrieves pending queued commands |
| `POST` | `/api/v1/bot/commands/:id/status` | Bot updates command status (`PROCESSING`, `COMPLETED`, `FAILED`) |
| `POST` | `/api/v1/bot/messages` | Bot reports incoming message from Facebook Marketplace |

### Delta Sync (`/api/v1/sync`)
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/sync?cursor=<opaque_cursor>&since=<timestamp>` | Fast cursor-based delta synchronization |

---

## 3. WebSocket Real-Time Event Stream

- Endpoint: `ws://<host>:<port>/api/v1/events`
- Authentication: `Authorization: Bearer <user_access_token>`
- Protocol: JSON DTOs matching Android's `InboundEventDto`
```json
{
  "eventId": "evt_98f4103a",
  "id": "evt_98f4103a",
  "eventType": "NEW_MESSAGE",
  "type": "NEW_MESSAGE",
  "userId": "usr_71829304",
  "aggregateType": "conversation",
  "aggregateId": "conv_12345",
  "cursor": "c2VxXzE0",
  "payload": "{\"text\":\"Hello!\",\"sender\":\"CUSTOMER\"}",
  "timestamp": 1726941200000
}
```

---

## 4. Running the Project

### Install dependencies
```bash
npm install
```

### Run Migrations
```bash
npm run migrate
```

### Build TypeScript
```bash
npm run build
```

### Run All Automated Tests
```bash
npm test
```

### Start Server
```bash
npm start
```
