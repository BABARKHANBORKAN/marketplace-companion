import assert from 'assert';
import WebSocket from 'ws';
import { createTestEnvironment, requestJson } from './test_helpers';
import { customerRepository } from '../src/repositories/customerRepository';
import { conversationRepository } from '../src/repositories/conversationRepository';

export async function runE2eLifecycleTests() {
  console.log('--- Running Full End-to-End Lifecycle Test ---');
  const env = await createTestEnvironment();

  try {
    // 1. User registers
    const regRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'e2e_seller@marketplace.local', password: 'Password123!', name: 'Alex Seller' },
    });
    assert.strictEqual(regRes.status, 201);
    const token = regRes.body.token;
    const userId = regRes.body.user.id;

    // 2. User creates Chrome Profile
    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Main E2E Profile', account_label: 'Alex Marketplace' },
    });
    assert.strictEqual(profileRes.status, 201);
    const profileId = profileRes.body.id;

    // 3. User generates Bot API Key
    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId, server_url: env.baseUrl },
    });
    assert.strictEqual(keyRes.status, 201);
    const rawBotKey = keyRes.body.api_key;
    assert.ok(rawBotKey);

    // 4. Android Client connects to WebSocket
    const userEvents: any[] = [];
    const userWs = new WebSocket(env.wsUrl, {
      headers: { Authorization: `Bearer ${token}` },
    });
    await new Promise<void>((resolve, reject) => {
      userWs.on('open', () => resolve());
      userWs.on('error', (err) => reject(err));
      userWs.on('message', (d) => userEvents.push(JSON.parse(d.toString('utf-8'))));
    });

    // 5. Desktop Bot sends heartbeat
    const hbRes = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: rawBotKey,
      body: {
        profile_id: profileId,
        bot_version: 'DesktopBot v2.4.1',
        status: 'ONLINE',
        current_task: 'Idle and listening',
        timestamp: Date.now(),
      },
    });
    assert.strictEqual(hbRes.status, 200);

    // 6. User creates Listing
    const listingRes = await requestJson(env.baseUrl, '/api/v1/listings', {
      method: 'POST',
      token,
      body: {
        profile_id: profileId,
        title: 'Canon EOS R5',
        price: 3200.0,
        category: 'Cameras',
        location: 'Seattle, WA',
      },
    });
    assert.strictEqual(listingRes.status, 201);
    const listingId = listingRes.body.id;

    // Setup conversation
    const customer = customerRepository.findOrCreateCustomer(userId, 'cust_ext_1', 'John Doe');
    const conversation = conversationRepository.createConversation({
      id: 'conv_e2e_1',
      userId,
      profileId,
      listingId,
      customerId: customer.id,
    });

    // 7. User sends outbound message
    const sendRes = await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, {
      method: 'POST',
      token,
      body: {
        text: 'Hello John, thanks for your inquiry!',
        command_id: 'cmd_msg_e2e_1',
        idempotency_key: 'idemp_e2e_1',
      },
    });
    assert.strictEqual(sendRes.status, 201);
    assert.strictEqual(sendRes.body.status, 'PROCESSING');

    // 8. Bot polls for pending command and confirms delivery
    const pendingCmds = await requestJson(env.baseUrl, '/api/v1/bot/commands/pending', {
      botKey: rawBotKey,
    });
    assert.strictEqual(pendingCmds.status, 200);
    assert.ok(pendingCmds.body.length >= 1);

    // Bot must claim (PROCESSING) before completing — the strict state machine rejects a
    // direct PENDING -> COMPLETED jump.
    const claimRes = await requestJson(env.baseUrl, `/api/v1/bot/commands/cmd_msg_e2e_1/status`, {
      method: 'POST',
      botKey: rawBotKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimRes.status, 200);

    const botConfirmRes = await requestJson(env.baseUrl, `/api/v1/bot/commands/cmd_msg_e2e_1/status`, {
      method: 'POST',
      botKey: rawBotKey,
      body: {
        status: 'COMPLETED',
        result_message: 'Message sent on Marketplace tab',
      },
    });
    assert.strictEqual(botConfirmRes.status, 200);

    // 9. Desktop Bot reports incoming message from customer
    const inMsgRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey: rawBotKey,
      body: {
        conversationId: conversation.id,
        text: 'Would you take $3000?',
      },
    });
    assert.strictEqual(inMsgRes.status, 201);

    // Wait brief moment for WebSocket delivery
    await new Promise((r) => setTimeout(r, 100));

    // Verify user received real-time NEW_MESSAGE events over WebSocket. The user's own outbound
    // message (step 7) is now ALSO published as an event (so a second connected device — or a
    // cursor-based delta sync — learns about it in real time), so there are two NEW_MESSAGE
    // events on this conversation by this point: the outbound one and the inbound one.
    const newMessageEvents = userEvents.filter((e) => e.eventType === 'NEW_MESSAGE' && e.aggregateId === conversation.id);
    assert.ok(newMessageEvents.length >= 2, 'User must receive real-time NEW_MESSAGE events for both the outbound and inbound message');

    const inMsgEvent = newMessageEvents.find((e) => JSON.parse(e.payload).text === 'Would you take $3000?');
    assert.ok(inMsgEvent, 'User must receive a real-time NEW_MESSAGE event for the inbound customer message');
    assert.strictEqual(inMsgEvent.aggregateId, conversation.id);

    const outMsgEvent = newMessageEvents.find((e) => JSON.parse(e.payload).text === 'Hello John, thanks for your inquiry!');
    assert.ok(outMsgEvent, "User's own device must also see its outbound message echoed back as a NEW_MESSAGE event");

    // 10. Delta Sync verifies client state alignment
    const syncRes = await requestJson(env.baseUrl, '/api/v1/sync', { token });
    assert.strictEqual(syncRes.status, 200);
    assert.ok(syncRes.body.cursor);
    assert.strictEqual(syncRes.body.profiles.length, 1);
    assert.strictEqual(syncRes.body.listings.length, 1);
    assert.strictEqual(syncRes.body.conversations.length, 1);
    assert.strictEqual(syncRes.body.messages.length, 2); // 1 outbound + 1 inbound

    userWs.close();
    console.log('✓ Full End-to-End Lifecycle test passed with flying colors!');
  } finally {
    await env.close();
  }
}
