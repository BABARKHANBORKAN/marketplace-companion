import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';
import { config } from '../src/config/env';

/**
 * Wraps the real global fetch so only calls aimed at the Supabase REST API are intercepted —
 * everything else (in particular requestJson's own calls to the local test server) passes
 * through untouched. Tests never hit the user's real Supabase project: the URL/config values
 * loaded from .env are real, but the actual network call here always short-circuits before
 * reaching the network.
 */
function installSupabaseFetchMock(handler: (url: string, init: RequestInit) => { status: number; body: any }) {
  const realFetch = global.fetch;
  global.fetch = (async (input: any, init?: any) => {
    const url = typeof input === 'string' ? input : input.url;
    if (url.includes('/rest/v1/')) {
      const { status, body } = handler(url, init);
      return {
        ok: status >= 200 && status < 300,
        status,
        statusText: status === 200 ? 'OK' : 'Error',
        json: async () => body,
      } as Response;
    }
    return realFetch(input, init);
  }) as typeof fetch;

  return () => {
    global.fetch = realFetch;
  };
}

export async function runAppsCodeAuthTests() {
  console.log('--- Running Apps Code Authentication Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. A missing code is rejected before any Supabase call is made
    const missingCodeRes = await requestJson(env.baseUrl, '/api/v1/auth/apps-code', {
      method: 'POST',
      body: {},
    });
    assert.strictEqual(missingCodeRes.status, 400, 'Missing code must be rejected with 400');

    // 2. A valid, active code redeems successfully and issues a completely normal session
    let restoreFetch = installSupabaseFetchMock(() => ({
      status: 200,
      body: [{ code: 'AX9482KP', is_active: false }], // non-empty = the PATCH actually flipped a row
    }));

    const validRes = await requestJson(env.baseUrl, '/api/v1/auth/apps-code', {
      method: 'POST',
      body: { code: 'ax94-82kp' }, // lowercase on purpose: matching must be case-insensitive
    });
    restoreFetch();

    assert.strictEqual(validRes.status, 200, 'A valid Apps Code must succeed');
    assert.ok(validRes.body.token, 'A valid login must return an access token');
    assert.ok(validRes.body.refreshToken, 'A valid login must return a refresh token');
    assert.strictEqual(validRes.body.user.email, config.appsCodeSharedAccountEmail, 'Apps Code login must use the configured shared account');
    const sharedUserId = validRes.body.user.id;

    // 3. That token is a genuinely working session — not a special-cased stub — proven by using
    // it against a completely ordinary protected endpoint exactly like a normal login's token
    const meRes = await requestJson(env.baseUrl, '/api/v1/auth/me', { token: validRes.body.token });
    assert.strictEqual(meRes.status, 200);
    assert.strictEqual(meRes.body.id, sharedUserId);

    const createProfileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token: validRes.body.token,
      body: { name: 'Shared Account Profile', account_label: 'Via Apps Code' },
    });
    assert.strictEqual(createProfileRes.status, 201, 'The Apps Code session must work against normal protected endpoints exactly like a real login');

    // 4. An invalid / already-used code (Supabase reports zero rows flipped) is rejected
    restoreFetch = installSupabaseFetchMock(() => ({ status: 200, body: [] }));
    const invalidRes = await requestJson(env.baseUrl, '/api/v1/auth/apps-code', {
      method: 'POST',
      body: { code: 'BADCODE1' },
    });
    restoreFetch();
    assert.strictEqual(invalidRes.status, 401, 'An invalid or already-consumed code must be rejected');

    // 5. A second, DIFFERENT valid code logs into the SAME shared account (one workspace for
    // everyone, not a per-code identity) — this is the explicit design decision, not a bug
    restoreFetch = installSupabaseFetchMock(() => ({
      status: 200,
      body: [{ code: 'ZZ001122', is_active: false }],
    }));
    const secondValidRes = await requestJson(env.baseUrl, '/api/v1/auth/apps-code', {
      method: 'POST',
      body: { code: 'zz001122' },
    });
    restoreFetch();
    assert.strictEqual(secondValidRes.status, 200);
    assert.strictEqual(secondValidRes.body.user.id, sharedUserId, 'Every valid code must log into the same shared account');

    // 6. That second profile-creation call shows up for BOTH sessions, proving it's really one
    // shared workspace, not two isolated ones that merely share a display email
    const profilesViaSecondSession = await requestJson(env.baseUrl, '/api/v1/profiles', { token: secondValidRes.body.token });
    assert.strictEqual(profilesViaSecondSession.status, 200);
    assert.ok(
      profilesViaSecondSession.body.some((p: any) => p.name === 'Shared Account Profile'),
      'A second Apps Code session must see data created by the first — it is genuinely one shared account'
    );

    // 7. A Supabase-side failure (non-2xx) fails closed, not open — never treated as "valid"
    restoreFetch = installSupabaseFetchMock(() => ({ status: 500, body: { error: 'internal' } }));
    const supabaseErrorRes = await requestJson(env.baseUrl, '/api/v1/auth/apps-code', {
      method: 'POST',
      body: { code: 'WHATEVER' },
    });
    restoreFetch();
    assert.strictEqual(supabaseErrorRes.status, 500, 'A Supabase-side error must surface as a failure, never as a successful login');

    // 8. Dedicated rate limiting on this endpoint specifically (tighter than the global limiter,
    // since a successful guess here grants a session — a real brute-force target)
    restoreFetch = installSupabaseFetchMock(() => ({ status: 200, body: [] })); // every attempt reports invalid
    let sawRateLimited = false;
    for (let i = 0; i < 12; i++) {
      const res = await requestJson(env.baseUrl, '/api/v1/auth/apps-code', {
        method: 'POST',
        body: { code: `GUESS${i}` },
      });
      if (res.status === 429) sawRateLimited = true;
    }
    restoreFetch();
    assert.ok(sawRateLimited, 'Repeated Apps Code attempts from the same source must eventually be rate-limited');

    // 9. No secret ever leaks back to the client: neither the Supabase anon key nor the shared
    // account's internal random password appear anywhere in a response body
    const responsesToCheck = [validRes, secondValidRes, meRes, createProfileRes];
    for (const res of responsesToCheck) {
      const serialized = JSON.stringify(res.body);
      assert.ok(!serialized.includes(config.supabaseAnonKey), 'The Supabase key must never appear in an API response');
    }

    console.log('✓ All Apps Code Authentication tests passed!');
  } finally {
    await env.close();
  }
}
