import assert from 'assert';
import WebSocket from 'ws';
import { createTestEnvironment, requestJson } from './test_helpers';
import { getDatabase } from '../src/db/database';
import { customerRepository } from '../src/repositories/customerRepository';
import { conversationRepository } from '../src/repositories/conversationRepository';

function waitForOpen(ws: WebSocket): Promise<void> {
  return new Promise((resolve, reject) => {
    ws.on('open', () => resolve());
    ws.on('error', (err) => reject(err));
  });
}

function waitForClose(ws: WebSocket, timeoutMs = 2000): Promise<number> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Timed out waiting for socket close')), timeoutMs);
    ws.on('close', (code) => {
      clearTimeout(timer);
      resolve(code);
    });
  });
}

export async function runSecurityHardeningTests() {
  console.log('--- Running Production Security Hardening Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Setup
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'security@marketplace.local', password: 'Password123!', name: 'Security Tester' },
    });
    const token = userRes.body.token;

    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Security Chrome', account_label: 'Security Label' },
    });
    const profileId = profileRes.body.id;

    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    const originalKeyId = keyRes.body.id;
    const originalKey = keyRes.body.api_key;
    const botWsUrl = env.wsUrl.replace('/api/v1/events', '/api/v1/bot/ws');

    // --- MAXIMUM MESSAGE SIZE ---

    // 2. An oversized incoming (bot-reported) message must be rejected
    const oversizedText = 'x'.repeat(10001);
    const oversizedInRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey: originalKey,
      body: { conversationId: 'nonexistent', text: oversizedText },
    });
    assert.strictEqual(oversizedInRes.status, 400, 'An oversized incoming message must be rejected');

    // 3. An oversized outgoing message must also be rejected (need a real conversation first)
    const listingRes = await requestJson(env.baseUrl, '/api/v1/listings', {
      method: 'POST',
      token,
      body: { profile_id: profileId, title: 'Size Test Item', price: 10.0 },
    });
    const userId = userRes.body.user.id;
    const customer = customerRepository.findOrCreateCustomer(userId, 'ext_size_cust', 'Size Customer');
    const conversation = conversationRepository.createConversation({
      id: 'conv_size_test',
      userId,
      profileId,
      listingId: listingRes.body.id,
      customerId: customer.id,
    });
    const oversizedOutRes = await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, {
      method: 'POST',
      token,
      body: { text: oversizedText },
    });
    assert.strictEqual(oversizedOutRes.status, 400, 'An oversized outgoing message must be rejected');

    // --- API-KEY ROTATION ---

    // 4. Rotating a key returns a NEW working key and immediately invalidates the old one
    const rotateRes = await requestJson(env.baseUrl, `/api/v1/api-keys/${originalKeyId}/rotate`, {
      method: 'POST',
      token,
    });
    assert.strictEqual(rotateRes.status, 201);
    const rotatedKey = rotateRes.body.api_key;
    assert.ok(rotatedKey && rotatedKey !== originalKey, 'Rotation must return a genuinely new raw key');
    assert.strictEqual(rotateRes.body.profile_id, profileId, 'The rotated key must belong to the same profile');

    const oldKeyRejected = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: originalKey,
      body: { profile_id: profileId, status: 'ONLINE' },
    });
    assert.strictEqual(oldKeyRejected.status, 403, 'The old key must stop working immediately after rotation');

    const newKeyWorks = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: rotatedKey,
      body: { profile_id: profileId, status: 'ONLINE' },
    });
    assert.strictEqual(newKeyWorks.status, 200, 'The rotated key must work immediately');

    // --- REVOKED-KEY IMMEDIATE DISCONNECT ---

    // 5. Connect a bot WebSocket with the rotated key, then revoke it — the live connection must
    // be force-closed right away, not just rejected on its NEXT reconnect attempt
    const liveSocket = new WebSocket(botWsUrl, { headers: { Authorization: `Bearer ${rotatedKey}` } });
    await waitForOpen(liveSocket);

    const closePromise = waitForClose(liveSocket);
    const keysListRes = await requestJson(env.baseUrl, '/api/v1/api-keys', { token });
    const rotatedKeyId = keysListRes.body.find((k: any) => k.masked_key.endsWith(rotatedKey.slice(-4)))?.id;
    assert.ok(rotatedKeyId, 'Must be able to find the rotated key by its own listing');

    await requestJson(env.baseUrl, `/api/v1/api-keys/${rotatedKeyId}/revoke`, { method: 'POST', token });
    const closeCode = await closePromise;
    assert.strictEqual(closeCode, 4003, 'A live bot connection must be force-closed the moment its key is revoked');

    // --- WEBSOCKET CONNECTION LIMITS (per user) ---

    // 6. A user opening far more concurrent connections than the cap must have the excess rejected
    const userSockets: WebSocket[] = [];
    let rejectedSomewhere = false;
    for (let i = 0; i < 12; i++) {
      const ws = new WebSocket(env.wsUrl, { headers: { Authorization: `Bearer ${token}` } });
      try {
        await waitForOpen(ws);
        userSockets.push(ws);
      } catch {
        rejectedSomewhere = true;
      }
      // A connection can also be accepted at the WS layer and then immediately closed by the
      // server once it's over the cap — catch that case too.
      ws.once('close', (code) => {
        if (code === 4008) rejectedSomewhere = true;
      });
    }
    await new Promise((r) => setTimeout(r, 200));
    assert.ok(rejectedSomewhere, 'Opening far more connections than the per-user cap must result in at least one rejection');
    for (const ws of userSockets) {
      try { ws.close(); } catch {}
    }

    // --- SECURITY AUDIT LOGGING ---

    // 7. A failed bot auth attempt (invalid key) must be recorded in the security audit log
    await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: 'mpc_live_totally_invalid_key_0000000000000000000000000000000000000000',
      body: { profile_id: profileId, status: 'ONLINE' },
    });

    const db = getDatabase();
    const invalidKeyEvents = db.prepare("SELECT * FROM security_events WHERE event_type = 'BOT_AUTH_INVALID_KEY'").all();
    assert.ok(invalidKeyEvents.length >= 1, 'An invalid bot key attempt must be recorded in the security audit log');

    const revokedEvents = db.prepare("SELECT * FROM security_events WHERE event_type = 'BOT_API_KEY_REVOKED' AND key_id = ?").all(rotatedKeyId);
    assert.ok(revokedEvents.length >= 1, 'Key revocation must be recorded in the security audit log');

    // 8. No raw API key value ever ends up stored in the audit log's own fields
    const allEvents = db.prepare('SELECT * FROM security_events').all() as any[];
    for (const ev of allEvents) {
      assert.ok(!JSON.stringify(ev).includes(originalKey), 'No raw API key must ever appear in the security audit log');
      assert.ok(!JSON.stringify(ev).includes(rotatedKey), 'No raw API key must ever appear in the security audit log');
    }

    console.log('✓ All Production Security Hardening tests passed!');
  } finally {
    await env.close();
  }
}
