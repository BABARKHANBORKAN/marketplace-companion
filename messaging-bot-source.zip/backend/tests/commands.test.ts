import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';
import { getDatabase } from '../src/db/database';
import { commandService } from '../src/services/commandService';

export async function runCommandsTests() {
  console.log('--- Running Commands & Idempotency Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Setup user, profile, and bot key
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'cmduser@marketplace.local', password: 'Password123!', name: 'Cmd User' },
    });
    const token = userRes.body.token;

    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Command Test Chrome', account_label: 'Cmd Label' },
    });
    const profileId = profileRes.body.id;

    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    const botKey = keyRes.body.api_key;

    // 2. Dispatch a command with idempotency key
    const idempotencyKey = 'idemp_unique_command_12345';
    const dispatchRes1 = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: {
        command_id: 'cmd_test_001',
        idempotency_key: idempotencyKey,
        profile_id: profileId,
        type: 'REOPEN_CHROME_PROFILE',
        payload: '{"action":"REOPEN_CHROME_PROFILE"}',
      },
    });
    assert.strictEqual(dispatchRes1.status, 200);
    assert.strictEqual(dispatchRes1.body.id, 'cmd_test_001');
    assert.strictEqual(dispatchRes1.body.status, 'PENDING');

    // 3. Dispatch same command again with same idempotency key => MUST return existing record
    const dispatchRes2 = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: {
        command_id: 'cmd_test_001',
        idempotency_key: idempotencyKey,
        profile_id: profileId,
        type: 'REOPEN_CHROME_PROFILE',
        payload: '{"action":"REOPEN_CHROME_PROFILE"}',
      },
    });
    assert.strictEqual(dispatchRes2.status, 200);
    assert.strictEqual(dispatchRes2.body.id, 'cmd_test_001');

    // 4. Bot fetches pending commands for its profile
    const pendingRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/pending', {
      botKey,
    });
    assert.strictEqual(pendingRes.status, 200);
    assert.ok(pendingRes.body.length >= 1);
    assert.strictEqual(pendingRes.body[0].id, 'cmd_test_001');

    // 5. Bot must claim the command (PENDING -> PROCESSING) before it can complete it — the
    // strict state machine rejects a direct PENDING -> COMPLETED jump.
    const claimStatusRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_test_001/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimStatusRes.status, 200);
    assert.strictEqual(claimStatusRes.body.status, 'PROCESSING');

    const statusRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_test_001/status', {
      method: 'POST',
      botKey,
      body: {
        status: 'COMPLETED',
        result_message: 'Chrome profile reopened successfully on desktop',
      },
    });
    assert.strictEqual(statusRes.status, 200);
    assert.strictEqual(statusRes.body.status, 'COMPLETED');

    // 6. User verifies command status
    const getCmdRes = await requestJson(env.baseUrl, '/api/v1/commands/cmd_test_001', {
      token,
    });
    assert.strictEqual(getCmdRes.status, 200);
    assert.strictEqual(getCmdRes.body.status, 'COMPLETED');
    assert.ok(getCmdRes.body.completed_at, 'completed_at timestamp must be populated');

    // --- FULL LIFECYCLE: PENDING -> (claim) PROCESSING -> COMPLETED, and duplicate-claim prevention ---

    // 7. Dispatch a fresh command -> must start PENDING
    const dispatch2 = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_lifecycle_1', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatch2.status, 200);
    assert.strictEqual(dispatch2.body.status, 'PENDING', 'A newly created command must start PENDING');

    // 8. Bot claims it -> PROCESSING (this IS the claim step; nothing became PROCESSING before it)
    const claimRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_lifecycle_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimRes.status, 200);
    assert.strictEqual(claimRes.body.status, 'PROCESSING', 'Bot claim must move the command to PROCESSING');

    // 9. Bot completes it -> COMPLETED
    const completeRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_lifecycle_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED', result_message: 'Task stopped' },
    });
    assert.strictEqual(completeRes.status, 200);
    assert.strictEqual(completeRes.body.status, 'COMPLETED');

    // 10. A second, stale/duplicate claim attempt on the now-finished command must be REJECTED,
    // not silently re-execute it (this is the actual "duplicate claim cannot cause duplicate execution" guard)
    const duplicateClaimRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_lifecycle_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(duplicateClaimRes.status, 404, 'A finished command must not be reopened to PROCESSING by a later claim');

    // 11. Re-reporting the SAME terminal status again (e.g. a lost-ack retry) is a safe idempotent
    // no-op, not an error -- and must not overwrite the original result with a new one
    const idempotentRepeatRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_lifecycle_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED', result_message: 'A DIFFERENT message that must be ignored' },
    });
    assert.strictEqual(idempotentRepeatRes.status, 200, 'Re-confirming the same terminal status must succeed as a no-op');
    assert.strictEqual(idempotentRepeatRes.body.status, 'COMPLETED');
    assert.strictEqual(
      idempotentRepeatRes.body.result_message,
      'Task stopped',
      'The original result must be preserved, not overwritten by a later duplicate report'
    );

    // 12. FAILED path
    const dispatch3 = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_lifecycle_fail', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatch3.body.status, 'PENDING');
    const failRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_lifecycle_fail/status', {
      method: 'POST',
      botKey,
      body: { status: 'FAILED', error_code: 'CHROME_CRASHED', error_message: 'Chrome window closed unexpectedly' },
    });
    assert.strictEqual(failRes.status, 200);
    assert.strictEqual(failRes.body.status, 'FAILED');
    assert.strictEqual(failRes.body.error_code, 'CHROME_CRASHED');

    // 13. CANCELLED path
    const dispatch4 = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_lifecycle_cancel', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatch4.body.status, 'PENDING');
    const cancelRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_lifecycle_cancel/status', {
      method: 'POST',
      botKey,
      body: { status: 'CANCELLED', result_message: 'Superseded by a newer command' },
    });
    assert.strictEqual(cancelRes.status, 200);
    assert.strictEqual(cancelRes.body.status, 'CANCELLED');

    // --- STRICT STATE MACHINE: PENDING -> COMPLETED must be rejected outright ---

    // 14. A fresh, never-claimed command jumping straight to COMPLETED must be rejected
    const dispatch5 = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_invalid_jump', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatch5.body.status, 'PENDING');
    const invalidJumpRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_invalid_jump/status', {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED', result_message: 'Skipping the claim step' },
    });
    assert.strictEqual(invalidJumpRes.status, 404, 'PENDING -> COMPLETED directly must be rejected by the state machine');

    // The command must be untouched — still PENDING, not silently completed
    const invalidJumpCheck = await requestJson(env.baseUrl, '/api/v1/commands/cmd_invalid_jump', { token });
    assert.strictEqual(invalidJumpCheck.body.status, 'PENDING', 'Rejected transition must not mutate the command');

    // 15. PROCESSING -> PENDING (voluntary un-claim) IS allowed, and the command can still be
    // completed normally afterward via a fresh claim
    const claimForRevert = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_invalid_jump/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimForRevert.status, 200);

    const revertRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_invalid_jump/status', {
      method: 'POST',
      botKey,
      body: { status: 'PENDING', result_message: 'Giving up on this attempt, requeueing' },
    });
    assert.strictEqual(revertRes.status, 200, 'PROCESSING -> PENDING must be allowed (voluntary un-claim / retry)');
    assert.strictEqual(revertRes.body.status, 'PENDING');

    const reclaimRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_invalid_jump/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(reclaimRes.status, 200, 'A reverted command must be re-claimable');
    const finalCompleteRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_invalid_jump/status', {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED' },
    });
    assert.strictEqual(finalCompleteRes.status, 200);
    assert.strictEqual(finalCompleteRes.body.status, 'COMPLETED');

    // --- ATOMIC CLAIMING: two DIFFERENT bot identities on the SAME profile must never both claim one command ---
    // (Reusing `botKey`/a same-bot second key would only prove idempotent self-retry, not the
    // actual race the state machine must prevent — so these are two explicitly distinct bots.)

    // 16. Register a second, genuinely distinct bot and mint it its own key for the SAME profile
    const botOneRes = await requestJson(env.baseUrl, '/api/v1/bot/bots', {
      method: 'POST',
      token,
      body: { name: 'Race Bot One' },
    });
    assert.strictEqual(botOneRes.status, 201);
    const botOneKeyRes = await requestJson(env.baseUrl, `/api/v1/bot/bots/${botOneRes.body.id}/api-keys`, {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    assert.strictEqual(botOneKeyRes.status, 201);
    const botKeyOne = botOneKeyRes.body.api_key;

    const botTwoRes = await requestJson(env.baseUrl, '/api/v1/bot/bots', {
      method: 'POST',
      token,
      body: { name: 'Race Bot Two' },
    });
    assert.strictEqual(botTwoRes.status, 201);
    const botTwoKeyRes = await requestJson(env.baseUrl, `/api/v1/bot/bots/${botTwoRes.body.id}/api-keys`, {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    assert.strictEqual(botTwoKeyRes.status, 201);
    const botKey2 = botTwoKeyRes.body.api_key;

    const dispatchRace = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_claim_race', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatchRace.body.status, 'PENDING');

    // Both distinct bot identities attempt to claim the exact same PENDING command
    const [claimA, claimB] = await Promise.all([
      requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_claim_race/status', {
        method: 'POST',
        botKey: botKeyOne,
        body: { status: 'PROCESSING' },
      }),
      requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_claim_race/status', {
        method: 'POST',
        botKey: botKey2,
        body: { status: 'PROCESSING' },
      }),
    ]);
    const claimResults = [claimA, claimB];
    const winners = claimResults.filter(r => r.status === 200);
    const losers = claimResults.filter(r => r.status !== 200);
    assert.strictEqual(winners.length, 1, 'Exactly one bot connection must win the claim');
    assert.strictEqual(losers.length, 1, 'The other bot connection must be rejected, not also succeed');
    assert.strictEqual(losers[0].status, 404, "The losing claim must be rejected as 'not found' for that bot's scope");

    // 17. Scoping: GET /commands/pending for the bot that LOST the race must NOT show the
    // now-claimed command (it belongs to the other bot now) — proves pending-command visibility
    // is scoped by (userId, profileId, botId), not just profileId
    const winningBotKey = claimA.status === 200 ? botKeyOne : botKey2;
    const losingBotKey = claimA.status === 200 ? botKey2 : botKeyOne;

    const losingBotPending = await requestJson(env.baseUrl, '/api/v1/bot/commands/pending', { botKey: losingBotKey });
    assert.strictEqual(losingBotPending.status, 200);
    assert.ok(
      !losingBotPending.body.some((c: any) => c.id === 'cmd_claim_race'),
      "The bot that lost the claim race must not see the other bot's claimed command as pending"
    );

    const winningBotPending = await requestJson(env.baseUrl, '/api/v1/bot/commands/pending', { botKey: winningBotKey });
    assert.strictEqual(winningBotPending.status, 200);
    assert.ok(
      winningBotPending.body.some((c: any) => c.id === 'cmd_claim_race'),
      'The bot that won the claim must still see its own claimed (PROCESSING) command as pending work'
    );

    // --- COMMAND TIMEOUT / RECOVERY ---

    // 18. A command claimed but never finished, once its updated_at is older than the timeout
    // cutoff, must be reverted to PENDING (with attempts incremented) so it can be reclaimed.
    const dispatchTimeout = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_timeout_1', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatchTimeout.body.status, 'PENDING');
    const claimTimeout = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_timeout_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimTimeout.status, 200);

    // Simulate the bot dying mid-task: backdate updated_at directly (test-only escape hatch —
    // there is no legitimate API for a bot to backdate its own claim)
    const db = getDatabase();
    db.prepare("UPDATE commands SET updated_at = ? WHERE id = 'cmd_timeout_1'").run(Date.now() - 1_000_000);

    const recoveredCount1 = commandService.recoverStaleCommands(Date.now() - 500_000);
    assert.ok(recoveredCount1 >= 1, 'Auditor must recover at least the one stale PROCESSING command');

    const afterFirstTimeout = await requestJson(env.baseUrl, '/api/v1/commands/cmd_timeout_1', { token });
    assert.strictEqual(afterFirstTimeout.body.status, 'PENDING', 'First timeout must revert to PENDING, not FAILED');

    // 19. Exhausting the retry budget marks it FAILED instead of endlessly reverting to PENDING
    const dbCmd = db.prepare("SELECT max_retries FROM commands WHERE id = 'cmd_timeout_1'").get() as { max_retries: number };
    for (let i = 0; i < dbCmd.max_retries; i++) {
      // Re-claim (it's PENDING again after each revert) then go stale again
      await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_timeout_1/status', {
        method: 'POST',
        botKey,
        body: { status: 'PROCESSING' },
      });
      db.prepare("UPDATE commands SET updated_at = ? WHERE id = 'cmd_timeout_1'").run(Date.now() - 1_000_000);
      commandService.recoverStaleCommands(Date.now() - 500_000);
    }
    const afterExhausted = await requestJson(env.baseUrl, '/api/v1/commands/cmd_timeout_1', { token });
    assert.strictEqual(afterExhausted.body.status, 'FAILED', 'Once the retry budget is exhausted, the command must be marked FAILED, not stuck forever');
    assert.strictEqual(afterExhausted.body.error_code, 'BOT_TIMEOUT');

    console.log('✓ All Commands & Idempotency tests passed!');
  } finally {
    await env.close();
  }
}
