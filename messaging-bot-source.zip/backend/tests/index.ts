import { runAuthTests } from './auth.test';
import { runIsolationTests } from './isolation.test';
import { runBotTests } from './bot_and_heartbeat.test';
import { runCommandsTests } from './commands.test';
import { runMessagesTests } from './messages.test';
import { runDeltaSyncTests } from './delta_sync.test';
import { runWebSocketTests } from './websocket.test';
import { runE2eLifecycleTests } from './e2e_lifecycle.test';
import { runReconnectWatchdogTests } from './reconnect_watchdog.test';
import { runSecurityHardeningTests } from './security_hardening.test';
import { runCommandLifecycleTests } from './command_lifecycle.test';
import { runAppsCodeAuthTests } from './apps_code_auth.test';
import { runProfileDeletionCascadeTests } from './profile_deletion_cascade.test';

async function runAll() {
  console.log('====================================================');
  console.log('Marketplace Companion Backend - Master Test Suite');
  console.log('====================================================\n');

  try {
    await runAuthTests();
    console.log();
    await runIsolationTests();
    console.log();
    await runBotTests();
    console.log();
    await runCommandsTests();
    console.log();
    await runMessagesTests();
    console.log();
    await runDeltaSyncTests();
    console.log();
    await runWebSocketTests();
    console.log();
    await runE2eLifecycleTests();
    console.log();
    await runReconnectWatchdogTests();
    console.log();
    await runSecurityHardeningTests();
    console.log();
    await runCommandLifecycleTests();
    console.log();
    await runAppsCodeAuthTests();
    console.log();
    await runProfileDeletionCascadeTests();
    console.log();
    console.log('====================================================');
    console.log('ALL TEST SUITES PASSED CLEANLY (100% SUCCESS)');
    console.log('====================================================');
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Test Suite Failed:', error);
    process.exit(1);
  }
}

runAll();
