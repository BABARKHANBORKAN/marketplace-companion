import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';
import { customerRepository } from '../src/repositories/customerRepository';
import { conversationRepository } from '../src/repositories/conversationRepository';

export async function runMessagesTests() {
  console.log('--- Running Messaging Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Setup user & profile
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'msgtest@marketplace.local', password: 'Password123!', name: 'Msg Tester' },
    });
    const token = userRes.body.token;
    const userId = userRes.body.user.id;

    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Inbox Chrome', account_label: 'Main Store' },
    });
    const profileId = profileRes.body.id;

    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    const botKey = keyRes.body.api_key;

    // 2. Setup listing & customer & conversation
    const listingRes = await requestJson(env.baseUrl, '/api/v1/listings', {
      method: 'POST',
      token,
      body: { profile_id: profileId, title: 'Bose Headphones', price: 199.0 },
    });
    const listingId = listingRes.body.id;

    const cust = customerRepository.findOrCreateCustomer(userId, 'ext_cust_456', 'Sarah Connor');
    const conv = conversationRepository.createConversation({
      id: 'conv_test_999',
      userId,
      profileId,
      listingId,
      customerId: cust.id,
    });

    // 3. User sends outbound message
    const idempotencyKey = 'idemp_msg_888';
    const sendRes1 = await requestJson(env.baseUrl, `/api/v1/conversations/${conv.id}/messages`, {
      method: 'POST',
      token,
      body: {
        text: 'Yes, it is still available!',
        idempotency_key: idempotencyKey,
        command_id: 'cmd_send_msg_1',
      },
    });
    assert.strictEqual(sendRes1.status, 201);
    assert.strictEqual(sendRes1.body.status, 'PROCESSING');
    assert.strictEqual(sendRes1.body.sender, 'USER_APP');

    // 4. Send again with same idempotency key => returns existing message
    const sendRes2 = await requestJson(env.baseUrl, `/api/v1/conversations/${conv.id}/messages`, {
      method: 'POST',
      token,
      body: {
        text: 'Yes, it is still available!',
        idempotency_key: idempotencyKey,
      },
    });
    assert.strictEqual(sendRes2.status, 201);
    assert.strictEqual(sendRes2.body.id, sendRes1.body.id);

    // 5. Bot claims (PROCESSING) then confirms command completion => updates message status to SENT
    const claimRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_send_msg_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimRes.status, 200);

    const botStatusRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_send_msg_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED', result_message: 'Message delivered to Facebook Marketplace chat' },
    });
    assert.strictEqual(botStatusRes.status, 200);

    // Verify messages list
    const msgsRes = await requestJson(env.baseUrl, `/api/v1/conversations/${conv.id}/messages`, { token });
    assert.strictEqual(msgsRes.body.length, 1);
    assert.strictEqual(msgsRes.body[0].status, 'SENT');

    // 6. Bot reports incoming message from customer
    const inMsgRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey,
      body: {
        conversationId: conv.id,
        text: 'Great, can I pick it up today?',
      },
    });
    assert.strictEqual(inMsgRes.status, 201);
    assert.strictEqual(inMsgRes.body.sender, 'CUSTOMER');

    // 7. Verify conversation unread count incremented
    const convsRes = await requestJson(env.baseUrl, '/api/v1/conversations', { token });
    const updatedConv = convsRes.body.find((c: any) => c.id === conv.id);
    assert.ok(updatedConv, 'Conversation must exist');
    assert.strictEqual(updatedConv.last_message, 'Great, can I pick it up today?');
    assert.strictEqual(updatedConv.unread_count, 1);

    // --- DURABLE IDEMPOTENCY FOR INCOMING (BOT-REPORTED) MESSAGES ---

    // 8. Bot reports a NEW incoming message with a platform message id (externalMessageId) —
    // this is what a reconnecting bot would replay if its earlier ack was lost
    const externalId = 'fb_msg_ext_12345';
    const firstReportRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey,
      body: {
        conversationId: conv.id,
        text: 'Would $150 work instead?',
        externalMessageId: externalId,
      },
    });
    assert.strictEqual(firstReportRes.status, 201);
    const firstReportedId = firstReportRes.body.id;

    // 9. Bot reconnects and re-reports the SAME platform message (same externalMessageId) — this
    // must return the EXISTING message, not create a duplicate
    const replayReportRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey,
      body: {
        conversationId: conv.id,
        text: 'Would $150 work instead?',
        externalMessageId: externalId,
      },
    });
    assert.strictEqual(replayReportRes.status, 201);
    assert.strictEqual(replayReportRes.body.id, firstReportedId, 'A replayed report must return the SAME message id, not a new one');

    // 10. Confirm only ONE message actually exists for this externalMessageId, and unread_count
    // was not double-incremented by the replay
    const msgsAfterReplay = await requestJson(env.baseUrl, `/api/v1/conversations/${conv.id}/messages`, { token });
    const matching = msgsAfterReplay.body.filter((m: any) => m.text === 'Would $150 work instead?');
    assert.strictEqual(matching.length, 1, 'A replayed bot-reported message must not create a duplicate row');

    const convsAfterReplay = await requestJson(env.baseUrl, '/api/v1/conversations', { token });
    const convAfterReplay = convsAfterReplay.body.find((c: any) => c.id === conv.id);
    assert.strictEqual(convAfterReplay.unread_count, 2, 'unread_count must increment once for the new message, not again for the replay (1 from step 6 + 1 from step 8)');

    console.log('✓ All Messaging tests passed!');
  } finally {
    await env.close();
  }
}
