import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';
import { getDatabase } from '../src/db/database';
import { botRepository } from '../src/repositories/botRepository';
import { profileRepository } from '../src/repositories/profileRepository';

export async function runBotTests() {
  console.log('--- Running Bot Authentication & Heartbeat Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Setup user & profile
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'botowner@marketplace.local', password: 'Password123!', name: 'Bot Owner' },
    });
    const token = userRes.body.token;

    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Main Chrome', account_label: 'Seller Account' },
    });
    const profileId = profileRes.body.id;

    // A freshly created profile must start OFFLINE with no bot connected and no heartbeat on
    // record — only a real heartbeat from the Desktop Bot should ever bring it ONLINE.
    assert.strictEqual(profileRes.body.status, 'OFFLINE', 'New profile must start OFFLINE');
    assert.strictEqual(profileRes.body.bot_connected, false, 'New profile must start with bot_connected = false');
    assert.strictEqual(profileRes.body.last_heartbeat, 0, 'New profile must start with no last_heartbeat');

    // 2. Generate Bot API Key
    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId, server_url: env.baseUrl },
    });
    assert.strictEqual(keyRes.status, 201);
    const rawApiKey = keyRes.body.api_key;
    const maskedKey = keyRes.body.masked_key;
    const keyId = keyRes.body.id;

    assert.ok(rawApiKey.startsWith('mpc_live_'), 'Raw key must have mpc_live_ prefix');
    assert.ok(maskedKey.includes('••••••••••••'), 'Masked key must have bullet masks');
    assert.strictEqual(maskedKey.slice(-4), rawApiKey.slice(-4), 'Last 4 characters must match');

    // 3. Verify Database: RAW KEY MUST NEVER BE STORED IN DATABASE!
    const db = getDatabase();
    const dbKeyRow = db.prepare('SELECT * FROM bot_api_keys WHERE id = ?').get(keyId) as any;
    assert.ok(dbKeyRow, 'Key row must exist');
    assert.notStrictEqual(dbKeyRow.key_hash, rawApiKey, 'Raw API key must NOT be stored in DB');
    assert.strictEqual(dbKeyRow.key_hash.length, 64, 'Key hash must be 64 hex characters (SHA-256)');

    // 4. Verify unauthenticated heartbeat is rejected with 401
    const unauthHbRes = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      body: {
        profile_id: profileId,
        status: 'ONLINE',
      },
    });
    assert.strictEqual(unauthHbRes.status, 401, 'Unauthenticated heartbeat must return 401 Unauthorized');

    // Verify invalid bot key is rejected with 401
    const invalidKeyHbRes = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: 'mpc_live_invalid_key_1234567890',
      body: {
        profile_id: profileId,
        status: 'ONLINE',
      },
    });
    assert.strictEqual(invalidKeyHbRes.status, 401, 'Invalid bot key must return 401 Unauthorized');

    // Bot authentication uses exactly one convention: Authorization: Bearer mpc_live_...
    // A valid key supplied only via the old X-Bot-Key header (no Authorization header) must be rejected.
    const xBotKeyOnlyRes = await fetch(`${env.baseUrl}/api/v1/bot/heartbeat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bot-Key': rawApiKey },
      body: JSON.stringify({ profile_id: profileId, status: 'ONLINE' }),
    });
    assert.strictEqual(xBotKeyOnlyRes.status, 401, 'X-Bot-Key header alone must no longer authenticate a bot request');

    // 5. Send authenticated Heartbeat from Bot using valid raw API key
    const hbRes = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: rawApiKey,
      body: {
        profile_id: profileId,
        bot_version: 'DesktopBot v2.4.1',
        status: 'BUSY',
        current_task: 'Processing listing update',
        timestamp: Date.now(),
      },
    });
    assert.strictEqual(hbRes.status, 200);
    assert.strictEqual(hbRes.body.acknowledged, true);

    // 6. Verify profile status was updated to BUSY, and the real heartbeat brought the bot online
    const checkProfileRes = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(checkProfileRes.body.status, 'BUSY');
    assert.strictEqual(checkProfileRes.body.current_task, 'Processing listing update');
    assert.strictEqual(checkProfileRes.body.bot_connected, true, 'A real heartbeat must set bot_connected = true');
    assert.ok(checkProfileRes.body.last_heartbeat > 0, 'A real heartbeat must set a non-zero last_heartbeat');

    // --- BODY-SUPPLIED profile_id/bot_id MUST NEVER BE TRUSTED FOR HEARTBEAT AUTHORIZATION ---

    // 6b. Create a second, unrelated profile for the SAME user, with no bot key of its own.
    const profileBRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Unrelated Second Profile', account_label: 'Should Not Be Touched' },
    });
    assert.strictEqual(profileBRes.status, 201);
    const profileBId = profileBRes.body.id;
    assert.strictEqual(profileBRes.body.status, 'OFFLINE');

    // 6c. Heartbeat with Bot A's key, but the BODY claims profile_id/bot_id belonging to Profile B.
    // The server must use ONLY the authenticated key's own (profileId, botId) — never the body —
    // so this must heartbeat Profile A and must NOT touch Profile B at all.
    const spoofedHbRes = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: rawApiKey,
      body: {
        profile_id: profileBId,
        bot_id: 'bot_completely_unrelated_id',
        status: 'ONLINE',
        current_task: 'Attempting to spoof Profile B',
      },
    });
    assert.strictEqual(spoofedHbRes.status, 200, 'Heartbeat must still succeed (auth is by key, not by body)');

    const profileACheck = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(profileACheck.body.current_task, 'Attempting to spoof Profile B', "Profile A (the key's real profile) must be the one updated");

    const profileBCheck = await requestJson(env.baseUrl, `/api/v1/profiles/${profileBId}`, { token });
    assert.strictEqual(profileBCheck.body.status, 'OFFLINE', 'Profile B must remain untouched — body profile_id must be ignored for authorization');
    assert.strictEqual(profileBCheck.body.bot_connected, false, 'Profile B must remain bot_connected = false');
    assert.strictEqual(profileBCheck.body.last_heartbeat, 0, 'Profile B must still have no heartbeat on record');

    // 7. Test Heartbeat auditor: mark stale bots AND stale profiles offline
    const cutoff = Date.now() + 1000; // all timestamps before this are considered stale
    const markedOffline = botRepository.markStaleBotsOffline(cutoff);
    assert.ok(markedOffline >= 1, 'Auditor should mark stale bots offline');

    const markedProfilesOffline = profileRepository.markStaleProfilesOffline(cutoff);
    assert.ok(markedProfilesOffline >= 1, 'Auditor should mark stale profiles OFFLINE (Profile A, which had a heartbeat)');

    const profileAAfterAudit = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(profileAAfterAudit.body.status, 'OFFLINE', 'Profile A must go OFFLINE once its heartbeat has expired');
    assert.strictEqual(profileAAfterAudit.body.bot_connected, false, 'Profile A must have bot_connected reset to false once stale');

    // 8. Revoke API key and verify it cannot be used for bot-authenticated endpoints (including heartbeat)
    const revokeRes = await requestJson(env.baseUrl, `/api/v1/api-keys/${keyId}/revoke`, {
      method: 'POST',
      token,
    });
    assert.strictEqual(revokeRes.status, 200);

    const blockedRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/pending', {
      botKey: rawApiKey,
    });
    assert.strictEqual(blockedRes.status, 403, 'Revoked bot key must be forbidden (403)');

    const blockedHbRes = await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey: rawApiKey,
      body: {
        status: 'ONLINE',
      },
    });
    assert.strictEqual(blockedHbRes.status, 403, 'Revoked bot key must be forbidden (403) on heartbeat');

    console.log('✓ All Bot & Heartbeat tests passed!');
  } finally {
    await env.close();
  }
}
