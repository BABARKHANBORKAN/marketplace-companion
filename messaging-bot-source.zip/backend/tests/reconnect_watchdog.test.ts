import assert from 'assert';
import WebSocket from 'ws';
import { createTestEnvironment, requestJson } from './test_helpers';
import { getDatabase } from '../src/db/database';

function waitForOpen(ws: WebSocket): Promise<void> {
  return new Promise((resolve, reject) => {
    ws.on('open', () => resolve());
    ws.on('error', (err) => reject(err));
  });
}

// The server can push a resume message in the SAME synchronous tick as completing the upgrade,
// before a caller's 'open' promise even resolves — so the 'message' listener must be attached
// at socket-construction time, not after awaiting open, or an immediate push can be missed.
function connectCollectingMessages(url: string, headers: Record<string, string>): { ws: WebSocket; messages: any[]; ready: Promise<void> } {
  const ws = new WebSocket(url, { headers });
  const messages: any[] = [];
  ws.on('message', (data) => {
    try { messages.push(JSON.parse(data.toString('utf-8'))); } catch {}
  });
  const ready = waitForOpen(ws);
  return { ws, messages, ready };
}

export async function runReconnectWatchdogTests() {
  console.log('--- Running WebSocket Reconnect / Offline Watchdog Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Setup
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'reconnect@marketplace.local', password: 'Password123!', name: 'Reconnect Tester' },
    });
    const token = userRes.body.token;

    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Reconnect Chrome', account_label: 'Reconnect Label' },
    });
    const profileId = profileRes.body.id;
    assert.strictEqual(profileRes.body.status, 'OFFLINE');

    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    const botKey = keyRes.body.api_key;
    const botWsUrl = env.wsUrl.replace('/api/v1/events', '/api/v1/bot/ws');

    // 2. Dispatch a command BEFORE any bot connection exists — it must sit PENDING, undelivered
    const dispatchRes = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_reconnect_1', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatchRes.body.status, 'PENDING');

    // 3. Bot connects for the first time -> must be re-authenticated (implicit, via the key) and
    // the profile must go ONLINE immediately, with no separate explicit /heartbeat call needed.
    const connA = connectCollectingMessages(botWsUrl, { Authorization: `Bearer ${botKey}` });
    const botSocketA = connA.ws;
    const messagesA = connA.messages;
    await connA.ready;

    await new Promise((r) => setTimeout(r, 150));

    const profileAfterConnect = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(profileAfterConnect.body.status, 'ONLINE', 'Connecting the bot socket must restore ONLINE state without a separate heartbeat call');
    assert.strictEqual(profileAfterConnect.body.bot_connected, true);

    // 4. The still-PENDING command must have been identified and pushed to the newly connected bot
    const executeEvents = messagesA.filter((m: any) => m.type === 'EXECUTE_COMMAND' && m.commandId === 'cmd_reconnect_1');
    assert.ok(executeEvents.length >= 1, 'An uncompleted command must be pushed to the bot as soon as it connects');

    // The actual delivery attempt must be durably recorded (dispatched_at), not just implied —
    // this is what lets the server later tell "never even reached a bot" apart from "reached one
    // and never got claimed" or "claimed and never finished".
    const db = getDatabase();
    const dispatchedRow = db.prepare('SELECT dispatched_at FROM commands WHERE id = ?').get('cmd_reconnect_1') as { dispatched_at: number | null };
    assert.ok(dispatchedRow.dispatched_at && dispatchedRow.dispatched_at > 0, 'A successfully pushed command must have dispatched_at recorded');

    // 5. Bot claims the command
    const claimRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_reconnect_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimRes.status, 200);

    // 6. Bot disconnects (simulating a crash/restart) -> profile must go OFFLINE IMMEDIATELY,
    // without waiting for the heartbeat timeout window
    botSocketA.close();
    await new Promise((r) => setTimeout(r, 200));

    const profileAfterDisconnect = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(profileAfterDisconnect.body.status, 'OFFLINE', 'A real bot disconnect must mark the profile OFFLINE immediately');
    assert.strictEqual(profileAfterDisconnect.body.bot_connected, false);

    // 7. Bot reconnects (new socket, same key) -> re-authenticates, restores ONLINE, and safely
    // resumes the still-PROCESSING command (never lost, never silently abandoned)
    const connB = connectCollectingMessages(botWsUrl, { Authorization: `Bearer ${botKey}` });
    const botSocketB = connB.ws;
    const messagesB = connB.messages;
    await connB.ready;
    await new Promise((r) => setTimeout(r, 150));

    const profileAfterReconnect = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(profileAfterReconnect.body.status, 'ONLINE', 'Reconnecting must restore ONLINE state again');

    const resumedExecuteEvents = messagesB.filter((m: any) => m.type === 'EXECUTE_COMMAND' && m.commandId === 'cmd_reconnect_1');
    assert.ok(resumedExecuteEvents.length >= 1, 'The still-PROCESSING command must be resumed (re-pushed) on reconnect');

    // 8. Completing it now must succeed exactly once — no duplicate-execution hazard from the resume
    const completeRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_reconnect_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED', result_message: 'Done after reconnect' },
    });
    assert.strictEqual(completeRes.status, 200);
    assert.strictEqual(completeRes.body.status, 'COMPLETED');

    // A second, late "resume" claim attempt (simulating a stale duplicate) must still be rejected,
    // proving the resume mechanism never bypasses the atomic state machine
    const staleClaimRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_reconnect_1/status', {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(staleClaimRes.status, 404, 'A completed command must never be re-claimed, even after a reconnect resume push');

    botSocketB.close();
    console.log('✓ All WebSocket Reconnect / Offline Watchdog tests passed!');
  } finally {
    await env.close();
  }
}
