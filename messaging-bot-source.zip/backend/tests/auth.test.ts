import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';

export async function runAuthTests() {
  console.log('--- Running Auth & Session Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Register new user
    const regRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: {
        email: 'alex@marketplace.local',
        password: 'Password123!',
        name: 'Alex Vance',
        plan: 'Pro',
      },
    });

    assert.strictEqual(regRes.status, 201, 'Registration should return 201');
    assert.ok(regRes.body.token, 'Should return accessToken/token');
    assert.ok(regRes.body.refreshToken, 'Should return refreshToken');
    assert.strictEqual(regRes.body.user.email, 'alex@marketplace.local');
    const userToken = regRes.body.token;
    const refreshToken = regRes.body.refreshToken;

    // 2. Access protected endpoint with token
    const meRes = await requestJson(env.baseUrl, '/api/v1/auth/me', {
      token: userToken,
    });
    assert.strictEqual(meRes.status, 200, 'GET /auth/me should succeed');
    assert.strictEqual(meRes.body.name, 'Alex Vance');

    // 3. Access protected endpoint without token => 401
    const unauthRes = await requestJson(env.baseUrl, '/api/v1/auth/me');
    assert.strictEqual(unauthRes.status, 401, 'Unauthenticated request should return 401');

    // 4. Refresh token
    const refreshRes = await requestJson(env.baseUrl, '/api/v1/auth/refresh', {
      method: 'POST',
      body: { refresh_token: refreshToken },
    });
    assert.strictEqual(refreshRes.status, 200, 'Token refresh should succeed');
    assert.ok(refreshRes.body.token, 'Should return new access token');
    assert.ok(refreshRes.body.refreshToken, 'Should return rotated refresh token');

    // 5. Old refresh token should now be invalidated (rotation)
    const oldRefreshRes = await requestJson(env.baseUrl, '/api/v1/auth/refresh', {
      method: 'POST',
      body: { refresh_token: refreshToken },
    });
    assert.strictEqual(oldRefreshRes.status, 401, 'Reused refresh token should be rejected (401)');

    // 6. Login with correct credentials
    const loginRes = await requestJson(env.baseUrl, '/api/v1/auth/login', {
      method: 'POST',
      body: {
        email: 'alex@marketplace.local',
        password: 'Password123!',
      },
    });
    assert.strictEqual(loginRes.status, 200, 'Login with correct credentials should return 200');

    // 7. Login with bad password
    const badLoginRes = await requestJson(env.baseUrl, '/api/v1/auth/login', {
      method: 'POST',
      body: {
        email: 'alex@marketplace.local',
        password: 'WrongPassword!',
      },
    });
    assert.strictEqual(badLoginRes.status, 401, 'Login with bad password should return 401');

    console.log('✓ All Auth & Session tests passed!');
  } finally {
    await env.close();
  }
}
