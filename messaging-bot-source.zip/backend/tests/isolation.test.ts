import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';
import { customerRepository } from '../src/repositories/customerRepository';
import { conversationRepository } from '../src/repositories/conversationRepository';
import { apiKeyRepository } from '../src/repositories/apiKeyRepository';

export async function runIsolationTests() {
  console.log('--- Running Multi-User Isolation Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Register User A
    const userARes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'usera@example.com', password: 'PasswordA123!', name: 'User A' },
    });
    const tokenA = userARes.body.token;
    const userIdA = userARes.body.user.id;

    // 2. Register User B
    const userBRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'userb@example.com', password: 'PasswordB123!', name: 'User B' },
    });
    const tokenB = userBRes.body.token;
    const userIdB = userBRes.body.user.id;

    // 3. User A creates a Chrome profile
    const profileARes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token: tokenA,
      body: { name: 'User A Profile', account_label: 'Account A' },
    });
    assert.strictEqual(profileARes.status, 201);
    const profileAId = profileARes.body.id;

    // 4. User A creates a listing
    const listingARes = await requestJson(env.baseUrl, '/api/v1/listings', {
      method: 'POST',
      token: tokenA,
      body: {
        profile_id: profileAId,
        title: 'Sony Alpha Camera',
        price: 850.0,
        category: 'Cameras',
      },
    });
    assert.strictEqual(listingARes.status, 201);
    const listingAId = listingARes.body.id;

    // 5. User A generates an API key
    const keyARes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token: tokenA,
      body: { profile_id: profileAId, server_url: env.baseUrl },
    });
    assert.strictEqual(keyARes.status, 201);
    const keyAId = keyARes.body.id;

    // --- VERIFY USER B CANNOT ACCESS USER A's DATA ---

    // 6. User B lists profiles -> empty
    const bProfilesRes = await requestJson(env.baseUrl, '/api/v1/profiles', { token: tokenB });
    assert.strictEqual(bProfilesRes.body.length, 0, 'User B must not see User A profiles');

    // 7. User B tries to fetch User A's profile by ID -> 404
    const bGetProfileRes = await requestJson(env.baseUrl, `/api/v1/profiles/${profileAId}`, { token: tokenB });
    assert.strictEqual(bGetProfileRes.status, 404, 'User B must not fetch User A profile');

    // 8. User B tries to delete User A's profile by ID -> 404
    const bDeleteProfileRes = await requestJson(env.baseUrl, `/api/v1/profiles/${profileAId}`, {
      method: 'DELETE',
      token: tokenB,
    });
    assert.strictEqual(bDeleteProfileRes.status, 404, 'User B must not delete User A profile');

    // 9. User B lists listings -> empty
    const bListingsRes = await requestJson(env.baseUrl, '/api/v1/listings', { token: tokenB });
    assert.strictEqual(bListingsRes.body.length, 0, 'User B must not see User A listings');

    // 10. User B tries to delete User A's listing -> 404
    const bDeleteListingRes = await requestJson(env.baseUrl, `/api/v1/listings/${listingAId}`, {
      method: 'DELETE',
      token: tokenB,
    });
    assert.strictEqual(bDeleteListingRes.status, 404, 'User B must not delete User A listing');

    // 11. User B lists API keys -> empty
    const bKeysRes = await requestJson(env.baseUrl, '/api/v1/api-keys', { token: tokenB });
    assert.strictEqual(bKeysRes.body.length, 0, 'User B must not see User A API keys');

    // 12. User B tries to revoke User A's key -> 404
    const bRevokeKeyRes = await requestJson(env.baseUrl, `/api/v1/api-keys/${keyAId}/revoke`, {
      method: 'POST',
      token: tokenB,
    });
    assert.strictEqual(bRevokeKeyRes.status, 404, 'User B must not revoke User A API key');

    // --- VERIFY USER B's BOT CANNOT CLAIM/COMPLETE USER A's COMMANDS ---

    // 13. User A dispatches a command destined for their own bot
    const cmdARes = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token: tokenA,
      body: {
        command_id: 'cmd_isolation_a1',
        profile_id: profileAId,
        type: 'REOPEN_CHROME_PROFILE',
        payload: '{"action":"REOPEN_CHROME_PROFILE"}',
      },
    });
    assert.strictEqual(cmdARes.status, 200);
    assert.strictEqual(cmdARes.body.status, 'PENDING');

    // 14. User B sets up their own profile and bot key
    const profileBRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token: tokenB,
      body: { name: 'User B Profile', account_label: 'Account B' },
    });
    const profileBId = profileBRes.body.id;
    const keyBRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token: tokenB,
      body: { profile_id: profileBId },
    });
    const botKeyB = keyBRes.body.api_key;

    // 15. User B's bot must not be able to claim/complete User A's command by guessing its ID
    const bStatusRes = await requestJson(env.baseUrl, '/api/v1/bot/commands/cmd_isolation_a1/status', {
      method: 'POST',
      botKey: botKeyB,
      body: { status: 'COMPLETED', result_message: 'Hijacked by User B bot' },
    });
    assert.strictEqual(bStatusRes.status, 404, "User B's bot must not update User A's command");

    // 16. User A verifies their command is untouched and still PENDING
    const cmdACheckRes = await requestJson(env.baseUrl, '/api/v1/commands/cmd_isolation_a1', { token: tokenA });
    assert.strictEqual(cmdACheckRes.status, 200);
    assert.strictEqual(cmdACheckRes.body.status, 'PENDING', "User A's command must remain untouched");

    // --- VERIFY INCOMING BOT MESSAGES ARE SCOPED BY (user, profile), NOT JUST conversationId ---

    // 17. Set up a real conversation under User A's profile
    const custA = customerRepository.findOrCreateCustomer(userIdA, 'ext_cust_isolation', 'Isolation Customer');
    const convA = conversationRepository.createConversation({
      id: 'conv_isolation_a1',
      userId: userIdA,
      profileId: profileAId,
      listingId: listingAId,
      customerId: custA.id,
    });

    // 18. Cross-tenant: User B's bot (their own valid key) must not be able to inject a message
    // into User A's conversation by supplying User A's conversationId
    const crossTenantMsgRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey: botKeyB,
      body: { conversationId: convA.id, text: 'Injected from User B bot' },
    });
    assert.strictEqual(crossTenantMsgRes.status, 404, "User B's bot must not post into User A's conversation");

    // 19. Same-tenant, wrong-profile: User A has a second profile with its own bot key;
    // that bot must not be able to post into a conversation that belongs to User A's first profile
    const profileA2Res = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token: tokenA,
      body: { name: 'User A Second Profile', account_label: 'Account A2' },
    });
    const profileA2Id = profileA2Res.body.id;
    const keyA2Res = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token: tokenA,
      body: { profile_id: profileA2Id },
    });
    const botKeyA2 = keyA2Res.body.api_key;

    const crossProfileMsgRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey: botKeyA2,
      body: { conversationId: convA.id, text: 'Injected from wrong profile bot' },
    });
    assert.strictEqual(
      crossProfileMsgRes.status,
      404,
      "User A's second-profile bot must not post into the first profile's conversation"
    );

    // 20. Verify no message was actually created in User A's conversation by either attempt
    const convAMessagesRes = await requestJson(env.baseUrl, `/api/v1/conversations/${convA.id}/messages`, { token: tokenA });
    assert.strictEqual(convAMessagesRes.status, 200);
    assert.strictEqual(convAMessagesRes.body.length, 0, 'No cross-tenant or cross-profile message must have been inserted');

    // 21. The legitimate bot for this exact profile CAN post into it
    const legitMsgRes = await requestJson(env.baseUrl, '/api/v1/bot/messages', {
      method: 'POST',
      botKey: keyARes.body.api_key,
      body: { conversationId: convA.id, text: 'Legitimate message from correct bot' },
    });
    assert.strictEqual(legitMsgRes.status, 201, "The bot for User A's own profile must be able to post");

    // --- VERIFY API-KEY CREATION CANNOT ADOPT ANOTHER USER'S BOT VIA :botId ---

    // 22. User A explicitly registers a Bot record
    const botARes = await requestJson(env.baseUrl, '/api/v1/bot/bots', {
      method: 'POST',
      token: tokenA,
      body: { name: 'User A Explicit Bot' },
    });
    assert.strictEqual(botARes.status, 201);
    const botIdA = botARes.body.id;

    // 23. User B tries to mint an API key for their own profile but pinned to User A's bot ID
    const hijackBotKeyRes = await requestJson(env.baseUrl, `/api/v1/bot/bots/${botIdA}/api-keys`, {
      method: 'POST',
      token: tokenB,
      body: { profile_id: profileBId },
    });
    assert.strictEqual(hijackBotKeyRes.status, 404, "User B must not be able to mint a key using User A's bot ID");

    // 24. Verify no API key was created for User B that references User A's bot
    const userBKeys = apiKeyRepository.findByUserId(userIdB);
    assert.ok(
      userBKeys.every(k => k.bot_id !== botIdA),
      "No API key belonging to User B may reference User A's bot"
    );

    // 25. User A themselves can still mint a key using their own explicit bot ID (legitimate path)
    const legitBotKeyRes = await requestJson(env.baseUrl, `/api/v1/bot/bots/${botIdA}/api-keys`, {
      method: 'POST',
      token: tokenA,
      body: { profile_id: profileAId },
    });
    assert.strictEqual(legitBotKeyRes.status, 201, "User A must be able to mint a key using their own bot ID");

    console.log('✓ All Multi-User Isolation tests passed!');
  } finally {
    await env.close();
  }
}
