import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';
import { decodeCursor } from '../src/utils/crypto';
import { customerRepository } from '../src/repositories/customerRepository';
import { conversationRepository } from '../src/repositories/conversationRepository';

export async function runDeltaSyncTests() {
  console.log('--- Running Delta Sync Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Setup user
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'synctest@marketplace.local', password: 'Password123!', name: 'Sync User' },
    });
    const token = userRes.body.token;

    // 2. Initial sync (no cursor) -> returns initial (empty) state
    const sync1 = await requestJson(env.baseUrl, '/api/v1/sync', { token });
    assert.strictEqual(sync1.status, 200);
    assert.ok(sync1.body.cursor, 'Must return cursor');
    assert.strictEqual(typeof sync1.body.cursor, 'string');
    assert.strictEqual(sync1.body.profiles.length, 0);
    const cursor1 = sync1.body.cursor;

    // 3. Create a profile (this now emits a PROFILE_CREATED event into the log)
    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Delta Profile', account_label: 'Delta Label' },
    });
    assert.strictEqual(profileRes.status, 201);
    const profileAId = profileRes.body.id;

    // 4. Cursor-based sync with the cursor from before the profile existed -> returns exactly the new profile
    const sync2 = await requestJson(env.baseUrl, `/api/v1/sync?cursor=${encodeURIComponent(cursor1)}`, { token });
    assert.strictEqual(sync2.status, 200);
    assert.ok(sync2.body.cursor, 'Must return new cursor');
    assert.strictEqual(sync2.body.profiles.length, 1);
    assert.strictEqual(sync2.body.profiles[0].name, 'Delta Profile');
    const cursor2 = sync2.body.cursor;

    // cursor must actually advance (real sequence-based cursor, not a static/unused value)
    assert.ok(decodeCursor(cursor2) > decodeCursor(cursor1), 'next_cursor must advance past the previous cursor');

    // 5. Sync again with the NEW cursor, no new changes in between -> must return nothing new,
    // and the cursor's underlying sequence must stay stable (repeated/no-op sync does not
    // duplicate old data). The cursor is opaque and also embeds a generation timestamp, so two
    // cursors pointing at the same sequence are not necessarily byte-identical strings — what
    // must match is the decoded sequence number.
    const sync3 = await requestJson(env.baseUrl, `/api/v1/sync?cursor=${encodeURIComponent(cursor2)}`, { token });
    assert.strictEqual(sync3.status, 200);
    assert.strictEqual(sync3.body.profiles.length, 0, 'No new events means no profiles should be returned');
    assert.strictEqual(
      decodeCursor(sync3.body.cursor),
      decodeCursor(cursor2),
      'Cursor sequence must not advance when there is nothing new'
    );

    // 6. Create a SECOND profile, then sync with cursor2 -> must return ONLY the second profile,
    // never re-returning the first (already-synced) one
    const profileRes2 = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Second Delta Profile', account_label: 'Delta Label 2' },
    });
    assert.strictEqual(profileRes2.status, 201);
    const profileBId = profileRes2.body.id;

    const sync4 = await requestJson(env.baseUrl, `/api/v1/sync?cursor=${encodeURIComponent(cursor2)}`, { token });
    assert.strictEqual(sync4.status, 200);
    assert.strictEqual(sync4.body.profiles.length, 1, 'Only the newly created profile must be returned');
    assert.strictEqual(sync4.body.profiles[0].id, profileBId);
    assert.notStrictEqual(sync4.body.profiles[0].id, profileAId, 'The already-synced first profile must not reappear');
    const cursor3 = sync4.body.cursor;
    assert.ok(decodeCursor(cursor3) > decodeCursor(cursor2), 'Cursor must advance again after new activity');

    // 7. Replaying the OLDEST cursor (cursor1) must deterministically return BOTH profiles created
    // since that point -- proving the cursor is a real event-sequence position, not a one-shot token
    const sync5 = await requestJson(env.baseUrl, `/api/v1/sync?cursor=${encodeURIComponent(cursor1)}`, { token });
    assert.strictEqual(sync5.status, 200);
    assert.strictEqual(sync5.body.profiles.length, 2, 'Replaying an older cursor must return every change since that point');
    const returnedIds = sync5.body.profiles.map((p: any) => p.id).sort();
    assert.deepStrictEqual(returnedIds, [profileAId, profileBId].sort());

    // 8. Message-level cursor correctness: set up a conversation, send a message, and verify the
    // cursor sync surfaces exactly that new message and nothing stale
    const userId = userRes.body.user.id;

    const listingRes = await requestJson(env.baseUrl, '/api/v1/listings', {
      method: 'POST',
      token,
      body: { profile_id: profileAId, title: 'Sync Test Item', price: 42.0 },
    });
    const listingId = listingRes.body.id;
    const customer = customerRepository.findOrCreateCustomer(userId, 'ext_sync_cust', 'Sync Customer');
    const conversation = conversationRepository.createConversation({
      id: 'conv_sync_1',
      userId,
      profileId: profileAId,
      listingId,
      customerId: customer.id,
    });

    const cursorBeforeMessage = (
      await requestJson(env.baseUrl, `/api/v1/sync?cursor=${encodeURIComponent(cursor3)}`, { token })
    ).body.cursor;

    const sendRes = await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, {
      method: 'POST',
      token,
      body: { text: 'Hello from delta sync test', command_id: 'cmd_sync_msg_1' },
    });
    assert.strictEqual(sendRes.status, 201);

    const syncAfterMessage = await requestJson(
      env.baseUrl,
      `/api/v1/sync?cursor=${encodeURIComponent(cursorBeforeMessage)}`,
      { token }
    );
    assert.strictEqual(syncAfterMessage.status, 200);
    assert.strictEqual(syncAfterMessage.body.messages.length, 1, 'Exactly the one new message must be returned');
    assert.strictEqual(syncAfterMessage.body.messages[0].text, 'Hello from delta sync test');
    const cursorAfterMessage = syncAfterMessage.body.cursor;

    // 9. Syncing again with the post-message cursor returns no duplicate of that message
    const syncNoDuplicate = await requestJson(
      env.baseUrl,
      `/api/v1/sync?cursor=${encodeURIComponent(cursorAfterMessage)}`,
      { token }
    );
    assert.strictEqual(syncNoDuplicate.status, 200);
    assert.strictEqual(syncNoDuplicate.body.messages.length, 0, 'The already-synced message must not be returned again');

    // --- MINIMAL TRUE DELTA PAYLOADS ---
    // 10. Build up real history in this conversation (several more messages), THEN capture a
    // fresh cursor and send exactly ONE more. A minimal delta must return only that one message
    // — not the whole conversation's accumulated history just because the conversation changed.
    for (let i = 0; i < 6; i++) {
      await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, {
        method: 'POST',
        token,
        body: { text: `History filler message #${i}` },
      });
    }
    const cursorBeforeMinimalTest = (
      await requestJson(env.baseUrl, `/api/v1/sync?cursor=${encodeURIComponent(cursorAfterMessage)}`, { token })
    ).body.cursor;

    const historyCountBefore = (
      await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, { token })
    ).body.length;
    assert.ok(historyCountBefore >= 7, 'Sanity check: the conversation must actually have accumulated real history by now');

    await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, {
      method: 'POST',
      token,
      body: { text: 'The one truly new message' },
    });

    const minimalSync = await requestJson(
      env.baseUrl,
      `/api/v1/sync?cursor=${encodeURIComponent(cursorBeforeMinimalTest)}`,
      { token }
    );
    assert.strictEqual(minimalSync.status, 200);
    assert.strictEqual(
      minimalSync.body.messages.length,
      1,
      `A delta sync after one new message must return exactly 1 message, not the conversation's full history (got ${minimalSync.body.messages.length})`
    );
    assert.strictEqual(minimalSync.body.messages[0].text, 'The one truly new message');

    console.log('✓ All Delta Sync tests passed!');
  } finally {
    await env.close();
  }
}
