import http from 'http';
import { createApp } from '../src/app';
import { setupWebSocketServer } from '../src/websocket/wsServer';
import { getDatabase, closeDatabase } from '../src/db/database';
import fs from 'fs';
import path from 'path';

export interface TestContext {
  server: http.Server;
  baseUrl: string;
  wsUrl: string;
  dbPath: string;
  close: () => Promise<void>;
}

export async function createTestEnvironment(): Promise<TestContext> {
  const dbPath = path.resolve(__dirname, `../test_${Date.now()}_${Math.random().toString(36).substring(7)}.db`);
  process.env.DATABASE_FILE = dbPath;

  // Reset database instance
  closeDatabase();
  const db = getDatabase(dbPath);

  const app = createApp();
  const server = http.createServer(app);
  const wss = setupWebSocketServer(server);

  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  const addr = server.address() as { port: number; address: string };
  const baseUrl = `http://127.0.0.1:${addr.port}`;
  const wsUrl = `ws://127.0.0.1:${addr.port}/api/v1/events`;

  const close = async () => {
    // server.close()'s callback only fires once every connection has ended on its own — a single
    // WebSocket left open by a test (or one mid-handshake) can otherwise hang cleanup forever and
    // stall every subsequent suite in the same process. Force-terminate everything first, and
    // never block indefinitely regardless.
    wss.close();
    for (const client of wss.clients) {
      try { client.terminate(); } catch {}
    }
    server.closeAllConnections();
    await new Promise<void>((res) => {
      const timer = setTimeout(res, 2000);
      server.close(() => {
        clearTimeout(timer);
        res();
      });
    });
    closeDatabase();
    try {
      if (fs.existsSync(dbPath)) fs.unlinkSync(dbPath);
      if (fs.existsSync(`${dbPath}-wal`)) fs.unlinkSync(`${dbPath}-wal`);
      if (fs.existsSync(`${dbPath}-shm`)) fs.unlinkSync(`${dbPath}-shm`);
    } catch {}
  };

  return {
    server,
    baseUrl,
    wsUrl,
    dbPath,
    close,
  };
}

export async function requestJson(
  baseUrl: string,
  path: string,
  options: {
    method?: string;
    token?: string;
    botKey?: string;
    body?: any;
  } = {}
): Promise<{ status: number; body: any; headers: Headers }> {
  const url = `${baseUrl}${path}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  if (options.token) {
    headers['Authorization'] = `Bearer ${options.token}`;
  }
  if (options.botKey) {
    // Bot auth uses exactly one convention: Authorization: Bearer mpc_live_...
    // (no X-Bot-Key), so tests only ever exercise the supported mechanism.
    headers['Authorization'] = `Bearer ${options.botKey}`;
  }

  const response = await fetch(url, {
    method: options.method || 'GET',
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  let body: any = null;
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    body = await response.json();
  } else {
    body = await response.text();
  }

  return {
    status: response.status,
    body,
    headers: response.headers,
  };
}
