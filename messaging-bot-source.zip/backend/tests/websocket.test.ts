import assert from 'assert';
import WebSocket from 'ws';
import { createTestEnvironment, requestJson } from './test_helpers';
import { customerRepository } from '../src/repositories/customerRepository';
import { conversationRepository } from '../src/repositories/conversationRepository';

export async function runWebSocketTests() {
  console.log('--- Running WebSocket Real-Time Event Tests ---');
  const env = await createTestEnvironment();

  try {
    // 1. Setup user
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'wstest@marketplace.local', password: 'Password123!', name: 'WS User' },
    });
    const token = userRes.body.token;
    const userId = userRes.body.user.id;

    // 2. Setup profile & bot key
    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'WS Chrome', account_label: 'WS Store' },
    });
    const profileId = profileRes.body.id;

    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    const botKey = keyRes.body.api_key;

    // 3. Connect WebSocket client with User JWT in Authorization header
    const receivedEvents: any[] = [];
    const ws = new WebSocket(env.wsUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    await new Promise<void>((resolve, reject) => {
      ws.on('open', () => resolve());
      ws.on('error', (err) => reject(err));
      ws.on('message', (data) => {
        try {
          const parsed = JSON.parse(data.toString('utf-8'));
          receivedEvents.push(parsed);
        } catch {}
      });
    });

    assert.strictEqual(ws.readyState, WebSocket.OPEN, 'WebSocket connection must be OPEN');

    // 4. Trigger a BOT_HEARTBEAT event via HTTP
    await requestJson(env.baseUrl, '/api/v1/bot/heartbeat', {
      method: 'POST',
      botKey,
      body: {
        profile_id: profileId,
        status: 'BUSY',
        current_task: 'Processing orders',
        timestamp: Date.now(),
      },
    });

    // Wait a brief moment for event transmission
    await new Promise((r) => setTimeout(r, 100));

    // Verify event received
    assert.ok(receivedEvents.length >= 1, 'Should receive real-time event on WebSocket');
    const hbEvent = receivedEvents.find((e) => e.eventType === 'BOT_HEARTBEAT');
    assert.ok(hbEvent, 'Should receive BOT_HEARTBEAT event');
    assert.ok(hbEvent.eventId, 'Event must have eventId');
    assert.strictEqual(typeof hbEvent.payload, 'string', 'Payload must be a JSON string as expected by Moshi');
    const payloadObj = JSON.parse(hbEvent.payload);
    assert.strictEqual(payloadObj.status, 'BUSY');

    // Close socket
    ws.close();

    // 5. Test unauthenticated WebSocket connection -> must fail
    let unauthFailed = false;
    try {
      const badWs = new WebSocket(env.wsUrl);
      await new Promise<void>((resolve, reject) => {
        badWs.on('open', () => resolve());
        badWs.on('error', () => {
          unauthFailed = true;
          resolve();
        });
      });
      badWs.close();
    } catch {
      unauthFailed = true;
    }
    assert.ok(unauthFailed, 'Unauthenticated WebSocket connection must be rejected');

    // 6. Bot API key must NOT be accepted via ?botKey= query string (URLs get logged) -> must fail
    const botWsUrl = env.wsUrl.replace('/api/v1/events', '/api/v1/bot/ws');
    let queryStringKeyRejected = false;
    try {
      const queryWs = new WebSocket(`${botWsUrl}?botKey=${encodeURIComponent(botKey)}`);
      await new Promise<void>((resolve, reject) => {
        queryWs.on('open', () => resolve());
        queryWs.on('error', () => {
          queryStringKeyRejected = true;
          resolve();
        });
      });
      queryWs.close();
    } catch {
      queryStringKeyRejected = true;
    }
    assert.ok(queryStringKeyRejected, 'Bot key supplied via ?botKey= query string must be rejected');

    // 7. Bot authentication uses exactly one convention everywhere: Authorization: Bearer mpc_live_...
    const bearerWs = new WebSocket(botWsUrl, { headers: { Authorization: `Bearer ${botKey}` } });
    await new Promise<void>((resolve, reject) => {
      bearerWs.on('open', () => resolve());
      bearerWs.on('error', (err) => reject(err));
    });
    assert.strictEqual(bearerWs.readyState, WebSocket.OPEN, 'Bot key via Authorization: Bearer must work');
    bearerWs.close();
    await new Promise((r) => setTimeout(r, 50));

    // The old X-Bot-Key header is no longer a supported bot-auth mechanism -> must be rejected
    let xBotKeyRejected = false;
    try {
      const xBotKeyWs = new WebSocket(botWsUrl, { headers: { 'X-Bot-Key': botKey } });
      await new Promise<void>((resolve, reject) => {
        xBotKeyWs.on('open', () => resolve());
        xBotKeyWs.on('error', () => {
          xBotKeyRejected = true;
          resolve();
        });
      });
      xBotKeyWs.close();
    } catch {
      xBotKeyRejected = true;
    }
    assert.ok(xBotKeyRejected, 'X-Bot-Key header must no longer be accepted for WebSocket bot auth');
    await new Promise((r) => setTimeout(r, 50));

    // 8. Only ONE live bot connection is allowed per profile. A second connection for the same
    // profile must evict the first, so a command can never be delivered to two bot processes.
    const messagesA: any[] = [];
    const messagesB: any[] = [];
    let closeCodeA: number | null = null;

    const botSocketA = new WebSocket(botWsUrl, { headers: { Authorization: `Bearer ${botKey}` } });
    await new Promise<void>((resolve, reject) => {
      botSocketA.on('open', () => resolve());
      botSocketA.on('error', (err) => reject(err));
    });
    botSocketA.on('message', (data) => {
      try { messagesA.push(JSON.parse(data.toString('utf-8'))); } catch {}
    });
    botSocketA.on('close', (code) => { closeCodeA = code; });

    const botSocketB = new WebSocket(botWsUrl, { headers: { Authorization: `Bearer ${botKey}` } });
    await new Promise<void>((resolve, reject) => {
      botSocketB.on('open', () => resolve());
      botSocketB.on('error', (err) => reject(err));
    });
    botSocketB.on('message', (data) => {
      try { messagesB.push(JSON.parse(data.toString('utf-8'))); } catch {}
    });

    // Give the server a moment to complete the eviction close handshake
    await new Promise((r) => setTimeout(r, 150));
    assert.strictEqual(
      botSocketA.readyState,
      WebSocket.CLOSED,
      'First bot connection must be closed when a second one connects for the same profile'
    );
    assert.strictEqual(closeCodeA, 4001, 'Superseded bot connection must be closed with code 4001');

    // 9. Dispatch a command and verify it reaches ONLY the surviving connection (B), never the evicted one (A)
    const dispatchRes = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: {
        profile_id: profileId,
        type: 'REOPEN_CHROME_PROFILE',
        payload: '{"action":"REOPEN_CHROME_PROFILE"}',
      },
    });
    assert.strictEqual(dispatchRes.status, 200);

    await new Promise((r) => setTimeout(r, 150));
    const execEventsB = messagesB.filter((m: any) => m.type === 'EXECUTE_COMMAND');
    const execEventsA = messagesA.filter((m: any) => m.type === 'EXECUTE_COMMAND');
    assert.strictEqual(execEventsB.length, 1, 'The surviving bot connection must receive exactly one EXECUTE_COMMAND');
    assert.strictEqual(execEventsA.length, 0, 'The evicted bot connection must never receive the command');

    botSocketB.close();

    console.log('✓ All WebSocket tests passed!');
  } finally {
    await env.close();
  }
}
