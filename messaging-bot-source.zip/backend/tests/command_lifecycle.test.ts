import assert from 'assert';
import WebSocket from 'ws';
import { createTestEnvironment, requestJson } from './test_helpers';
import { customerRepository } from '../src/repositories/customerRepository';
import { conversationRepository } from '../src/repositories/conversationRepository';
import { getDatabase } from '../src/db/database';

function connectCollectingMessages(url: string, headers: Record<string, string>): { ws: WebSocket; messages: any[]; ready: Promise<void> } {
  const ws = new WebSocket(url, { headers });
  const messages: any[] = [];
  ws.on('message', (data) => {
    try { messages.push(JSON.parse(data.toString('utf-8'))); } catch {}
  });
  const ready = new Promise<void>((resolve, reject) => {
    ws.on('open', () => resolve());
    ws.on('error', (err) => reject(err));
  });
  return { ws, messages, ready };
}

/**
 * Walks the exact documented command lifecycle end-to-end, live over WebSockets on both sides:
 *
 *   Android            Backend                      Bot
 *   -------            -------                      ---
 *   sends message  ->  creates command (PENDING)
 *                                                     connects (WS) -> resume-pushes the
 *                                                     still-uncompleted command
 *                                                     claims it -> PROCESSING
 *                      (Android's own WS sees the PROCESSING update live)
 *                                                     executes, reports result -> COMPLETED
 *                      (Android's own WS sees the COMPLETED update + message -> SENT, live)
 *
 * This is deliberately distinct from e2e_lifecycle.test.ts (which drives the bot side via HTTP
 * polling of GET /commands/pending) and from reconnect_watchdog.test.ts (which exercises the
 * WS resume/reconnect mechanics in isolation, not via a real Android-initiated message send).
 * Here both halves are combined, over live sockets, in the exact order the lifecycle is meant
 * to happen in production.
 */
export async function runCommandLifecycleTests() {
  console.log('--- Running Full Command Lifecycle Test (Android -> PENDING -> Bot connects -> PROCESSING -> COMPLETED) ---');
  const env = await createTestEnvironment();

  try {
    // --- Setup ---
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'lifecycle@marketplace.local', password: 'Password123!', name: 'Lifecycle Tester' },
    });
    const token = userRes.body.token;
    const userId = userRes.body.user.id;

    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Lifecycle Chrome', account_label: 'Lifecycle Label' },
    });
    const profileId = profileRes.body.id;
    assert.strictEqual(profileRes.body.status, 'OFFLINE', 'Starts OFFLINE — no bot has connected yet');

    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    const botKey = keyRes.body.api_key;

    const listingRes = await requestJson(env.baseUrl, '/api/v1/listings', {
      method: 'POST',
      token,
      body: { profile_id: profileId, title: 'Lifecycle Test Camera', price: 500.0 },
    });
    const customer = customerRepository.findOrCreateCustomer(userId, 'ext_lifecycle_cust', 'Lifecycle Customer');
    const conversation = conversationRepository.createConversation({
      id: 'conv_lifecycle_1',
      userId,
      profileId,
      listingId: listingRes.body.id,
      customerId: customer.id,
    });

    // Android's own WebSocket, connected up front, watching everything live
    const androidWsUrl = env.wsUrl;
    const android = connectCollectingMessages(androidWsUrl, { Authorization: `Bearer ${token}` });
    await android.ready;

    // --- Step 1: Android sends a message -> Backend creates the command as PENDING ---
    const sendRes = await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, {
      method: 'POST',
      token,
      body: { text: 'Is this still available?', command_id: 'cmd_full_lifecycle', idempotency_key: 'idemp_full_lifecycle' },
    });
    assert.strictEqual(sendRes.status, 201);

    const db = getDatabase();
    const createdRow = db.prepare("SELECT status FROM commands WHERE id = 'cmd_full_lifecycle'").get() as { status: string };
    assert.strictEqual(createdRow.status, 'PENDING', 'Backend must create the command as PENDING, before any bot exists');

    // --- Step 2: Bot connects (WebSocket) -> re-authenticates, restores ONLINE, and the
    // still-uncompleted command is identified and safely resumed (pushed) to it ---
    const botWsUrl = env.wsUrl.replace('/api/v1/events', '/api/v1/bot/ws');
    const bot = connectCollectingMessages(botWsUrl, { Authorization: `Bearer ${botKey}` });
    await bot.ready;
    await new Promise((r) => setTimeout(r, 150));

    const profileAfterConnect = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(profileAfterConnect.body.status, 'ONLINE', 'Bot connecting must bring the profile ONLINE');

    const pushedToBot = bot.messages.find((m) => m.type === 'EXECUTE_COMMAND' && m.commandId === 'cmd_full_lifecycle');
    assert.ok(pushedToBot, 'The PENDING command must be identified and pushed to the bot as soon as it connects');

    // --- Step 3: Bot claims it -> PROCESSING (atomic; this IS the claim/ack step) ---
    const claimRes = await requestJson(env.baseUrl, `/api/v1/bot/commands/cmd_full_lifecycle/status`, {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(claimRes.status, 200);
    assert.strictEqual(claimRes.body.status, 'PROCESSING');

    await new Promise((r) => setTimeout(r, 150));

    // Android must see the PROCESSING transition live, without polling
    const processingEvent = android.messages.find(
      (m) => m.eventType === 'COMMAND_STATUS_UPDATE' && JSON.parse(m.payload).commandId === 'cmd_full_lifecycle' && JSON.parse(m.payload).status === 'PROCESSING'
    );
    assert.ok(processingEvent, "Android's own WebSocket must see the command reach PROCESSING in real time");

    // A second bot connection cannot also claim this — proves the state machine is genuinely
    // guarding this specific in-flight command, not just working "in general" elsewhere
    const botTwoKeyRes = await requestJson(env.baseUrl, '/api/v1/bot/bots', { method: 'POST', token, body: { name: 'Second Bot' } });
    const botTwoApiKeyRes = await requestJson(env.baseUrl, `/api/v1/bot/bots/${botTwoKeyRes.body.id}/api-keys`, {
      method: 'POST',
      token,
      body: { profile_id: profileId },
    });
    const rivalClaimRes = await requestJson(env.baseUrl, `/api/v1/bot/commands/cmd_full_lifecycle/status`, {
      method: 'POST',
      botKey: botTwoApiKeyRes.body.api_key,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(rivalClaimRes.status, 404, 'A different bot must never be able to claim a command already claimed by another');

    // --- Step 4: Bot executes and reports the result -> COMPLETED ---
    const completeRes = await requestJson(env.baseUrl, `/api/v1/bot/commands/cmd_full_lifecycle/status`, {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED', result_message: 'Message delivered on Facebook Marketplace' },
    });
    assert.strictEqual(completeRes.status, 200);
    assert.strictEqual(completeRes.body.status, 'COMPLETED');
    assert.ok(completeRes.body.completed_at, 'completed_at must be populated');

    await new Promise((r) => setTimeout(r, 150));

    // Android must see BOTH the command's COMPLETED status and the linked message's SENT status, live
    const completedEvent = android.messages.find(
      (m) => m.eventType === 'COMMAND_STATUS_UPDATE' && JSON.parse(m.payload).commandId === 'cmd_full_lifecycle' && JSON.parse(m.payload).status === 'COMPLETED'
    );
    assert.ok(completedEvent, "Android's own WebSocket must see the command reach COMPLETED in real time");

    // The claim (PROCESSING) step ALSO publishes a MESSAGE_STATUS_UPDATE (message -> PROCESSING),
    // so there are two for this command by now — find the one reporting SENT specifically.
    const messageSentEvent = android.messages.find(
      (m) => m.eventType === 'MESSAGE_STATUS_UPDATE' && JSON.parse(m.payload).commandId === 'cmd_full_lifecycle' && JSON.parse(m.payload).status === 'SENT'
    );
    assert.ok(messageSentEvent, "Android's own WebSocket must see the linked message reach SENT in real time");

    // --- Final state verification: durable, not just observed transiently over the sockets ---
    const finalCmd = await requestJson(env.baseUrl, '/api/v1/commands/cmd_full_lifecycle', { token });
    assert.strictEqual(finalCmd.body.status, 'COMPLETED');

    const finalMessages = await requestJson(env.baseUrl, `/api/v1/conversations/${conversation.id}/messages`, { token });
    const sentMessage = finalMessages.body.find((m: any) => m.command_id === 'cmd_full_lifecycle');
    assert.ok(sentMessage, 'The message tied to this command must exist');
    assert.strictEqual(sentMessage.status, 'SENT');

    // --- Idempotency / no duplicate execution: replaying the claim or the completion after the
    // fact must never re-trigger anything ---
    const replayClaimRes = await requestJson(env.baseUrl, `/api/v1/bot/commands/cmd_full_lifecycle/status`, {
      method: 'POST',
      botKey,
      body: { status: 'PROCESSING' },
    });
    assert.strictEqual(replayClaimRes.status, 404, 'A completed command must never be reopened to PROCESSING');

    const replayCompleteRes = await requestJson(env.baseUrl, `/api/v1/bot/commands/cmd_full_lifecycle/status`, {
      method: 'POST',
      botKey,
      body: { status: 'COMPLETED', result_message: 'a different, later duplicate report' },
    });
    assert.strictEqual(replayCompleteRes.status, 200, 'Re-confirming the same terminal status must succeed as an idempotent no-op');
    assert.strictEqual(
      replayCompleteRes.body.result_message,
      'Message delivered on Facebook Marketplace',
      'The original result must be preserved — the duplicate report must not overwrite it'
    );

    android.ws.close();
    bot.ws.close();
    console.log('✓ Full Command Lifecycle test passed: Android -> PENDING -> Bot connects -> PROCESSING -> COMPLETED!');
  } finally {
    await env.close();
  }
}
