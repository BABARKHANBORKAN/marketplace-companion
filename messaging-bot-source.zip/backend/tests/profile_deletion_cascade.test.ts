import assert from 'assert';
import { createTestEnvironment, requestJson } from './test_helpers';
import { getDatabase } from '../src/db/database';

/**
 * Regression coverage for: deleting a profile must also clean up everything that was never
 * wired with a cascading foreign key to chrome_profiles — specifically bot_api_keys (which has
 * no FK to chrome_profiles at all) and commands (same). Without this, a "deleted" profile left
 * behind a dangling-but-still-ACTIVE bot key a Desktop Bot could keep authenticating with, plus
 * orphaned queued commands referencing a profile that no longer exists.
 */
export async function runProfileDeletionCascadeTests() {
  console.log('--- Running Profile Deletion Cascade Tests ---');
  const env = await createTestEnvironment();

  try {
    const userRes = await requestJson(env.baseUrl, '/api/v1/auth/register', {
      method: 'POST',
      body: { email: 'profiledelete@marketplace.local', password: 'Password123!', name: 'Profile Deleter' },
    });
    const token = userRes.body.token;

    const profileRes = await requestJson(env.baseUrl, '/api/v1/profiles', {
      method: 'POST',
      token,
      body: { name: 'Doomed Chrome', account_label: 'Seller Account' },
    });
    const profileId = profileRes.body.id;

    const keyRes = await requestJson(env.baseUrl, '/api/v1/api-keys', {
      method: 'POST',
      token,
      body: { profile_id: profileId, server_url: env.baseUrl },
    });
    assert.strictEqual(keyRes.status, 201);
    const keyId = keyRes.body.id;

    // Dispatch a command for the profile (as the owning user, same path the Android app uses).
    const dispatchRes = await requestJson(env.baseUrl, '/api/v1/commands', {
      method: 'POST',
      token,
      body: { command_id: 'cmd_delete_cascade_1', profile_id: profileId, type: 'STOP_CURRENT_TASK', payload: '{}' },
    });
    assert.strictEqual(dispatchRes.status, 200, 'Command dispatch must succeed before testing cascade');

    // Sanity: both rows actually exist before deletion.
    const db = getDatabase();
    const keyBefore = db.prepare('SELECT * FROM bot_api_keys WHERE id = ?').get(keyId);
    assert.ok(keyBefore, 'API key must exist before profile deletion');
    const commandsBefore = db.prepare('SELECT * FROM commands WHERE profile_id = ?').all(profileId);
    assert.strictEqual(commandsBefore.length, 1, 'Command must exist before profile deletion');

    // Delete the profile.
    const deleteRes = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, {
      method: 'DELETE',
      token,
    });
    assert.strictEqual(deleteRes.status, 204, 'Profile deletion must succeed');

    // Profile itself is gone.
    const getProfileRes = await requestJson(env.baseUrl, `/api/v1/profiles/${profileId}`, { token });
    assert.strictEqual(getProfileRes.status, 404, 'Deleted profile must 404 on lookup');

    // The dangling API key must be gone too — not just left ACTIVE and unreachable.
    const keyAfter = db.prepare('SELECT * FROM bot_api_keys WHERE id = ?').get(keyId);
    assert.strictEqual(keyAfter, undefined, 'API key must be deleted along with its profile');

    // Confirmed via the list endpoint too (what the Android app actually reads).
    const keysListRes = await requestJson(env.baseUrl, '/api/v1/api-keys', { token });
    assert.ok(
      !keysListRes.body.some((k: any) => k.id === keyId),
      'Deleted profile\'s key must not appear in the key list'
    );

    // Orphaned commands must be purged, not left referencing a nonexistent profile forever.
    const commandsAfter = db.prepare('SELECT * FROM commands WHERE profile_id = ?').all(profileId);
    assert.strictEqual(commandsAfter.length, 0, 'Commands for a deleted profile must be purged');

    // A currently-connected bot using that key must get disconnected, and the cleanup must be
    // auditable — not a silent DB-only side effect.
    const auditRow = db.prepare(`
      SELECT * FROM security_events WHERE key_id = ? AND event_type = 'BOT_API_KEY_DELETED'
    `).get(keyId) as any;
    assert.ok(auditRow, 'Key deletion as part of profile deletion must be security-audit-logged');
    assert.strictEqual(auditRow.detail, 'Deleted as part of profile deletion');

    console.log('✓ All Profile Deletion Cascade tests passed!');
  } finally {
    await env.close();
  }
}
