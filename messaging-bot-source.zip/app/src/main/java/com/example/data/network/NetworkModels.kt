package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class LoginRequest(
    val email: String,
    val password: String
)

@JsonClass(generateAdapter = true)
data class RegisterRequest(
    val name: String,
    val email: String,
    val password: String
)

@JsonClass(generateAdapter = true)
data class RefreshTokenRequest(
    @Json(name = "refresh_token") val refreshToken: String
)

@JsonClass(generateAdapter = true)
data class ForgotPasswordRequest(
    val email: String
)

@JsonClass(generateAdapter = true)
data class AppsCodeLoginRequest(
    val code: String
)

@JsonClass(generateAdapter = true)
data class AuthResponse(
    @Json(name = "accessToken") val accessToken: String? = null,
    @Json(name = "token") val legacyToken: String? = null,
    @Json(name = "refreshToken") val refreshToken: String? = null,
    @Json(name = "refresh_token") val legacyRefreshToken: String? = null,
    @Json(name = "expiresIn") val expiresIn: Long? = null,
    val user: UserDto
) {
    // Standard accessors supporting both RFC standard camelCase and legacy snake_case fields
    val token: String get() = accessToken ?: legacyToken ?: ""
    val effectiveRefreshToken: String? get() = refreshToken ?: legacyRefreshToken
}

@JsonClass(generateAdapter = true)
data class UserDto(
    val id: String,
    val name: String,
    val email: String,
    val plan: String = "Pro"
)

@JsonClass(generateAdapter = true)
data class ChromeProfileDto(
    val id: String,
    @Json(name = "user_id") val userId: String? = null,
    val name: String,
    @Json(name = "account_label") val accountLabel: String,
    val status: String,
    @Json(name = "current_task") val currentTask: String? = "Idle",
    @Json(name = "last_seen") val lastSeen: Long? = null,
    @Json(name = "last_heartbeat") val lastHeartbeat: Long? = null,
    @Json(name = "listing_count") val listingCount: Int = 0,
    @Json(name = "conversation_count") val conversationCount: Int = 0,
    @Json(name = "unread_count") val unreadCount: Int = 0,
    @Json(name = "chrome_window_name") val chromeWindowName: String? = null,
    @Json(name = "bot_connected") val botConnected: Boolean = true
)

@JsonClass(generateAdapter = true)
data class CreateProfileRequest(
    val name: String,
    @Json(name = "account_label") val accountLabel: String
)

@JsonClass(generateAdapter = true)
data class DispatchCommandRequest(
    @Json(name = "command_id") val commandId: String,
    @Json(name = "idempotency_key") val idempotencyKey: String? = null,
    @Json(name = "profile_id") val profileId: String,
    val type: String,
    val payload: String,
    @Json(name = "conversation_id") val conversationId: String? = null,
    @Json(name = "customer_id") val customerId: String? = null,
    @Json(name = "listing_id") val listingId: String? = null,
    @Json(name = "message_id") val messageId: String? = null
)

@JsonClass(generateAdapter = true)
data class CommandResponse(
    val id: String,
    @Json(name = "idempotency_key") val idempotencyKey: String? = null,
    val status: String,
    @Json(name = "result_message") val resultMessage: String? = null,
    @Json(name = "completed_at") val completedAt: Long? = null,
    @Json(name = "error_code") val errorCode: String? = null,
    @Json(name = "error_message") val errorMessage: String? = null
)

@JsonClass(generateAdapter = true)
data class ConversationDto(
    val id: String,
    @Json(name = "profile_id") val profileId: String,
    @Json(name = "customer_id") val customerId: String,
    @Json(name = "customer_name") val customerName: String? = null,
    @Json(name = "listing_id") val listingId: String,
    @Json(name = "listing_title") val listingTitle: String? = null,
    @Json(name = "unread_count") val unreadCount: Int = 0,
    @Json(name = "last_message") val lastMessage: String? = "",
    @Json(name = "last_message_at") val lastMessageAt: Long = 0L,
    @Json(name = "is_pinned") val isPinned: Boolean = false
)

@JsonClass(generateAdapter = true)
data class MessageDto(
    val id: String,
    @Json(name = "conversation_id") val conversationId: String,
    val sender: String,
    val text: String,
    val status: String,
    val timestamp: Long,
    @Json(name = "command_id") val commandId: String? = null,
    @Json(name = "idempotency_key") val idempotencyKey: String? = null
)

@JsonClass(generateAdapter = true)
data class SendMessageRequest(
    @Json(name = "conversation_id") val conversationId: String,
    val text: String,
    @Json(name = "stop_task_first") val stopTaskFirst: Boolean = false,
    @Json(name = "reopen_chrome_first") val reopenChromeFirst: Boolean = false,
    @Json(name = "command_id") val commandId: String? = null,
    @Json(name = "idempotency_key") val idempotencyKey: String? = null
)

@JsonClass(generateAdapter = true)
data class ListingDto(
    val id: String,
    @Json(name = "profile_id") val profileId: String,
    val title: String,
    val price: Double,
    val currency: String = "USD",
    val status: String = "ACTIVE",
    val category: String = "General",
    val description: String = "",
    val location: String = "Local Area",
    @Json(name = "conversation_count") val conversationCount: Int = 0,
    @Json(name = "message_count") val messageCount: Int = 0,
    @Json(name = "created_at") val createdAt: Long = 0L,
    @Json(name = "image_url") val imageUrl: String = ""
)

@JsonClass(generateAdapter = true)
data class CreateListingRequest(
    @Json(name = "profile_id") val profileId: String,
    val title: String,
    val price: Double,
    val category: String,
    val description: String,
    val location: String = "Local Area"
)

@JsonClass(generateAdapter = true)
data class BotConnectionDto(
    val id: String,
    @Json(name = "profile_id") val profileId: String,
    @Json(name = "masked_key") val maskedKey: String? = null,
    @Json(name = "api_key") val apiKey: String? = null, // Only present once upon creation; excluded in read responses
    @Json(name = "server_url") val serverUrl: String,
    val status: String,
    @Json(name = "last_heartbeat") val lastHeartbeat: Long = 0L,
    @Json(name = "bot_version") val botVersion: String = "DesktopBot v1.0",
    @Json(name = "created_at") val createdAt: Long = 0L
)

@JsonClass(generateAdapter = true)
data class GenerateKeyRequest(
    @Json(name = "profile_id") val profileId: String,
    @Json(name = "server_url") val serverUrl: String
)

@JsonClass(generateAdapter = true)
data class BotHeartbeatRequest(
    @Json(name = "bot_id") val botId: String,
    @Json(name = "profile_id") val profileId: String,
    @Json(name = "bot_version") val botVersion: String,
    val status: String,
    @Json(name = "current_task") val currentTask: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class BotHeartbeatResponse(
    val acknowledged: Boolean,
    val timestamp: Long,
    @Json(name = "pending_commands_count") val pendingCommandsCount: Int = 0
)

@JsonClass(generateAdapter = true)
data class DeltaSyncResponse(
    val profiles: List<ChromeProfileDto>? = null,
    val conversations: List<ConversationDto>? = null,
    val messages: List<MessageDto>? = null,
    val listings: List<ListingDto>? = null,
    @Json(name = "completed_commands") val completedCommands: List<CommandResponse>? = null,
    @Json(name = "cursor") val cursor: String? = null,
    @Json(name = "has_more") val hasMore: Boolean = false,
    @Json(name = "server_time") val serverTime: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class InboundEventDto(
    @Json(name = "eventId") val eventId: String? = null,
    @Json(name = "id") val legacyId: String? = null,
    @Json(name = "eventType") val eventType: String? = null,
    @Json(name = "type") val legacyType: String? = null, // NEW_MESSAGE, MESSAGE_STATUS_UPDATE, BOT_HEARTBEAT, COMMAND_STATUS_UPDATE
    val payload: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val id: String get() = eventId ?: legacyId ?: ""
    val type: String get() = eventType ?: legacyType ?: ""
}
