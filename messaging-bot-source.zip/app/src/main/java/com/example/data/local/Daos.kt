package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppNotification
import com.example.data.model.AutoReplyRule
import com.example.data.model.BotCommand
import com.example.data.model.BotConnection
import com.example.data.model.ChromeProfile
import com.example.data.model.CommandStatus
import com.example.data.model.Conversation
import com.example.data.model.Customer
import com.example.data.model.Listing
import com.example.data.model.Message
import com.example.data.model.MessageStatus
import com.example.data.model.ProfileStatus
import com.example.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface ChromeProfileDao {
    @Query("SELECT * FROM chrome_profiles ORDER BY id ASC")
    fun getAllProfiles(): Flow<List<ChromeProfile>>

    @Query("SELECT * FROM chrome_profiles WHERE userId = :userId ORDER BY id ASC")
    fun getProfilesByUser(userId: String): Flow<List<ChromeProfile>>

    @Query("SELECT * FROM chrome_profiles WHERE id = :id LIMIT 1")
    fun getProfileById(id: String): Flow<ChromeProfile?>

    @Query("SELECT * FROM chrome_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileByIdSync(id: String): ChromeProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ChromeProfile)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<ChromeProfile>)

    @Update
    suspend fun updateProfile(profile: ChromeProfile)

    @Query("UPDATE chrome_profiles SET status = :status, currentTask = :currentTask, lastSeen = :timestamp WHERE id = :id")
    suspend fun updateProfileStatus(id: String, status: ProfileStatus, currentTask: String, timestamp: Long)

    @Query("UPDATE chrome_profiles SET lastHeartbeatAt = :timestamp, lastHeartbeat = :timestamp, connectionStatus = :connectionStatus WHERE id = :id")
    suspend fun updateHeartbeat(id: String, timestamp: Long, connectionStatus: String)

    @Query("UPDATE chrome_profiles SET manuallyDisconnected = :disconnected, status = :status, currentTask = :currentTask, lastSeen = :timestamp WHERE id = :id")
    suspend fun setManualConnectionState(id: String, disconnected: Boolean, status: ProfileStatus, currentTask: String, timestamp: Long)

    @Query("DELETE FROM chrome_profiles WHERE id = :id")
    suspend fun deleteProfile(id: String)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE userId = :userId")
    fun getCustomersByUser(userId: String): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: String): Customer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<Customer>)
}

@Dao
interface ListingDao {
    @Query("SELECT * FROM listings ORDER BY createdAt DESC")
    fun getAllListings(): Flow<List<Listing>>

    @Query("SELECT * FROM listings WHERE userId = :userId ORDER BY createdAt DESC")
    fun getListingsByUser(userId: String): Flow<List<Listing>>

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    fun getListingById(id: String): Flow<Listing?>

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    suspend fun getListingByIdSync(id: String): Listing?

    @Query("SELECT * FROM listings WHERE profileId = :profileId ORDER BY createdAt DESC")
    fun getListingsByProfile(profileId: String): Flow<List<Listing>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListing(listing: Listing)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListings(listings: List<Listing>)

    @Update
    suspend fun updateListing(listing: Listing)

    @Query("DELETE FROM listings WHERE id = :id")
    suspend fun deleteListing(id: String)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY isPinned DESC, lastMessageAt DESC")
    fun getAllConversations(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE userId = :userId ORDER BY isPinned DESC, lastMessageAt DESC")
    fun getConversationsByUser(userId: String): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE profileId = :profileId ORDER BY lastMessageAt DESC")
    fun getConversationsByProfile(profileId: String): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    fun getConversationById(id: String): Flow<Conversation?>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversationByIdSync(id: String): Conversation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: Conversation)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversations(conversations: List<Conversation>)

    @Query("UPDATE conversations SET lastMessage = :lastMessage, lastMessageAt = :timestamp, unreadCount = unreadCount + :unreadIncrement WHERE id = :id")
    suspend fun updateLastMessage(id: String, lastMessage: String, timestamp: Long, unreadIncrement: Int = 0)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE conversations SET isPinned = :isPinned WHERE id = :id")
    suspend fun togglePin(id: String, isPinned: Boolean)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<Message>>

    @Query("SELECT * FROM messages WHERE id = :id LIMIT 1")
    suspend fun getMessageById(id: String): Message?

    @Query("SELECT * FROM messages WHERE commandId = :commandId LIMIT 1")
    suspend fun getMessageByCommandId(commandId: String): Message?

    @Query("SELECT * FROM messages WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getMessageByIdempotencyKey(key: String): Message?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Message)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<Message>)

    @Query("UPDATE messages SET status = :status WHERE id = :id")
    suspend fun updateMessageStatus(id: String, status: MessageStatus)

    @Query("UPDATE messages SET status = :status WHERE commandId = :commandId")
    suspend fun updateMessageStatusByCommand(commandId: String, status: MessageStatus)
}

@Dao
interface BotCommandDao {
    @Query("SELECT * FROM bot_commands ORDER BY createdAt DESC")
    fun getAllCommands(): Flow<List<BotCommand>>

    @Query("SELECT * FROM bot_commands WHERE userId = :userId ORDER BY createdAt DESC")
    fun getCommandsByUser(userId: String): Flow<List<BotCommand>>

    @Query("SELECT * FROM bot_commands WHERE id = :id LIMIT 1")
    suspend fun getCommandById(id: String): BotCommand?

    @Query("SELECT * FROM bot_commands WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getCommandByIdempotencyKey(key: String): BotCommand?

    @Query("SELECT * FROM bot_commands WHERE profileId = :profileId ORDER BY createdAt DESC")
    fun getCommandsByProfile(profileId: String): Flow<List<BotCommand>>

    @Query("SELECT * FROM bot_commands WHERE status = 'PENDING' OR status = 'PROCESSING' ORDER BY createdAt ASC")
    fun getPendingCommands(): Flow<List<BotCommand>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommand(command: BotCommand)

    @Query("UPDATE bot_commands SET status = :status, completedAt = :completedAt, resultMessage = :resultMessage, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateCommandStatus(
        id: String,
        status: CommandStatus,
        completedAt: Long?,
        resultMessage: String?,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("UPDATE bot_commands SET retryCount = :retryCount, nextRetryAt = :nextRetryAt, lastAttemptAt = :lastAttemptAt, errorCode = :errorCode, errorMessage = :errorMessage, status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateCommandRetry(
        id: String,
        retryCount: Int,
        nextRetryAt: Long,
        lastAttemptAt: Long,
        errorCode: String?,
        errorMessage: String?,
        status: CommandStatus,
        updatedAt: Long
    )
}

@Dao
interface BotConnectionDao {
    @Query("SELECT * FROM api_keys ORDER BY createdAt DESC")
    fun getAllApiKeys(): Flow<List<BotConnection>>

    @Query("SELECT * FROM api_keys WHERE userId = :userId ORDER BY createdAt DESC")
    fun getApiKeysByUser(userId: String): Flow<List<BotConnection>>

    @Query("SELECT * FROM api_keys WHERE id = :id LIMIT 1")
    suspend fun getApiKeyById(id: String): BotConnection?

    @Query("SELECT * FROM api_keys WHERE profileId = :profileId LIMIT 1")
    fun getApiKeyForProfile(profileId: String): Flow<BotConnection?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiKey(connection: BotConnection)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiKeys(connections: List<BotConnection>)

    @Query("UPDATE api_keys SET status = :status WHERE id = :id")
    suspend fun updateApiKeyStatus(id: String, status: String)

    @Query("DELETE FROM api_keys WHERE id = :id")
    suspend fun deleteApiKey(id: String)
}

@Dao
interface AutoReplyRuleDao {
    @Query("SELECT * FROM auto_reply_rules ORDER BY createdAt DESC")
    fun getAllRules(): Flow<List<AutoReplyRule>>

    @Query("SELECT * FROM auto_reply_rules WHERE userId = :userId ORDER BY createdAt DESC")
    fun getRulesByUser(userId: String): Flow<List<AutoReplyRule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: AutoReplyRule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRules(rules: List<AutoReplyRule>)

    @Update
    suspend fun updateRule(rule: AutoReplyRule)

    @Query("UPDATE auto_reply_rules SET enabled = :enabled WHERE id = :id")
    suspend fun toggleRule(id: String, enabled: Boolean)

    @Query("DELETE FROM auto_reply_rules WHERE id = :id")
    suspend fun deleteRule(id: String)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY createdAt DESC")
    fun getAllNotifications(): Flow<List<AppNotification>>

    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun getNotificationsByUser(userId: String): Flow<List<AppNotification>>

    @Query("SELECT COUNT(*) FROM notifications WHERE read = 0")
    fun getUnreadCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM notifications WHERE read = 0 AND userId = :userId")
    fun getUnreadCountByUser(userId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<AppNotification>)

    @Query("UPDATE notifications SET read = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE notifications SET read = 1")
    suspend fun markAllAsRead()

    @Query("UPDATE notifications SET read = 1 WHERE userId = :userId")
    suspend fun markAllAsReadForUser(userId: String)

    @Query("DELETE FROM notifications")
    suspend fun clearAll()

    @Query("DELETE FROM notifications WHERE userId = :userId")
    suspend fun clearAllForUser(userId: String)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserById(id: String): Flow<User?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)
}
