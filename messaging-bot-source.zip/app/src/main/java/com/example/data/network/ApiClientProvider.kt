package com.example.data.network

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object ApiClientProvider {

    val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    fun createService(
        baseUrl: String,
        tokenProvider: () -> String?,
        tokenRefresher: (() -> String?)? = null,
        onAuthFailure: (() -> Unit)? = null
    ): MarketplaceApiService {
        val logging = HttpLoggingInterceptor().apply {
            // Mask headers containing Authorization for security audit
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val authInterceptor = AuthInterceptor(tokenProvider, tokenRefresher, onAuthFailure)

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()

        val trimmed = baseUrl.trim()
        val withoutV1 = trimmed.replace(Regex("/(api/)?v1/?$"), "")
        val normalizedUrl = if (withoutV1.endsWith("/")) withoutV1 else "$withoutV1/"

        // Retrofit.Builder().baseUrl() throws IllegalArgumentException (crashing the app) if the
        // URL doesn't parse (e.g. a corrupted/blank persisted value). Fall back to the default
        // server instead of crashing; requests will simply fail until a valid URL is restored,
        // same as any other unreachable-server case.
        val safeUrl = normalizedUrl.toHttpUrlOrNull()?.toString() ?: "http://13.60.48.34:8080/"

        return Retrofit.Builder()
            .baseUrl(safeUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(MarketplaceApiService::class.java)
    }
}
