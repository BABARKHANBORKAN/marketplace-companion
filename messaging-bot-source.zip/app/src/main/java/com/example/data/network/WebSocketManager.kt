package com.example.data.network

import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

enum class WebSocketState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    FAILED
}

class WebSocketManager(
    private val serverUrlProvider: () -> String,
    private val tokenProvider: () -> String?,
    private val onEventReceived: suspend (InboundEventDto) -> Unit,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO),
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .pingInterval(25, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Indefinite read timeout for persistent websocket
        .build()
) {
    companion object {
        private const val TAG = "WebSocketManager"
        private const val NORMAL_CLOSURE_STATUS = 1000
        private const val INITIAL_BACKOFF_MS = 1000L
        private const val MAX_BACKOFF_MS = 30000L
        private const val BACKOFF_MULTIPLIER = 2.0
    }

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val eventAdapter = moshi.adapter(InboundEventDto::class.java)

    private val _connectionState = MutableStateFlow(WebSocketState.DISCONNECTED)
    val connectionState: StateFlow<WebSocketState> = _connectionState.asStateFlow()

    private var currentWebSocket: WebSocket? = null
    private var reconnectJob: Job? = null
    private val isExplicitlyDisconnected = AtomicBoolean(false)
    private val reconnectAttempts = AtomicInteger(0)

    /**
     * Converts HTTP/HTTPS base URL to WS/WSS URL without putting tokens in the query string
     */
    fun getWebSocketUrl(baseUrl: String): String {
        val trimmed = baseUrl.trim().trimEnd('/')
        val withoutV1 = trimmed.replace(Regex("/(api/)?v1/?$"), "")
        val wsBase = when {
            withoutV1.startsWith("https://", ignoreCase = true) -> "wss://" + withoutV1.substring(8)
            withoutV1.startsWith("http://", ignoreCase = true) -> "ws://" + withoutV1.substring(7)
            withoutV1.startsWith("wss://", ignoreCase = true) || withoutV1.startsWith("ws://", ignoreCase = true) -> withoutV1
            else -> "ws://$withoutV1"
        }
        return "$wsBase/api/v1/events"
    }

    /**
     * Connects to the real backend WebSocket endpoint using OkHttp
     */
    @Synchronized
    fun connect() {
        isExplicitlyDisconnected.set(false)
        reconnectJob?.cancel()

        val token = tokenProvider()
        if (token.isNullOrBlank()) {
            Log.d(TAG, "Cannot connect: Token is null or blank (unauthenticated).")
            _connectionState.value = WebSocketState.DISCONNECTED
            return
        }

        if (_connectionState.value == WebSocketState.CONNECTED || _connectionState.value == WebSocketState.CONNECTING) {
            Log.d(TAG, "Already connected or connecting. Skipping connect() call.")
            return
        }

        val baseUrl = serverUrlProvider()
        val wsUrl = getWebSocketUrl(baseUrl)
        Log.i(TAG, "Connecting to WebSocket at: $wsUrl (Auth via Authorization header only)")

        _connectionState.value = WebSocketState.CONNECTING

        val requestBuilder = Request.Builder()
            .url(wsUrl)
            .header("User-Agent", "MarketplaceCompanion-Android/1.0")
            .header("Authorization", "Bearer $token")

        currentWebSocket?.cancel()
        currentWebSocket = okHttpClient.newWebSocket(requestBuilder.build(), createWebSocketListener())
    }

    /**
     * Gracefully disconnects the WebSocket
     */
    @Synchronized
    fun disconnect() {
        isExplicitlyDisconnected.set(true)
        reconnectJob?.cancel()
        reconnectAttempts.set(0)

        currentWebSocket?.close(NORMAL_CLOSURE_STATUS, "Client disconnecting")
        currentWebSocket = null
        _connectionState.value = WebSocketState.DISCONNECTED
        Log.i(TAG, "WebSocket explicitly disconnected.")
    }

    /**
     * Forces a reconnection
     */
    @Synchronized
    fun reconnect() {
        disconnect()
        connect()
    }

    private fun scheduleReconnect() {
        if (isExplicitlyDisconnected.get()) return

        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            _connectionState.value = WebSocketState.RECONNECTING
            val attempt = reconnectAttempts.incrementAndGet()
            val delayMs = (INITIAL_BACKOFF_MS * Math.pow(BACKOFF_MULTIPLIER, (attempt - 1).coerceAtMost(5).toDouble()))
                .toLong()
                .coerceAtMost(MAX_BACKOFF_MS)

            Log.d(TAG, "Reconnecting attempt #$attempt in ${delayMs}ms...")
            delay(delayMs)

            if (isActive && !isExplicitlyDisconnected.get()) {
                connect()
            }
        }
    }

    private fun createWebSocketListener(): WebSocketListener {
        return object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket connected successfully.")
                reconnectAttempts.set(0)
                _connectionState.value = WebSocketState.CONNECTED
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                scope.launch {
                    try {
                        val event = eventAdapter.fromJson(text)
                        if (event != null) {
                            onEventReceived(event)
                        } else {
                            Log.w(TAG, "Failed to parse inbound event: $text")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error processing WebSocket message: ${e.message}", e)
                    }
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closing ($code): $reason")
                webSocket.close(NORMAL_CLOSURE_STATUS, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.i(TAG, "WebSocket closed ($code): $reason")
                if (!isExplicitlyDisconnected.get()) {
                    scheduleReconnect()
                } else {
                    _connectionState.value = WebSocketState.DISCONNECTED
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w(TAG, "WebSocket failure: ${t.message}")
                if (!isExplicitlyDisconnected.get()) {
                    _connectionState.value = WebSocketState.FAILED
                    scheduleReconnect()
                } else {
                    _connectionState.value = WebSocketState.DISCONNECTED
                }
            }
        }
    }
}
