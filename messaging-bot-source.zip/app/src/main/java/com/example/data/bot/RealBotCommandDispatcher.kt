package com.example.data.bot

import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.CommandStatus
import com.example.data.model.MessageStatus
import com.example.data.network.DispatchCommandRequest
import com.example.data.network.MarketplaceApiService
import com.example.data.network.SendMessageRequest
import java.util.UUID
import kotlin.math.min

class RealBotCommandDispatcher(
    private val database: AppDatabase,
    private val apiServiceProvider: () -> MarketplaceApiService
) : BotCommandDispatcher {

    private val commandDao = database.botCommandDao()
    private val messageDao = database.messageDao()
    private val notificationDao = database.notificationDao()

    override suspend fun reopenChromeProfile(profileId: String, commandId: String): DispatchResult {
        val existing = commandDao.getCommandById(commandId)
        val idempotencyKey = existing?.idempotencyKey ?: UUID.randomUUID().toString()

        return try {
            CommandStateMachine.assertValidTransition(
                commandId,
                existing?.status ?: CommandStatus.PENDING,
                CommandStatus.PROCESSING
            )
            commandDao.updateCommandStatus(commandId, CommandStatus.PROCESSING, null, "Dispatched to backend")

            val response = apiServiceProvider().dispatchCommand(
                DispatchCommandRequest(
                    commandId = commandId,
                    idempotencyKey = idempotencyKey,
                    profileId = profileId,
                    type = "REOPEN_CHROME_PROFILE",
                    payload = "{\"action\":\"REOPEN_CHROME_PROFILE\",\"profileId\":\"$profileId\"}"
                )
            )

            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val targetStatus = when (body.status.uppercase()) {
                    "COMPLETED" -> CommandStatus.COMPLETED
                    "PROCESSING" -> CommandStatus.PROCESSING
                    "FAILED" -> CommandStatus.FAILED
                    else -> CommandStatus.PROCESSING
                }

                commandDao.updateCommandStatus(
                    id = commandId,
                    status = targetStatus,
                    completedAt = body.completedAt,
                    resultMessage = body.resultMessage ?: "Command dispatched to live server"
                )
                DispatchResult.Success(commandId, body.resultMessage ?: "Reopen command dispatched")
            } else {
                queueCommandForRetry(
                    commandId = commandId,
                    reason = "Server returned ${response.code()}: ${response.message()}",
                    errorCode = "HTTP_${response.code()}"
                )
            }
        } catch (e: Exception) {
            queueCommandForRetry(commandId, "Network error: ${e.localizedMessage ?: "Unknown"}", errorCode = "NETWORK_ERROR")
        }
    }

    override suspend fun stopCurrentTask(profileId: String, commandId: String): DispatchResult {
        val existing = commandDao.getCommandById(commandId)
        val idempotencyKey = existing?.idempotencyKey ?: UUID.randomUUID().toString()

        return try {
            CommandStateMachine.assertValidTransition(
                commandId,
                existing?.status ?: CommandStatus.PENDING,
                CommandStatus.PROCESSING
            )
            commandDao.updateCommandStatus(commandId, CommandStatus.PROCESSING, null, "Dispatched stop request")

            val response = apiServiceProvider().dispatchCommand(
                DispatchCommandRequest(
                    commandId = commandId,
                    idempotencyKey = idempotencyKey,
                    profileId = profileId,
                    type = "STOP_CURRENT_TASK",
                    payload = "{\"action\":\"STOP_CURRENT_TASK\",\"profileId\":\"$profileId\"}"
                )
            )

            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val targetStatus = when (body.status.uppercase()) {
                    "COMPLETED" -> CommandStatus.COMPLETED
                    else -> CommandStatus.PROCESSING
                }

                commandDao.updateCommandStatus(
                    id = commandId,
                    status = targetStatus,
                    completedAt = body.completedAt ?: System.currentTimeMillis(),
                    resultMessage = body.resultMessage ?: "Stop task acknowledged"
                )
                DispatchResult.Success(commandId, "Stop command received by server")
            } else {
                queueCommandForRetry(commandId, "Server returned ${response.code()}", errorCode = "HTTP_${response.code()}")
            }
        } catch (e: Exception) {
            queueCommandForRetry(commandId, "Network error: ${e.localizedMessage}", errorCode = "NETWORK_ERROR")
        }
    }

    override suspend fun openCustomerChatInChrome(
        profileId: String,
        conversationId: String,
        commandId: String
    ): DispatchResult {
        val existing = commandDao.getCommandById(commandId)
        val idempotencyKey = existing?.idempotencyKey ?: UUID.randomUUID().toString()
        val customerId = existing?.customerId ?: ""
        val listingId = existing?.listingId ?: ""

        return try {
            CommandStateMachine.assertValidTransition(
                commandId,
                existing?.status ?: CommandStatus.PENDING,
                CommandStatus.PROCESSING
            )
            commandDao.updateCommandStatus(commandId, CommandStatus.PROCESSING, null, "Opening chat in Chrome")

            val response = apiServiceProvider().dispatchCommand(
                DispatchCommandRequest(
                    commandId = commandId,
                    idempotencyKey = idempotencyKey,
                    profileId = profileId,
                    type = "OPEN_CUSTOMER_CHAT",
                    payload = "{\"conversationId\":\"$conversationId\",\"profileId\":\"$profileId\",\"customerId\":\"$customerId\",\"listingId\":\"$listingId\"}",
                    conversationId = conversationId,
                    customerId = customerId,
                    listingId = listingId
                )
            )

            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val targetStatus = when (body.status.uppercase()) {
                    "COMPLETED" -> CommandStatus.COMPLETED
                    else -> CommandStatus.PROCESSING
                }

                commandDao.updateCommandStatus(
                    id = commandId,
                    status = targetStatus,
                    completedAt = body.completedAt ?: System.currentTimeMillis(),
                    resultMessage = body.resultMessage ?: "Chat open acknowledged"
                )
                DispatchResult.Success(commandId, "Chat open requested on desktop Chrome")
            } else {
                queueCommandForRetry(commandId, "Server error ${response.code()}", errorCode = "HTTP_${response.code()}")
            }
        } catch (e: Exception) {
            queueCommandForRetry(commandId, "Network failure: ${e.localizedMessage}", errorCode = "NETWORK_ERROR")
        }
    }

    override suspend fun sendMessage(
        conversationId: String,
        profileId: String,
        text: String,
        messageId: String,
        commandId: String
    ): DispatchResult {
        val existingCmd = commandDao.getCommandById(commandId)
        val idempotencyKey = existingCmd?.idempotencyKey ?: UUID.randomUUID().toString()

        return try {
            // Update command to PROCESSING
            CommandStateMachine.assertValidTransition(
                commandId,
                existingCmd?.status ?: CommandStatus.PENDING,
                CommandStatus.PROCESSING
            )
            commandDao.updateCommandStatus(commandId, CommandStatus.PROCESSING, null, "Dispatching message to backend")

            // CRITICAL REQUIREMENT 7: Update message to PROCESSING (NOT SENT yet!)
            CommandStateMachine.assertValidMessageTransition(messageId, MessageStatus.PENDING, MessageStatus.PROCESSING)
            messageDao.updateMessageStatus(messageId, MessageStatus.PROCESSING)

            val response = apiServiceProvider().sendMessage(
                conversationId = conversationId,
                request = SendMessageRequest(
                    conversationId = conversationId,
                    text = text,
                    commandId = commandId,
                    idempotencyKey = idempotencyKey
                )
            )

            if (response.isSuccessful) {
                // Backend accepted command -> Remains PROCESSING until desktop bot confirms delivery
                DispatchResult.Success(commandId, "Message queued on backend daemon for Marketplace delivery")
            } else {
                // Backend rejected request -> mark failed or queue retry
                messageDao.updateMessageStatus(messageId, MessageStatus.PENDING)
                queueCommandForRetry(commandId, "Server rejected message: ${response.code()}", errorCode = "HTTP_${response.code()}")
            }
        } catch (e: Exception) {
            // Network unavailable -> keep PENDING and queue for retry
            messageDao.updateMessageStatus(messageId, MessageStatus.PENDING)
            queueCommandForRetry(commandId, "Network unavailable. Message queued offline.", errorCode = "OFFLINE")
        }
    }

    /**
     * Exponential backoff retry handler preserving full command context
     */
    private suspend fun queueCommandForRetry(
        commandId: String,
        reason: String,
        errorCode: String? = null
    ): DispatchResult {
        val cmd = commandDao.getCommandById(commandId)
        val currentRetry = cmd?.retryCount ?: 0
        val maxRetries = cmd?.maxRetries ?: 5

        if (currentRetry >= maxRetries) {
            // Reached maximum retries -> Mark FAILED
            commandDao.updateCommandStatus(
                id = commandId,
                status = CommandStatus.FAILED,
                completedAt = System.currentTimeMillis(),
                resultMessage = "Failed after $maxRetries attempts: $reason"
            )
            // If associated with a message, mark message FAILED
            if (!cmd?.messageId.isNullOrBlank()) {
                messageDao.updateMessageStatus(cmd!!.messageId, MessageStatus.FAILED)
            }
            notificationDao.insertNotification(
                AppNotification(
                    id = UUID.randomUUID().toString(),
                    type = "BOT_ERROR",
                    title = "Command Failed",
                    body = "Command reached max retries ($maxRetries): $reason",
                    targetScreen = "SETTINGS"
                )
            )
            return DispatchResult.Failed(commandId, reason)
        }

        val nextRetryDelay = min(120_000L, 5_000L * (1L shl currentRetry))
        val nextRetryAt = System.currentTimeMillis() + nextRetryDelay

        commandDao.updateCommandRetry(
            id = commandId,
            retryCount = currentRetry + 1,
            nextRetryAt = nextRetryAt,
            lastAttemptAt = System.currentTimeMillis(),
            errorCode = errorCode,
            errorMessage = reason,
            status = CommandStatus.PENDING,
            updatedAt = System.currentTimeMillis()
        )

        return DispatchResult.Queued(commandId, reason)
    }
}
