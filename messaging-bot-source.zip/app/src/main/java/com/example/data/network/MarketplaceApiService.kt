package com.example.data.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface MarketplaceApiService {

    // --- Authentication ---
    @POST("api/v1/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<AuthResponse>

    @POST("api/v1/auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>

    @POST("api/v1/auth/refresh")
    suspend fun refreshToken(@Body request: RefreshTokenRequest): Response<AuthResponse>

    @POST("api/v1/auth/forgot-password")
    suspend fun forgotPassword(@Body request: ForgotPasswordRequest): Response<Unit>

    @POST("api/v1/auth/apps-code")
    suspend fun loginWithAppsCode(@Body request: AppsCodeLoginRequest): Response<AuthResponse>

    @GET("api/v1/auth/me")
    suspend fun getCurrentUser(): Response<UserDto>

    // --- Chrome Profiles ---
    @GET("api/v1/profiles")
    suspend fun getProfiles(): Response<List<ChromeProfileDto>>

    @POST("api/v1/profiles")
    suspend fun createProfile(@Body request: CreateProfileRequest): Response<ChromeProfileDto>

    @GET("api/v1/profiles/{id}")
    suspend fun getProfileById(@Path("id") id: String): Response<ChromeProfileDto>

    @DELETE("api/v1/profiles/{id}")
    suspend fun deleteProfile(@Path("id") id: String): Response<Unit>

    // --- Bot Commands ---
    @POST("api/v1/commands")
    suspend fun dispatchCommand(@Body request: DispatchCommandRequest): Response<CommandResponse>

    @GET("api/v1/commands/{id}")
    suspend fun getCommandStatus(@Path("id") id: String): Response<CommandResponse>

    // --- Conversations & Messages ---
    @GET("api/v1/conversations")
    suspend fun getConversations(): Response<List<ConversationDto>>

    @GET("api/v1/conversations/{id}/messages")
    suspend fun getMessages(@Path("id") conversationId: String): Response<List<MessageDto>>

    @POST("api/v1/conversations/{id}/messages")
    suspend fun sendMessage(
        @Path("id") conversationId: String,
        @Body request: SendMessageRequest
    ): Response<MessageDto>

    // --- Listings ---
    @GET("api/v1/listings")
    suspend fun getListings(): Response<List<ListingDto>>

    @POST("api/v1/listings")
    suspend fun createListing(@Body request: CreateListingRequest): Response<ListingDto>

    @DELETE("api/v1/listings/{id}")
    suspend fun deleteListing(@Path("id") id: String): Response<Unit>

    // --- Bot API Keys ---
    @GET("api/v1/api-keys")
    suspend fun getApiKeys(): Response<List<BotConnectionDto>>

    @POST("api/v1/api-keys")
    suspend fun generateApiKey(@Body request: GenerateKeyRequest): Response<BotConnectionDto>

    @POST("api/v1/api-keys/{id}/revoke")
    suspend fun revokeApiKey(@Path("id") id: String): Response<Unit>

    @DELETE("api/v1/api-keys/{id}")
    suspend fun deleteApiKey(@Path("id") id: String): Response<Unit>

    // --- Desktop Bot Heartbeat ---
    @POST("api/v1/bot/heartbeat")
    suspend fun sendHeartbeat(@Body request: BotHeartbeatRequest): Response<BotHeartbeatResponse>

    // --- Synchronization & Real-Time Polling ---
    @GET("api/v1/sync")
    suspend fun fetchDeltaSync(
        @Query("cursor") cursor: String? = null,
        @Query("since") sinceTimestamp: Long? = null
    ): Response<DeltaSyncResponse>
}
