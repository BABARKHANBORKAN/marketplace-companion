package com.example.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SecureCredentialStore(private val context: Context) {

    companion object {
        private const val KEY_ALIAS = "mpc_secure_keystore_v1"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128
        private const val PREFS_NAME = "mpc_encrypted_credentials"

        fun maskApiKey(rawKey: String): String {
            if (rawKey.length <= 8) return "••••••••"
            val prefix = if (rawKey.startsWith("mpc_live_")) "mpc_live_"
            else if (rawKey.startsWith("mpc_demo_")) "mpc_demo_"
            else rawKey.take(8)
            val suffix = rawKey.takeLast(4)
            return "$prefix••••••••••••$suffix"
        }
    }

    // In-memory cache for secrets generated during the active app session
    private val activeSessionSecrets = ConcurrentHashMap<String, String>()

    private val prefs by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGenerator.init(spec)
            keyGenerator.generateKey()
        }
        return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    /**
     * Store secret in active memory and optionally encrypt into keystore-backed storage
     */
    fun saveGeneratedSecret(keyId: String, secret: String) {
        activeSessionSecrets[keyId] = secret
        try {
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val encryptedBytes = cipher.doFinal(secret.toByteArray(Charsets.UTF_8))
            val combined = iv + encryptedBytes
            val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
            prefs.edit().putString("enc_key_$keyId", encoded).apply()
        } catch (_: Exception) {
            // Keystore might not be supported in Robolectric JVM tests without full native support;
            // session memory fallback guarantees safe in-memory access during generation.
        }
    }

    /**
     * Retrieve the plaintext secret for copying/revealing.
     * Returns null if key is not held or has been revoked.
     */
    fun getSecret(keyId: String): String? {
        activeSessionSecrets[keyId]?.let { return it }

        val storedEncoded = prefs.getString("enc_key_$keyId", null) ?: return null
        return try {
            val combined = Base64.decode(storedEncoded, Base64.NO_WRAP)
            if (combined.size <= GCM_IV_LENGTH) return null
            val iv = combined.copyOfRange(0, GCM_IV_LENGTH)
            val encryptedBytes = combined.copyOfRange(GCM_IV_LENGTH, combined.size)

            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)
            val decryptedBytes = cipher.doFinal(encryptedBytes)
            val secret = String(decryptedBytes, Charsets.UTF_8)
            activeSessionSecrets[keyId] = secret
            secret
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Revoke and purge the secret from all storage
     */
    fun removeSecret(keyId: String) {
        activeSessionSecrets.remove(keyId)
        prefs.edit().remove("enc_key_$keyId").apply()
    }

    /**
     * Purge all stored credentials on logout
     */
    fun clearAll() {
        activeSessionSecrets.clear()
        prefs.edit().clear().apply()
    }
}
