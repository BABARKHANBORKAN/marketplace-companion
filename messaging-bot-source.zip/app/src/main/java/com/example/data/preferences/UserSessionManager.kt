package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.sessionDataStore: DataStore<Preferences> by preferencesDataStore(name = "user_session_prefs")

data class AuthSession(
    val isAuthenticated: Boolean = false,
    val token: String? = null,
    val refreshToken: String? = null,
    val userId: String? = null,
    val email: String? = null,
    val name: String? = null,
    val serverUrl: String = "http://13.60.48.34:8080/",
    val lastSyncTime: Long = 0L
)

class UserSessionManager(private val context: Context) {

    private object PrefKeys {
        val AUTH_TOKEN = stringPreferencesKey("auth_token")
        val REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        val USER_ID = stringPreferencesKey("user_id")
        val USER_EMAIL = stringPreferencesKey("user_email")
        val USER_NAME = stringPreferencesKey("user_name")
        val SERVER_URL = stringPreferencesKey("server_url")
        val LAST_SYNC_TIME = longPreferencesKey("last_sync_time")
    }

    val sessionFlow: Flow<AuthSession> = context.sessionDataStore.data.map { prefs ->
        val token = prefs[PrefKeys.AUTH_TOKEN]
        val isAuthenticated = !token.isNullOrBlank()

        AuthSession(
            isAuthenticated = isAuthenticated,
            token = token,
            refreshToken = prefs[PrefKeys.REFRESH_TOKEN],
            userId = prefs[PrefKeys.USER_ID],
            email = prefs[PrefKeys.USER_EMAIL],
            name = prefs[PrefKeys.USER_NAME],
            serverUrl = sanitizeServerUrl(prefs[PrefKeys.SERVER_URL] ?: "http://13.60.48.34:8080/"),
            lastSyncTime = prefs[PrefKeys.LAST_SYNC_TIME] ?: 0L
        )
    }

    suspend fun saveAuthToken(
        token: String,
        refreshToken: String? = null,
        userId: String,
        email: String,
        name: String
    ) {
        context.sessionDataStore.edit { prefs ->
            prefs[PrefKeys.AUTH_TOKEN] = token
            if (refreshToken != null) {
                prefs[PrefKeys.REFRESH_TOKEN] = refreshToken
            }
            prefs[PrefKeys.USER_ID] = userId
            prefs[PrefKeys.USER_EMAIL] = email
            prefs[PrefKeys.USER_NAME] = name
        }
    }

    suspend fun updateServerUrl(url: String) {
        val sanitized = sanitizeServerUrl(url)
        context.sessionDataStore.edit { prefs ->
            prefs[PrefKeys.SERVER_URL] = sanitized
        }
    }

    suspend fun updateLastSyncTime(time: Long = System.currentTimeMillis()) {
        context.sessionDataStore.edit { prefs ->
            prefs[PrefKeys.LAST_SYNC_TIME] = time
        }
    }

    suspend fun getCurrentToken(): String? {
        val prefs = context.sessionDataStore.data.first()
        return prefs[PrefKeys.AUTH_TOKEN]
    }

    suspend fun getCurrentRefreshToken(): String? {
        val prefs = context.sessionDataStore.data.first()
        return prefs[PrefKeys.REFRESH_TOKEN]
    }

    suspend fun clearSession() {
        context.sessionDataStore.edit { prefs ->
            prefs.remove(PrefKeys.AUTH_TOKEN)
            prefs.remove(PrefKeys.REFRESH_TOKEN)
            prefs.remove(PrefKeys.USER_ID)
            prefs.remove(PrefKeys.USER_EMAIL)
            prefs.remove(PrefKeys.USER_NAME)
        }
    }

    companion object {
        fun sanitizeServerUrl(url: String): String {
            val trimmed = url.trim()
            val withoutV1 = trimmed.replace(Regex("/(api/)?v1/?$"), "")
            return if (withoutV1.endsWith("/")) withoutV1 else "$withoutV1/"
        }
    }
}
