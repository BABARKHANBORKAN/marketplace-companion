package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val passwordHash: String = "",
    val plan: String = "Pro",
    val createdAt: Long = System.currentTimeMillis()
)

enum class ProfileStatus {
    ONLINE,   // GREEN = Online
    OFFLINE,  // RED = Offline/Closed
    BUSY      // YELLOW = Online but Busy/Working
}

@Entity(tableName = "chrome_profiles")
data class ChromeProfile(
    @PrimaryKey val id: String, // e.g. "profile_01", "profile_02", "profile_03"
    val userId: String = "",
    val name: String, // e.g. "Main Sales Chrome"
    val accountLabel: String, // e.g. "Alex Marketplace Account"
    val status: ProfileStatus,
    val currentTask: String = "Idle", // e.g. "Creating Marketplace Listing", "Replying to inquiry"
    val lastSeen: Long = System.currentTimeMillis(),
    val lastHeartbeat: Long = System.currentTimeMillis(),
    val lastHeartbeatAt: Long = System.currentTimeMillis(),
    val listingCount: Int = 0,
    val conversationCount: Int = 0,
    val unreadCount: Int = 0,
    val chromeWindowName: String = "Google Chrome - Profile 3",
    val botConnected: Boolean = true,
    val connectionStatus: String = "ONLINE",
    val serverUpdatedAt: Long = System.currentTimeMillis(),
    val syncStatus: String = "CONFIRMED", // CONFIRMED, LOCAL_PENDING
    // True only when the user explicitly tapped "Disconnect" in the UI. Unlike `status`, this is
    // never overwritten by incoming heartbeats/delta sync — it stays true until the user
    // explicitly reconnects, which is what makes Disconnect actually stick.
    val manuallyDisconnected: Boolean = false
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String,
    val userId: String = "",
    val name: String,
    val externalCustomerId: String,
    val avatarInitials: String = "",
    val avatarColorHex: String = "#1877F2"
)

enum class ListingStatus {
    ACTIVE,
    PENDING_SYNC,
    INACTIVE,
    SOLD
}

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey val id: String,
    val userId: String = "",
    val profileId: String,
    val title: String,
    val price: Double,
    val currency: String = "USD",
    val status: ListingStatus = ListingStatus.ACTIVE,
    val category: String = "Electronics",
    val description: String = "",
    val location: String = "Seattle, WA",
    val conversationCount: Int = 0,
    val messageCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val imageUrl: String = "",
    val syncStatus: String = "CONFIRMED" // CONFIRMED, LOCAL_PENDING
)

@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey val id: String,
    val userId: String = "",
    val profileId: String,
    val customerId: String,
    val listingId: String,
    val unreadCount: Int = 0,
    val lastMessage: String = "",
    val lastMessageAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)

enum class MessageSender {
    CUSTOMER,
    USER_APP,
    BOT_AUTO
}

enum class MessageStatus {
    PENDING,
    PROCESSING,
    SENT,
    FAILED,
    CANCELLED
}

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String,
    val conversationId: String,
    val sender: MessageSender,
    val text: String,
    val status: MessageStatus = MessageStatus.SENT,
    val timestamp: Long = System.currentTimeMillis(),
    val commandId: String? = null,
    val idempotencyKey: String? = null
)

enum class CommandType {
    REOPEN_CHROME_PROFILE,
    OPEN_CUSTOMER_CHAT,
    STOP_CURRENT_TASK,
    PAUSE_CURRENT_TASK,
    SEND_MESSAGE
}

enum class CommandStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED,
    CANCELLED
}

@Entity(tableName = "bot_commands")
data class BotCommand(
    @PrimaryKey val id: String, // commandId
    val idempotencyKey: String = "",
    val userId: String = "",
    val botId: String = "",
    val profileId: String,
    val type: CommandType,
    val conversationId: String = "",
    val customerId: String = "",
    val listingId: String = "",
    val messageId: String = "",
    val payload: String = "", // JSON or descriptive summary
    val status: CommandStatus = CommandStatus.PENDING,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val retryCount: Int = 0,
    val maxRetries: Int = 5,
    val nextRetryAt: Long = 0L,
    val lastAttemptAt: Long = 0L,
    val errorCode: String? = null,
    val errorMessage: String? = null,
    val processedAt: Long? = null,
    val completedAt: Long? = null,
    val resultMessage: String? = null
)

@Entity(tableName = "api_keys")
data class BotConnection(
    @PrimaryKey val id: String,
    val userId: String = "",
    val profileId: String,
    val maskedKey: String, // e.g. "mpc_live_••••••••••••1234"
    val keyPrefix: String = "mpc_live_",
    val keyLastFour: String = "",
    val serverUrl: String = "",
    val status: String = "ACTIVE", // ACTIVE, REVOKED, EXPIRED
    val lastHeartbeat: Long = System.currentTimeMillis(),
    val botVersion: String = "DesktopBot v2.4.1",
    val createdAt: Long = System.currentTimeMillis()
) {
    // Read-only display key (never plain secret)
    val displayKey: String get() = maskedKey
    val apiKey: String get() = maskedKey
}

@Entity(tableName = "auto_reply_rules")
data class AutoReplyRule(
    @PrimaryKey val id: String,
    val userId: String = "",
    val trigger: String,
    val reply: String,
    val enabled: Boolean = true,
    val matchCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey val id: String,
    val userId: String = "",
    val type: String, // NEW_MESSAGE, BOT_CONNECTED, BOT_DISCONNECTED, PROFILE_OFFLINE, PROFILE_REOPENED, MESSAGE_SENT, MESSAGE_FAILED, BOT_ERROR, LISTING_ACTIVITY
    val title: String,
    val body: String,
    val targetScreen: String = "INBOX", // INBOX, CHAT, PROFILES, LISTINGS, API_KEYS
    val targetId: String? = null,
    val read: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class ConversationWithDetails(
    val conversation: Conversation,
    val customer: Customer,
    val listing: Listing,
    val profile: ChromeProfile
)
