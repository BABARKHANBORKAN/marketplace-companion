package com.example.data.repository

import android.content.Context
import com.example.data.bot.BotCommandDispatcher
import com.example.data.bot.DispatchResult
import com.example.data.bot.RealBotCommandDispatcher
import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.AutoReplyRule
import com.example.data.model.BotCommand
import com.example.data.model.BotConnection
import com.example.data.model.ChromeProfile
import com.example.data.model.CommandStatus
import com.example.data.model.CommandType
import com.example.data.model.Conversation
import com.example.data.model.ConversationWithDetails
import com.example.data.model.Customer
import com.example.data.model.Listing
import com.example.data.model.ListingStatus
import com.example.data.model.Message
import com.example.data.model.MessageSender
import com.example.data.model.MessageStatus
import com.example.data.model.ProfileStatus
import com.example.data.model.User
import com.example.data.network.ApiClientProvider
import com.example.data.network.AppsCodeLoginRequest
import com.example.data.network.CreateListingRequest
import com.example.data.network.CreateProfileRequest
import com.example.data.network.ForgotPasswordRequest
import com.example.data.network.LoginRequest
import com.example.data.network.MarketplaceApiService
import com.example.data.network.RefreshTokenRequest
import com.example.data.network.RegisterRequest
import com.example.data.preferences.AuthSession
import com.example.data.preferences.UserSessionManager
import com.example.data.sync.SyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class MarketplaceRepository(
    private val database: AppDatabase,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO),
    val sessionManager: UserSessionManager? = null,
    private val context: Context? = null
) {
    private val profileDao = database.chromeProfileDao()
    private val customerDao = database.customerDao()
    private val listingDao = database.listingDao()
    private val conversationDao = database.conversationDao()
    private val messageDao = database.messageDao()
    private val commandDao = database.botCommandDao()
    private val botConnectionDao = database.botConnectionDao()
    private val autoReplyDao = database.autoReplyRuleDao()
    private val notificationDao = database.notificationDao()
    private val userDao = database.userDao()

    // Lazy/dynamic API Service based on current session token & server URL
    private var cachedServerUrl: String = "http://13.60.48.34:8080/"
    private var cachedToken: String? = null
    private var cachedApiService: MarketplaceApiService = createFreshApiService(cachedServerUrl, cachedToken)

    private fun createFreshApiService(baseUrl: String, token: String?): MarketplaceApiService {
        return ApiClientProvider.createService(
            baseUrl = baseUrl,
            tokenProvider = { cachedToken },
            tokenRefresher = {
                // Synchronously refresh token if 401 occurs
                sessionManager?.let { sm ->
                    runBlocking {
                        val refreshToken = sm.getCurrentRefreshToken() ?: return@runBlocking null
                        try {
                            val tempService = ApiClientProvider.createService(cachedServerUrl, { null })
                            val response = tempService.refreshToken(RefreshTokenRequest(refreshToken))
                            if (response.isSuccessful && response.body() != null) {
                                val auth = response.body()!!
                                sm.saveAuthToken(
                                    token = auth.token,
                                    refreshToken = auth.refreshToken ?: refreshToken,
                                    userId = auth.user.id,
                                    email = auth.user.email,
                                    name = auth.user.name
                                )
                                cachedToken = auth.token
                                auth.token
                            } else {
                                null
                            }
                        } catch (_: Exception) {
                            null
                        }
                    }
                }
            },
            onAuthFailure = {
                scope.launch {
                    sessionManager?.clearSession()
                }
            }
        )
    }

    private fun getApiService(): MarketplaceApiService = cachedApiService

    private fun refreshApiClient(baseUrl: String, token: String?) {
        cachedServerUrl = baseUrl
        cachedToken = token
        cachedApiService = createFreshApiService(baseUrl, token)
    }

    // API Key Provider Infrastructure
    val apiKeyRepository: ApiKeyRepository = ApiKeyRepository(
        backendProvider = BackendApiKeyProvider(
            apiServiceProvider = { getApiService() },
            botConnectionDao = botConnectionDao
        )
    )

    // Bot Command Dispatcher
    val realDispatcher = RealBotCommandDispatcher(database) { getApiService() }

    private fun getDispatcher(): BotCommandDispatcher = realDispatcher

    // Background Sync Manager
    val syncManager = sessionManager?.let { sm ->
        SyncManager(
            database = database,
            sessionManager = sm,
            apiServiceProvider = { getApiService() },
            realDispatcher = realDispatcher,
            scope = scope
        )
    }

    init {
        sessionManager?.let { sm ->
            scope.launch {
                sm.sessionFlow.collect { session ->
                    refreshApiClient(session.serverUrl, session.token)
                    if (session.isAuthenticated) {
                        syncManager?.connectWebSocket()
                    } else {
                        syncManager?.disconnectWebSocket()
                    }
                }
            }
            syncManager?.startPeriodicSync()
        }
    }

    // Current authenticated user ID stream for strict cache isolation
    private val currentUserIdFlow: Flow<String?> =
        sessionManager?.sessionFlow?.map { it.userId } ?: flowOf(null)

    suspend fun getCurrentUserId(): String {
        return sessionManager?.sessionFlow?.firstOrNull()?.userId ?: ""
    }

    val allProfiles: Flow<List<ChromeProfile>> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else profileDao.getProfilesByUser(uid)
    }

    val allListings: Flow<List<Listing>> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else listingDao.getListingsByUser(uid)
    }

    val allCommands: Flow<List<BotCommand>> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else commandDao.getCommandsByUser(uid)
    }

    val allApiKeys: Flow<List<BotConnection>> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else botConnectionDao.getApiKeysByUser(uid)
    }

    val allAutoReplies: Flow<List<AutoReplyRule>> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else autoReplyDao.getRulesByUser(uid)
    }

    val allNotifications: Flow<List<AppNotification>> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else notificationDao.getNotificationsByUser(uid)
    }

    val unreadNotificationsCount: Flow<Int> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(0) else notificationDao.getUnreadCountByUser(uid)
    }

    val currentUser: Flow<User?> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(null) else userDao.getUserById(uid)
    }

    val webSocketState: Flow<com.example.data.network.WebSocketState>? = syncManager?.webSocketState

    fun reconnectWebSocket() {
        syncManager?.reconnectWebSocket()
    }

    val authSession: Flow<AuthSession>? = sessionManager?.sessionFlow

    // Combined Flow for rich Inbox view with Customer, Listing, and Profile associations (user isolated)
    val conversationsWithDetails: Flow<List<ConversationWithDetails>> = currentUserIdFlow.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) {
            flowOf(emptyList())
        } else {
            combine(
                conversationDao.getConversationsByUser(uid),
                customerDao.getCustomersByUser(uid),
                listingDao.getListingsByUser(uid),
                profileDao.getProfilesByUser(uid)
            ) { convs, customers, listings, profiles ->
                val customerMap = customers.associateBy { it.id }
                val listingMap = listings.associateBy { it.id }
                val profileMap = profiles.associateBy { it.id }

                convs.mapNotNull { conv ->
                    val customer = customerMap[conv.customerId] ?: return@mapNotNull null
                    val listing = listingMap[conv.listingId] ?: return@mapNotNull null
                    val profile = profileMap[conv.profileId] ?: ChromeProfile(
                        id = conv.profileId,
                        userId = uid,
                        name = "Unknown Profile",
                        accountLabel = "Unassigned",
                        status = ProfileStatus.OFFLINE
                    )
                    ConversationWithDetails(
                        conversation = conv,
                        customer = customer,
                        listing = listing,
                        profile = profile
                    )
                }
            }
        }
    }

    fun getMessagesForConversation(conversationId: String): Flow<List<Message>> =
        messageDao.getMessagesForConversation(conversationId)

    fun getProfile(profileId: String): Flow<ChromeProfile?> =
        profileDao.getProfileById(profileId)

    fun getListing(listingId: String): Flow<Listing?> =
        listingDao.getListingById(listingId)

    fun getConversation(conversationId: String): Flow<Conversation?> =
        conversationDao.getConversationById(conversationId)

    suspend fun getConversationDetails(conversationId: String): ConversationWithDetails? {
        val conv = conversationDao.getConversationByIdSync(conversationId) ?: return null
        val customer = customerDao.getCustomerById(conv.customerId) ?: return null
        val listing = listingDao.getListingByIdSync(conv.listingId) ?: return null
        val profile = profileDao.getProfileByIdSync(conv.profileId) ?: ChromeProfile(
            id = conv.profileId,
            userId = conv.userId,
            name = "Profile",
            accountLabel = "Account",
            status = ProfileStatus.OFFLINE
        )
        return ConversationWithDetails(conv, customer, listing, profile)
    }

    // --- Core Action: Reopen Chrome Profile ---
    suspend fun reopenChromeProfile(profileId: String): DispatchResult {
        val userId = getCurrentUserId()
        val commandId = "cmd_" + UUID.randomUUID().toString().take(8)
        val idempotencyKey = "idemp_" + UUID.randomUUID().toString()
        val command = BotCommand(
            id = commandId,
            idempotencyKey = idempotencyKey,
            userId = userId,
            profileId = profileId,
            type = CommandType.REOPEN_CHROME_PROFILE,
            payload = "{\"action\":\"REOPEN_CHROME_PROFILE\",\"profileId\":\"$profileId\"}",
            status = CommandStatus.PENDING
        )
        commandDao.insertCommand(command)

        return getDispatcher().reopenChromeProfile(profileId, commandId)
    }

    // --- Core Action: Stop Current Task ---
    suspend fun stopCurrentTask(profileId: String): DispatchResult {
        val userId = getCurrentUserId()
        val commandId = "cmd_" + UUID.randomUUID().toString().take(8)
        val idempotencyKey = "idemp_" + UUID.randomUUID().toString()
        val command = BotCommand(
            id = commandId,
            idempotencyKey = idempotencyKey,
            userId = userId,
            profileId = profileId,
            type = CommandType.STOP_CURRENT_TASK,
            payload = "{\"action\":\"STOP_CURRENT_TASK\",\"profileId\":\"$profileId\"}",
            status = CommandStatus.PENDING
        )
        commandDao.insertCommand(command)

        return getDispatcher().stopCurrentTask(profileId, commandId)
    }

    // --- Core Action: Open Customer Chat in Chrome ---
    suspend fun openCustomerChatInChrome(profileId: String, conversationId: String): DispatchResult {
        val convDetails = getConversationDetails(conversationId)
        val userId = getCurrentUserId()
        val commandId = "cmd_" + UUID.randomUUID().toString().take(8)
        val idempotencyKey = "idemp_" + UUID.randomUUID().toString()
        val customerId = convDetails?.customer?.id ?: ""
        val listingId = convDetails?.listing?.id ?: ""

        val command = BotCommand(
            id = commandId,
            idempotencyKey = idempotencyKey,
            userId = userId,
            profileId = profileId,
            type = CommandType.OPEN_CUSTOMER_CHAT,
            conversationId = conversationId,
            customerId = customerId,
            listingId = listingId,
            payload = "{\"profileId\":\"$profileId\",\"conversationId\":\"$conversationId\",\"customerId\":\"$customerId\",\"listingId\":\"$listingId\"}",
            status = CommandStatus.PENDING
        )
        commandDao.insertCommand(command)

        return getDispatcher().openCustomerChatInChrome(profileId, conversationId, commandId)
    }

    // --- Core Action: Send Message ---
    suspend fun sendMessage(
        conversationId: String,
        text: String,
        stopTaskFirst: Boolean = false,
        reopenChromeFirst: Boolean = false
    ): String {
        val convDetails = getConversationDetails(conversationId) ?: return ""
        val profile = convDetails.profile
        val userId = getCurrentUserId()
        val messageId = "msg_" + UUID.randomUUID().toString().take(8)
        val commandId = "cmd_" + UUID.randomUUID().toString().take(8)
        val idempotencyKey = "idemp_" + UUID.randomUUID().toString()

        if (stopTaskFirst) {
            stopCurrentTask(profile.id)
        }
        if (reopenChromeFirst) {
            reopenChromeProfile(profile.id)
        }

        // Insert message with initial PENDING delivery status
        val message = Message(
            id = messageId,
            conversationId = conversationId,
            sender = MessageSender.USER_APP,
            text = text,
            status = MessageStatus.PENDING,
            timestamp = System.currentTimeMillis(),
            commandId = commandId,
            idempotencyKey = idempotencyKey
        )
        messageDao.insertMessage(message)

        // Update conversation preview
        conversationDao.updateLastMessage(
            id = conversationId,
            lastMessage = "You: $text",
            timestamp = System.currentTimeMillis()
        )

        // Create BotCommand record with complete context
        val command = BotCommand(
            id = commandId,
            idempotencyKey = idempotencyKey,
            userId = userId,
            profileId = profile.id,
            type = CommandType.SEND_MESSAGE,
            conversationId = conversationId,
            customerId = convDetails.customer.id,
            listingId = convDetails.listing.id,
            messageId = messageId,
            payload = "{\"conversationId\":\"$conversationId\",\"message\":\"${text.replace("\"", "\\\"")}\"}",
            status = CommandStatus.PENDING
        )
        commandDao.insertCommand(command)

        getDispatcher().sendMessage(conversationId, profile.id, text, messageId, commandId)
        return messageId
    }

    // --- Authentication Operations ---
    suspend fun login(email: String, pass: String): Result<String> {
        return try {
            val response = getApiService().login(LoginRequest(email, pass))
            if (response.isSuccessful && response.body() != null) {
                val auth = response.body()!!
                val u = auth.user
                userDao.insertUser(User(id = u.id, name = u.name, email = u.email, plan = u.plan))
                sessionManager?.saveAuthToken(auth.token, auth.refreshToken, u.id, u.email, u.name)
                Result.success("Login successful")
            } else {
                Result.failure(Exception("Login failed: ${response.message()} (${response.code()})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun register(name: String, email: String, pass: String): Result<String> {
        return try {
            val response = getApiService().register(RegisterRequest(name, email, pass))
            if (response.isSuccessful && response.body() != null) {
                val auth = response.body()!!
                val u = auth.user
                userDao.insertUser(User(id = u.id, name = u.name, email = u.email, plan = u.plan))
                sessionManager?.saveAuthToken(auth.token, auth.refreshToken, u.id, u.email, u.name)
                Result.success("Registration successful")
            } else {
                Result.failure(Exception("Registration error: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun loginWithAppsCode(code: String): Result<String> {
        return try {
            val response = getApiService().loginWithAppsCode(AppsCodeLoginRequest(code))
            if (response.isSuccessful && response.body() != null) {
                val auth = response.body()!!
                val u = auth.user
                userDao.insertUser(User(id = u.id, name = u.name, email = u.email, plan = u.plan))
                sessionManager?.saveAuthToken(auth.token, auth.refreshToken, u.id, u.email, u.name)
                Result.success("Login successful")
            } else {
                val message = if (response.code() == 401) "Invalid or expired Apps Code" else "Login failed: ${response.message()} (${response.code()})"
                Result.failure(Exception(message))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun forgotPassword(email: String): Result<String> {
        return try {
            val response = getApiService().forgotPassword(ForgotPasswordRequest(email))
            if (response.isSuccessful) {
                Result.success("Password reset instructions sent to your email")
            } else {
                Result.failure(Exception("Failed to send reset link: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun logout() {
        sessionManager?.clearSession()
    }

    suspend fun updateServerUrl(url: String) {
        sessionManager?.updateServerUrl(url)
        refreshApiClient(url, cachedToken)
    }

    // --- Hardened API Key Management (One-time Reveal, Backend-Generated) ---
    suspend fun generateApiKey(profileId: String, serverUrl: String): GeneratedKeyResult {
        val finalServerUrl = serverUrl.ifBlank { cachedServerUrl }
        val userId = getCurrentUserId()
        val result = apiKeyRepository.generateKey(profileId, finalServerUrl, userId)

        if (result is GeneratedKeyResult.Success) {
            notificationDao.insertNotification(
                AppNotification(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    type = "BOT_CONNECTED",
                    title = "New API Key Generated",
                    body = "Key generated for $profileId. Connect your Desktop Bot using this credential.",
                    targetScreen = "API_KEYS",
                    targetId = result.connection.id
                )
            )
        }
        return result
    }

    suspend fun revokeApiKey(id: String) {
        apiKeyRepository.revokeKey(id)
    }

    suspend fun deleteApiKey(id: String) {
        botConnectionDao.deleteApiKey(id)
        runCatching { getApiService().deleteApiKey(id) }
    }

    // --- Profile Operations (Server-Side Confirmation & Multi-User Isolated) ---
    suspend fun createProfile(name: String, accountLabel: String): String {
        val userId = getCurrentUserId()
        val id = "profile_" + UUID.randomUUID().toString().take(8)

        try {
            val response = getApiService().createProfile(CreateProfileRequest(name, accountLabel))
            if (response.isSuccessful && response.body() != null) {
                val dto = response.body()!!
                val confirmedProfile = ChromeProfile(
                    id = dto.id,
                    userId = dto.userId ?: userId,
                    name = dto.name,
                    accountLabel = dto.accountLabel,
                    status = ProfileStatus.ONLINE,
                    currentTask = "Idle",
                    chromeWindowName = dto.chromeWindowName ?: "Google Chrome - ${dto.name}",
                    syncStatus = "CONFIRMED"
                )
                profileDao.insertProfile(confirmedProfile)
                return confirmedProfile.id
            }
        } catch (_: Exception) {
            // Server unavailable: persist with LOCAL_PENDING status
        }

        val profile = ChromeProfile(
            id = id,
            userId = userId,
            name = name,
            accountLabel = accountLabel,
            status = ProfileStatus.ONLINE,
            currentTask = "Idle",
            chromeWindowName = "Google Chrome - $name",
            syncStatus = "LOCAL_PENDING"
        )
        profileDao.insertProfile(profile)
        return id
    }

    suspend fun updateProfileStatus(id: String, status: ProfileStatus, task: String) {
        profileDao.updateProfileStatus(id, status, task, System.currentTimeMillis())
    }

    // Unlike updateProfileStatus, this sticks: incoming heartbeats/delta sync skip profiles
    // flagged manuallyDisconnected, so status stays OFFLINE until connectProfile() is called.
    suspend fun disconnectProfile(id: String) {
        profileDao.setManualConnectionState(
            id = id,
            disconnected = true,
            status = ProfileStatus.OFFLINE,
            currentTask = "Disconnected by user",
            timestamp = System.currentTimeMillis()
        )
    }

    suspend fun connectProfile(id: String) {
        profileDao.setManualConnectionState(
            id = id,
            disconnected = false,
            status = ProfileStatus.ONLINE,
            currentTask = "Idle",
            timestamp = System.currentTimeMillis()
        )
    }

    suspend fun deleteProfile(id: String) {
        profileDao.deleteProfile(id)
        runCatching { getApiService().deleteProfile(id) }
    }

    // --- Listing Operations (Server-Side Confirmation & Multi-User Isolated) ---
    suspend fun createListing(
        title: String,
        price: Double,
        category: String,
        description: String,
        profileId: String
    ): String {
        val userId = getCurrentUserId()
        val id = "listing_" + UUID.randomUUID().toString().take(6)

        try {
            val response = getApiService().createListing(
                CreateListingRequest(
                    profileId = profileId,
                    title = title,
                    price = price,
                    category = category,
                    description = description
                )
            )
            if (response.isSuccessful && response.body() != null) {
                val dto = response.body()!!
                val confirmedListing = Listing(
                    id = dto.id,
                    userId = userId,
                    profileId = dto.profileId,
                    title = dto.title,
                    price = dto.price,
                    category = dto.category,
                    description = dto.description,
                    status = ListingStatus.ACTIVE,
                    createdAt = dto.createdAt,
                    syncStatus = "CONFIRMED"
                )
                listingDao.insertListing(confirmedListing)
                return confirmedListing.id
            }
        } catch (_: Exception) {
            // Server unavailable: persist with LOCAL_PENDING
        }

        val listing = Listing(
            id = id,
            userId = userId,
            profileId = profileId,
            title = title,
            price = price,
            category = category,
            description = description,
            status = ListingStatus.ACTIVE,
            createdAt = System.currentTimeMillis(),
            syncStatus = "LOCAL_PENDING"
        )
        listingDao.insertListing(listing)
        return id
    }

    suspend fun updateListing(listing: Listing) {
        listingDao.updateListing(listing)
    }

    suspend fun deleteListing(id: String) {
        listingDao.deleteListing(id)
        runCatching { getApiService().deleteListing(id) }
    }

    // --- Auto Reply Operations ---
    suspend fun createAutoReplyRule(trigger: String, reply: String) {
        val userId = getCurrentUserId()
        val rule = AutoReplyRule(
            id = "rule_" + UUID.randomUUID().toString().take(6),
            userId = userId,
            trigger = trigger,
            reply = reply,
            enabled = true
        )
        autoReplyDao.insertRule(rule)
    }

    suspend fun toggleAutoReplyRule(id: String, enabled: Boolean) {
        autoReplyDao.toggleRule(id, enabled)
    }

    suspend fun deleteAutoReplyRule(id: String) {
        autoReplyDao.deleteRule(id)
    }

    // --- Notifications & Read State ---
    suspend fun markConversationRead(conversationId: String) {
        conversationDao.markAsRead(conversationId)
    }

    suspend fun markNotificationRead(id: String) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsRead() {
        val userId = getCurrentUserId()
        if (userId.isNotBlank()) {
            notificationDao.markAllAsReadForUser(userId)
        } else {
            notificationDao.markAllAsRead()
        }
    }

    suspend fun clearNotifications() {
        val userId = getCurrentUserId()
        if (userId.isNotBlank()) {
            notificationDao.clearAllForUser(userId)
        } else {
            notificationDao.clearAll()
        }
    }

    suspend fun updateUserName(name: String, email: String) {
        val userId = getCurrentUserId().ifBlank { "user_default" }
        userDao.insertUser(User(id = userId, name = name, email = email))
    }
}
