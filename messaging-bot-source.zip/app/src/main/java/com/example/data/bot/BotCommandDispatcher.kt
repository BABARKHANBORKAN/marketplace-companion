package com.example.data.bot

sealed class DispatchResult {
    data class Success(val commandId: String, val message: String) : DispatchResult()
    data class Queued(val commandId: String, val reason: String) : DispatchResult()
    data class Failed(val commandId: String, val error: String) : DispatchResult()
}

interface BotCommandDispatcher {
    suspend fun reopenChromeProfile(profileId: String, commandId: String): DispatchResult
    suspend fun stopCurrentTask(profileId: String, commandId: String): DispatchResult
    suspend fun openCustomerChatInChrome(profileId: String, conversationId: String, commandId: String): DispatchResult
    suspend fun sendMessage(
        conversationId: String,
        profileId: String,
        text: String,
        messageId: String,
        commandId: String
    ): DispatchResult
}
