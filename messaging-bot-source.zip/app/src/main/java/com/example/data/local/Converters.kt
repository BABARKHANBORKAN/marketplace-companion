package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.CommandStatus
import com.example.data.model.CommandType
import com.example.data.model.ListingStatus
import com.example.data.model.MessageSender
import com.example.data.model.MessageStatus
import com.example.data.model.ProfileStatus

class Converters {
    @TypeConverter
    fun fromProfileStatus(value: ProfileStatus): String = value.name

    @TypeConverter
    fun toProfileStatus(value: String): ProfileStatus = try {
        ProfileStatus.valueOf(value)
    } catch (_: Exception) {
        ProfileStatus.OFFLINE
    }

    @TypeConverter
    fun fromListingStatus(value: ListingStatus): String = value.name

    @TypeConverter
    fun toListingStatus(value: String): ListingStatus = try {
        ListingStatus.valueOf(value)
    } catch (_: Exception) {
        ListingStatus.ACTIVE
    }

    @TypeConverter
    fun fromMessageSender(value: MessageSender): String = value.name

    @TypeConverter
    fun toMessageSender(value: String): MessageSender = try {
        MessageSender.valueOf(value)
    } catch (_: Exception) {
        MessageSender.CUSTOMER
    }

    @TypeConverter
    fun fromMessageStatus(value: MessageStatus): String = value.name

    @TypeConverter
    fun toMessageStatus(value: String): MessageStatus = try {
        MessageStatus.valueOf(value)
    } catch (_: Exception) {
        MessageStatus.SENT
    }

    @TypeConverter
    fun fromCommandType(value: CommandType): String = value.name

    @TypeConverter
    fun toCommandType(value: String): CommandType = try {
        CommandType.valueOf(value)
    } catch (_: Exception) {
        CommandType.SEND_MESSAGE
    }

    @TypeConverter
    fun fromCommandStatus(value: CommandStatus): String = value.name

    @TypeConverter
    fun toCommandStatus(value: String): CommandStatus = try {
        CommandStatus.valueOf(value)
    } catch (_: Exception) {
        CommandStatus.PENDING
    }
}
