package com.example.data.sync

import com.example.data.bot.CommandStateMachine
import com.example.data.bot.RealBotCommandDispatcher
import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.ChromeProfile
import com.example.data.model.CommandStatus
import com.example.data.model.CommandType
import com.example.data.model.Conversation
import com.example.data.model.Customer
import com.example.data.model.Listing
import com.example.data.model.ListingStatus
import com.example.data.model.Message
import com.example.data.model.MessageSender
import com.example.data.model.MessageStatus
import com.example.data.model.ProfileStatus
import com.example.data.network.InboundEventDto
import com.example.data.network.MarketplaceApiService
import com.example.data.network.WebSocketManager
import com.example.data.network.WebSocketState
import com.example.data.preferences.UserSessionManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Collections
import java.util.UUID

class SyncManager(
    private val database: AppDatabase,
    private val sessionManager: UserSessionManager,
    private val apiServiceProvider: () -> MarketplaceApiService,
    private val realDispatcher: RealBotCommandDispatcher,
    private val scope: CoroutineScope
) {
    private val profileDao = database.chromeProfileDao()
    private val listingDao = database.listingDao()
    private val conversationDao = database.conversationDao()
    private val messageDao = database.messageDao()
    private val commandDao = database.botCommandDao()
    private val customerDao = database.customerDao()
    private val notificationDao = database.notificationDao()

    // Deduplication set to prevent duplicate event ingestion between SSE/WebSocket and Polling
    private val processedEventIds = Collections.synchronizedSet(mutableSetOf<String>())

    // In-memory cursor for incremental delta sync
    private var syncCursor: String? = null

    // Real OkHttp WebSocket Manager
    private val webSocketManager: WebSocketManager = WebSocketManager(
        serverUrlProvider = {
            kotlinx.coroutines.runBlocking {
                sessionManager.sessionFlow.first().serverUrl
            }
        },
        tokenProvider = {
            kotlinx.coroutines.runBlocking {
                sessionManager.getCurrentToken()
            }
        },
        onEventReceived = { event ->
            processInboundEvent(event)
        },
        scope = scope
    )

    val webSocketState: StateFlow<WebSocketState> = webSocketManager.connectionState

    fun connectWebSocket() {
        webSocketManager.connect()
    }

    fun disconnectWebSocket() {
        webSocketManager.disconnect()
    }

    fun reconnectWebSocket() {
        webSocketManager.reconnect()
    }

    companion object {
        const val HEARTBEAT_TIMEOUT_MS = 90_000L // 90 seconds timeout
        const val SYNC_INTERVAL_MS = 30_000L     // Periodic delta sync fallback
        const val COMMAND_PROCESSING_TIMEOUT_MS = 120_000L // 2 minutes, matches backend's default
    }

    /**
     * Start background loop for periodic sync, retry execution, and heartbeat auditing
     */
    fun startPeriodicSync() {
        scope.launch {
            while (isActive) {
                delay(SYNC_INTERVAL_MS)
                val session = sessionManager.sessionFlow.first()
                if (session.isAuthenticated) {
                    performLiveSync()
                }
                checkBotHeartbeats()
                checkStaleProcessingCommands()
            }
        }
    }

    /**
     * Settles commands that never got a COMPLETED/FAILED update from the backend (WebSocket
     * push or delta sync) within a bounded window — e.g. because the desktop bot isn't actually
     * running, or never picked the command up. Without this, a command can be left showing
     * PROCESSING in the UI indefinitely, which looks like the app is stuck even though it's
     * really the bot side that never responded.
     */
    suspend fun checkStaleProcessingCommands() {
        val now = System.currentTimeMillis()
        val pending = commandDao.getPendingCommands().first()

        for (command in pending) {
            if (command.status != CommandStatus.PROCESSING) continue
            val elapsed = now - command.updatedAt
            if (elapsed <= COMMAND_PROCESSING_TIMEOUT_MS) continue

            if (CommandStateMachine.isValidTransition(command.status, CommandStatus.FAILED)) {
                commandDao.updateCommandStatus(
                    id = command.id,
                    status = CommandStatus.FAILED,
                    completedAt = now,
                    resultMessage = "Timed out waiting for the desktop bot to respond. Make sure the bot is running and connected, then try again."
                )
                if (command.messageId.isNotBlank()) {
                    messageDao.updateMessageStatus(command.messageId, MessageStatus.FAILED)
                }
            }
        }
    }

    /**
     * Audit profile heartbeats and mark profiles OFFLINE if daemon stopped pinging
     */
    suspend fun checkBotHeartbeats() {
        val session = sessionManager.sessionFlow.first()
        val userId = session.userId ?: return
        val profiles = profileDao.getProfilesByUser(userId).first()
        val now = System.currentTimeMillis()

        for (profile in profiles) {
            val elapsed = now - profile.lastHeartbeat
            if (elapsed > HEARTBEAT_TIMEOUT_MS && profile.status != ProfileStatus.OFFLINE) {
                profileDao.updateProfileStatus(
                    id = profile.id,
                    status = ProfileStatus.OFFLINE,
                    currentTask = "Desktop Bot Disconnected (No Heartbeat)",
                    timestamp = now
                )
                profileDao.updateHeartbeat(profile.id, profile.lastHeartbeat, "OFFLINE")

                notificationDao.insertNotification(
                    AppNotification(
                        id = UUID.randomUUID().toString(),
                        userId = userId,
                        type = "PROFILE_OFFLINE",
                        title = "${profile.name} Went Offline",
                        body = "Desktop daemon has not reported heartbeat for over 90 seconds.",
                        targetScreen = "PROFILES",
                        targetId = profile.id
                    )
                )
            }
        }
    }

    /**
     * Ingest and process a real-time event (e.g. from WebSocket or SSE channel) with deduplication
     */
    suspend fun processInboundEvent(event: InboundEventDto) {
        if (!processedEventIds.add(event.id)) {
            // Already processed this event
            return
        }

        when (event.type) {
            "NEW_MESSAGE" -> {
                // Parse and insert message if not already present
                runCatching {
                    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                    val adapter = moshi.adapter(Map::class.java)
                    val map = adapter.fromJson(event.payload) as? Map<String, Any> ?: return
                    val msgId = map["id"] as? String ?: return
                    val convId = map["conversationId"] as? String ?: return
                    val text = map["text"] as? String ?: ""
                    val senderStr = map["sender"] as? String ?: "CUSTOMER"

                    if (messageDao.getMessageById(msgId) == null) {
                        val sender = try { MessageSender.valueOf(senderStr) } catch (_: Exception) { MessageSender.CUSTOMER }
                        val message = Message(
                            id = msgId,
                            conversationId = convId,
                            sender = sender,
                            text = text,
                            status = MessageStatus.SENT,
                            timestamp = event.timestamp
                        )
                        messageDao.insertMessage(message)
                        conversationDao.updateLastMessage(
                            id = convId,
                            lastMessage = text,
                            timestamp = event.timestamp,
                            unreadIncrement = if (sender == MessageSender.CUSTOMER) 1 else 0
                        )
                    }
                }
            }

            "MESSAGE_STATUS_UPDATE" -> {
                runCatching {
                    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                    val adapter = moshi.adapter(Map::class.java)
                    val map = adapter.fromJson(event.payload) as? Map<String, Any> ?: return
                    val msgId = map["messageId"] as? String ?: return
                    val statusStr = map["status"] as? String ?: "SENT"
                    val status = try { MessageStatus.valueOf(statusStr) } catch (_: Exception) { MessageStatus.SENT }

                    val existingMsg = messageDao.getMessageById(msgId)
                    if (existingMsg != null && CommandStateMachine.isValidMessageTransition(existingMsg.status, status)) {
                        messageDao.updateMessageStatus(msgId, status)
                    }
                }
            }

            "BOT_HEARTBEAT" -> {
                runCatching {
                    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                    val adapter = moshi.adapter(Map::class.java)
                    val map = adapter.fromJson(event.payload) as? Map<String, Any> ?: return
                    val profileId = map["profileId"] as? String ?: return
                    val existingProfile = profileDao.getProfileByIdSync(profileId)
                    if (existingProfile?.manuallyDisconnected == true) return
                    val statusStr = map["status"] as? String ?: "ACTIVE"
                    val currentTask = map["currentTask"] as? String ?: "Idle"
                    val profileStatus = when (statusStr.uppercase()) {
                        "ACTIVE" -> ProfileStatus.ONLINE
                        "BUSY" -> ProfileStatus.BUSY
                        else -> ProfileStatus.OFFLINE
                    }
                    profileDao.updateProfileStatus(profileId, profileStatus, currentTask, event.timestamp)
                    profileDao.updateHeartbeat(profileId, event.timestamp, statusStr)
                }
            }

            "COMMAND_STATUS_UPDATE" -> {
                runCatching {
                    val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                    val adapter = moshi.adapter(Map::class.java)
                    val map = adapter.fromJson(event.payload) as? Map<String, Any> ?: return
                    val cmdId = map["commandId"] as? String ?: return
                    val statusStr = map["status"] as? String ?: "COMPLETED"
                    val targetStatus = try { CommandStatus.valueOf(statusStr) } catch (_: Exception) { CommandStatus.COMPLETED }
                    val resultMessage = map["resultMessage"] as? String

                    val existingCmd = commandDao.getCommandById(cmdId)
                    if (existingCmd != null && CommandStateMachine.isValidTransition(existingCmd.status, targetStatus)) {
                        commandDao.updateCommandStatus(cmdId, targetStatus, event.timestamp, resultMessage)
                        // If this command delivered a message and reached COMPLETED, mark message as SENT
                        if (targetStatus == CommandStatus.COMPLETED && !existingCmd.messageId.isBlank()) {
                            messageDao.updateMessageStatus(existingCmd.messageId, MessageStatus.SENT)
                        } else if (targetStatus == CommandStatus.FAILED && !existingCmd.messageId.isBlank()) {
                            messageDao.updateMessageStatus(existingCmd.messageId, MessageStatus.FAILED)
                        }
                    }
                }
            }
        }
    }

    /**
     * Retry pending offline commands and sync delta with backend
     */
    suspend fun performLiveSync() {
        val now = System.currentTimeMillis()

        // 1. Retry pending queued commands that have reached their scheduled retry time
        val pendingCommands = commandDao.getPendingCommands().first()
        for (cmd in pendingCommands) {
            // Only retry if nextRetryAt is 0 (immediate) or current time >= nextRetryAt
            if (cmd.nextRetryAt > 0 && now < cmd.nextRetryAt) {
                continue
            }

            when (cmd.type) {
                CommandType.REOPEN_CHROME_PROFILE -> {
                    realDispatcher.reopenChromeProfile(cmd.profileId, cmd.id)
                }
                CommandType.STOP_CURRENT_TASK -> {
                    realDispatcher.stopCurrentTask(cmd.profileId, cmd.id)
                }
                CommandType.OPEN_CUSTOMER_CHAT -> {
                    // Retain full conversationId, customerId, listingId context
                    realDispatcher.openCustomerChatInChrome(
                        profileId = cmd.profileId,
                        conversationId = cmd.conversationId,
                        commandId = cmd.id
                    )
                }
                CommandType.SEND_MESSAGE -> {
                    val msg = if (cmd.messageId.isNotBlank()) {
                        messageDao.getMessageById(cmd.messageId)
                    } else {
                        messageDao.getMessageByCommandId(cmd.id)
                    }
                    if (msg != null) {
                        realDispatcher.sendMessage(
                            conversationId = cmd.conversationId.ifBlank { msg.conversationId },
                            profileId = cmd.profileId,
                            text = msg.text,
                            messageId = msg.id,
                            commandId = cmd.id
                        )
                    }
                }
                else -> {}
            }
        }

        // 2. Fetch server updates (Delta Sync)
        try {
            val session = sessionManager.sessionFlow.first()
            val currentUserId = session.userId
            if (currentUserId.isNullOrBlank()) return

            val api = apiServiceProvider()
            val response = api.fetchDeltaSync(
                cursor = syncCursor,
                sinceTimestamp = if (syncCursor == null) session.lastSyncTime else null
            )
            if (response.isSuccessful && response.body() != null) {
                val delta = response.body()!!
                if (!delta.cursor.isNullOrBlank()) {
                    syncCursor = delta.cursor
                }

                // Ingest updated profiles
                delta.profiles?.forEach { dto ->
                    val existing = profileDao.getProfileByIdSync(dto.id)
                    val isManuallyDisconnected = existing?.manuallyDisconnected == true
                    // insertProfile REPLACEs the whole row, so a manually-disconnected profile's
                    // status/flag must be explicitly preserved here or the next sync would silently
                    // reconnect it using the server's (stale, from this device's perspective) status.
                    val status = if (isManuallyDisconnected) {
                        ProfileStatus.OFFLINE
                    } else {
                        try { ProfileStatus.valueOf(dto.status) } catch (_: Exception) { ProfileStatus.OFFLINE }
                    }
                    val profile = ChromeProfile(
                        id = dto.id,
                        userId = dto.userId ?: currentUserId,
                        name = dto.name,
                        accountLabel = dto.accountLabel,
                        status = status,
                        currentTask = if (isManuallyDisconnected) (existing?.currentTask ?: "Disconnected by user") else (dto.currentTask ?: "Idle"),
                        lastSeen = dto.lastSeen ?: now,
                        lastHeartbeat = dto.lastHeartbeat ?: now,
                        lastHeartbeatAt = dto.lastHeartbeat ?: now,
                        listingCount = dto.listingCount,
                        conversationCount = dto.conversationCount,
                        unreadCount = dto.unreadCount,
                        chromeWindowName = dto.chromeWindowName ?: existing?.chromeWindowName ?: "Google Chrome - ${dto.name}",
                        botConnected = if (isManuallyDisconnected) false else dto.botConnected,
                        manuallyDisconnected = isManuallyDisconnected,
                        syncStatus = "CONFIRMED"
                    )
                    profileDao.insertProfile(profile)
                }

                // Ingest updated listings
                delta.listings?.forEach { dto ->
                    val status = try { ListingStatus.valueOf(dto.status) } catch (_: Exception) { ListingStatus.ACTIVE }
                    val listing = Listing(
                        id = dto.id,
                        userId = currentUserId,
                        profileId = dto.profileId,
                        title = dto.title,
                        price = dto.price,
                        currency = dto.currency,
                        status = status,
                        category = dto.category,
                        description = dto.description,
                        location = dto.location,
                        conversationCount = dto.conversationCount,
                        messageCount = dto.messageCount,
                        createdAt = dto.createdAt,
                        imageUrl = dto.imageUrl,
                        syncStatus = "CONFIRMED"
                    )
                    listingDao.insertListing(listing)
                }

                // Ingest updated conversations
                delta.conversations?.forEach { dto ->
                    val conv = Conversation(
                        id = dto.id,
                        userId = currentUserId,
                        profileId = dto.profileId,
                        customerId = dto.customerId,
                        listingId = dto.listingId,
                        unreadCount = dto.unreadCount,
                        lastMessage = dto.lastMessage ?: "",
                        lastMessageAt = dto.lastMessageAt,
                        isPinned = dto.isPinned
                    )
                    conversationDao.insertConversation(conv)

                    // Ensure customer record exists if customerName is provided
                    if (!dto.customerName.isNullOrBlank()) {
                        customerDao.insertCustomer(
                            Customer(
                                id = dto.customerId,
                                userId = currentUserId,
                                name = dto.customerName,
                                externalCustomerId = dto.customerId
                            )
                        )
                    }
                }

                // Ingest new messages with deduplication
                delta.messages?.forEach { dto ->
                    if (messageDao.getMessageById(dto.id) == null) {
                        val sender = try { MessageSender.valueOf(dto.sender) } catch (_: Exception) { MessageSender.CUSTOMER }
                        val status = try { MessageStatus.valueOf(dto.status) } catch (_: Exception) { MessageStatus.SENT }
                        val message = Message(
                            id = dto.id,
                            conversationId = dto.conversationId,
                            sender = sender,
                            text = dto.text,
                            status = status,
                            timestamp = dto.timestamp,
                            commandId = dto.commandId,
                            idempotencyKey = dto.idempotencyKey
                        )
                        messageDao.insertMessage(message)
                    }
                }

                // Process completed commands from server
                delta.completedCommands?.forEach { cmdDto ->
                    val status = try { CommandStatus.valueOf(cmdDto.status.uppercase()) } catch (_: Exception) { CommandStatus.COMPLETED }
                    val existingCmd = commandDao.getCommandById(cmdDto.id)
                    if (existingCmd != null && CommandStateMachine.isValidTransition(existingCmd.status, status)) {
                        commandDao.updateCommandStatus(
                            id = cmdDto.id,
                            status = status,
                            completedAt = cmdDto.completedAt ?: now,
                            resultMessage = cmdDto.resultMessage
                        )
                        // If associated with a message and status is COMPLETED, update message to SENT
                        if (status == CommandStatus.COMPLETED && !existingCmd.messageId.isBlank()) {
                            messageDao.updateMessageStatus(existingCmd.messageId, MessageStatus.SENT)
                        }
                    }
                }

                sessionManager.updateLastSyncTime(delta.serverTime)
            }
        } catch (_: Exception) {
            // Live backend might be offline during development, gracefully continue
        }
    }
}
