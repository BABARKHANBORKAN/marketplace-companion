package com.example.data.bot

import android.util.Log
import com.example.data.model.CommandStatus
import com.example.data.model.MessageStatus

object CommandStateMachine {

    private const val TAG = "CommandStateMachine"

    /**
     * Verifies whether transitioning from [current] to [target] is valid according
     * to the strict Command State Machine.
     */
    fun isValidTransition(current: CommandStatus, target: CommandStatus): Boolean {
        if (current == target) return true

        return when (current) {
            CommandStatus.PENDING -> when (target) {
                CommandStatus.PROCESSING -> true
                CommandStatus.CANCELLED -> true
                CommandStatus.FAILED -> true
                CommandStatus.COMPLETED -> false
                else -> false
            }
            CommandStatus.PROCESSING -> when (target) {
                CommandStatus.COMPLETED -> true
                CommandStatus.FAILED -> true
                CommandStatus.CANCELLED -> true
                CommandStatus.PENDING -> true // Allowed only for scheduled retry backoff
                else -> false
            }
            CommandStatus.COMPLETED -> false // Terminal state
            CommandStatus.FAILED -> when (target) {
                CommandStatus.PENDING -> true // Allowed when explicitly queuing a retry
                else -> false
            }
            CommandStatus.CANCELLED -> false // Terminal state
        }
    }

    /**
     * Validates transition and throws [IllegalStateException] if invalid.
     */
    fun assertValidTransition(commandId: String, current: CommandStatus, target: CommandStatus) {
        if (!isValidTransition(current, target)) {
            val error = "Illegal command state transition for command $commandId: $current -> $target"
            Log.e(TAG, error)
            throw IllegalStateException(error)
        }
    }

    /**
     * Verifies whether transitioning from [current] to [target] is valid for Message delivery.
     * Android creates message -> PENDING
     * Backend accepts request -> PROCESSING
     * Bot reports success / confirms delivery -> SENT
     * If Bot fails -> FAILED
     */
    fun isValidMessageTransition(current: MessageStatus, target: MessageStatus): Boolean {
        if (current == target) return true

        return when (current) {
            MessageStatus.PENDING -> when (target) {
                MessageStatus.PROCESSING -> true
                MessageStatus.CANCELLED -> true
                MessageStatus.FAILED -> true
                MessageStatus.SENT -> false // Cannot jump directly from PENDING to SENT without PROCESSING by bot
                else -> false
            }
            MessageStatus.PROCESSING -> when (target) {
                MessageStatus.SENT -> true
                MessageStatus.FAILED -> true
                MessageStatus.CANCELLED -> true
                MessageStatus.PENDING -> true // Queued for retry
                else -> false
            }
            MessageStatus.SENT -> false // Terminal state
            MessageStatus.FAILED -> when (target) {
                MessageStatus.PENDING -> true // Retrying failed message
                else -> false
            }
            MessageStatus.CANCELLED -> false
        }
    }

    fun assertValidMessageTransition(messageId: String, current: MessageStatus, target: MessageStatus) {
        if (!isValidMessageTransition(current, target)) {
            val error = "Illegal message delivery transition for message $messageId: $current -> $target"
            Log.e(TAG, error)
            throw IllegalStateException(error)
        }
    }
}
