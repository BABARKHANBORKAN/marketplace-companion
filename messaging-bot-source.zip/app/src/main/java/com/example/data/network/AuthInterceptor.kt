package com.example.data.network

import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(
    private val tokenProvider: () -> String?,
    private val tokenRefresher: (() -> String?)? = null,
    private val onAuthFailure: (() -> Unit)? = null
) : Interceptor {

    private val lock = Any()

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val builder = original.newBuilder()
            .header("Accept", "application/json")
            .header("User-Agent", "MarketplaceCompanion-Android/1.0")

        val token = tokenProvider()
        if (!token.isNullOrBlank()) {
            builder.header("Authorization", "Bearer $token")
        }

        val initialResponse = chain.proceed(builder.build())

        // If not unauthorized, proceed
        if (initialResponse.code != 401) {
            return initialResponse
        }

        // Avoid infinite loop if the 401 is coming from the auth endpoints themselves
        val path = original.url.encodedPath
        if (path.contains("/auth/login") || path.contains("/auth/refresh") || path.contains("/auth/register")) {
            return initialResponse
        }

        // Close previous response before retrying
        initialResponse.close()

        // Synchronize token refresh across concurrent requests
        val newToken = synchronized(lock) {
            val currentToken = tokenProvider()
            // If token already refreshed by another thread, use that
            if (!currentToken.isNullOrBlank() && currentToken != token) {
                currentToken
            } else {
                tokenRefresher?.invoke()
            }
        }

        return if (!newToken.isNullOrBlank()) {
            val retryRequest = original.newBuilder()
                .header("Accept", "application/json")
                .header("User-Agent", "MarketplaceCompanion-Android/1.0")
                .header("Authorization", "Bearer $newToken")
                .build()
            chain.proceed(retryRequest)
        } else {
            onAuthFailure?.invoke()
            chain.proceed(builder.build())
        }
    }
}
