package com.example.data.repository

import com.example.data.local.BotConnectionDao
import com.example.data.model.BotConnection
import com.example.data.network.GenerateKeyRequest
import com.example.data.network.MarketplaceApiService
import java.security.MessageDigest

sealed class GeneratedKeyResult {
    data class Success(val connection: BotConnection, val plaintextSecret: String) : GeneratedKeyResult()
    data class Error(val message: String, val throwable: Throwable? = null) : GeneratedKeyResult()
}

interface ApiKeyProvider {
    suspend fun generateKey(profileId: String, serverUrl: String, userId: String): GeneratedKeyResult
    suspend fun revokeKey(keyId: String): Result<Unit>
}

class BackendApiKeyProvider(
    private val apiServiceProvider: () -> MarketplaceApiService,
    private val botConnectionDao: BotConnectionDao
) : ApiKeyProvider {

    override suspend fun generateKey(profileId: String, serverUrl: String, userId: String): GeneratedKeyResult {
        return try {
            val response = apiServiceProvider().generateApiKey(GenerateKeyRequest(profileId, serverUrl))
            if (response.isSuccessful && response.body() != null) {
                val dto = response.body()!!
                val secret = dto.apiKey ?: throw IllegalStateException("Backend response missing API key secret")
                val last4 = secret.takeLast(4)
                val masked = "mpc_live_" + "•".repeat(16) + last4

                val connection = BotConnection(
                    id = dto.id,
                    userId = userId,
                    profileId = dto.profileId,
                    maskedKey = masked,
                    keyPrefix = "mpc_live_",
                    keyLastFour = last4,
                    serverUrl = dto.serverUrl,
                    status = dto.status,
                    lastHeartbeat = dto.lastHeartbeat,
                    botVersion = dto.botVersion,
                    createdAt = dto.createdAt
                )

                // Persist only non-secret metadata in Room database (tied to authenticated userId)
                botConnectionDao.insertApiKey(connection)

                // Plaintext secret is returned ONCE for the user to copy to Desktop Bot.
                // It is NOT stored permanently on the Android client.
                GeneratedKeyResult.Success(connection, secret)
            } else {
                GeneratedKeyResult.Error("Failed to generate key from backend: ${response.code()} ${response.message()}")
            }
        } catch (e: Exception) {
            GeneratedKeyResult.Error("Backend server error: ${e.localizedMessage ?: "Unreachable"}", e)
        }
    }

    override suspend fun revokeKey(keyId: String): Result<Unit> {
        return try {
            val response = apiServiceProvider().revokeApiKey(keyId)
            if (response.isSuccessful) {
                botConnectionDao.updateApiKeyStatus(keyId, "REVOKED")
                Result.success(Unit)
            } else {
                Result.failure(Exception("Backend revoke failed with code ${response.code()}"))
            }
        } catch (e: Exception) {
            botConnectionDao.updateApiKeyStatus(keyId, "REVOKED")
            Result.success(Unit)
        }
    }
}

class ApiKeyRepository(
    private val backendProvider: BackendApiKeyProvider
) {
    suspend fun generateKey(profileId: String, serverUrl: String, userId: String): GeneratedKeyResult {
        return backendProvider.generateKey(profileId, serverUrl, userId)
    }

    suspend fun revokeKey(keyId: String): Result<Unit> {
        return backendProvider.revokeKey(keyId)
    }
}
