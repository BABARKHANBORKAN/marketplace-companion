package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AppNotification
import com.example.data.model.AutoReplyRule
import com.example.data.model.BotCommand
import com.example.data.model.BotConnection
import com.example.data.model.ChromeProfile
import com.example.data.model.Conversation
import com.example.data.model.Customer
import com.example.data.model.Listing
import com.example.data.model.Message
import com.example.data.model.User

@Database(
    entities = [
        User::class,
        ChromeProfile::class,
        Customer::class,
        Listing::class,
        Conversation::class,
        Message::class,
        BotCommand::class,
        BotConnection::class,
        AutoReplyRule::class,
        AppNotification::class
    ],
    version = 4,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chromeProfileDao(): ChromeProfileDao
    abstract fun customerDao(): CustomerDao
    abstract fun listingDao(): ListingDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun botCommandDao(): BotCommandDao
    abstract fun botConnectionDao(): BotConnectionDao
    abstract fun autoReplyRuleDao(): AutoReplyRuleDao
    abstract fun notificationDao(): NotificationDao
    abstract fun userDao(): UserDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // 1. Migrate chrome_profiles: add new columns
                db.execSQL("ALTER TABLE chrome_profiles ADD COLUMN lastHeartbeatAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE chrome_profiles ADD COLUMN connectionStatus TEXT NOT NULL DEFAULT 'ONLINE'")
                db.execSQL("ALTER TABLE chrome_profiles ADD COLUMN serverUpdatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE chrome_profiles ADD COLUMN syncStatus TEXT NOT NULL DEFAULT 'CONFIRMED'")

                // 2. Migrate listings: add syncStatus
                db.execSQL("ALTER TABLE listings ADD COLUMN syncStatus TEXT NOT NULL DEFAULT 'CONFIRMED'")

                // 3. Migrate messages: add idempotencyKey
                db.execSQL("ALTER TABLE messages ADD COLUMN idempotencyKey TEXT DEFAULT NULL")

                // 4. Migrate customers: add userId
                db.execSQL("ALTER TABLE customers ADD COLUMN userId TEXT NOT NULL DEFAULT 'user_default'")

                // 5. Migrate bot_commands: recreate table to support all new non-null columns and preserve existing records
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS bot_commands_new (
                        id TEXT NOT NULL PRIMARY KEY,
                        idempotencyKey TEXT NOT NULL DEFAULT '',
                        userId TEXT NOT NULL DEFAULT 'user_default',
                        botId TEXT NOT NULL DEFAULT '',
                        profileId TEXT NOT NULL,
                        type TEXT NOT NULL,
                        conversationId TEXT NOT NULL DEFAULT '',
                        customerId TEXT NOT NULL DEFAULT '',
                        listingId TEXT NOT NULL DEFAULT '',
                        messageId TEXT NOT NULL DEFAULT '',
                        payload TEXT NOT NULL DEFAULT '',
                        status TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL DEFAULT 0,
                        retryCount INTEGER NOT NULL DEFAULT 0,
                        maxRetries INTEGER NOT NULL DEFAULT 5,
                        nextRetryAt INTEGER NOT NULL DEFAULT 0,
                        lastAttemptAt INTEGER NOT NULL DEFAULT 0,
                        errorCode TEXT,
                        errorMessage TEXT,
                        processedAt INTEGER,
                        completedAt INTEGER,
                        resultMessage TEXT
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO bot_commands_new (id, userId, profileId, type, payload, status, createdAt, completedAt, resultMessage)
                    SELECT id, userId, profileId, type, payload, status, createdAt, completedAt, resultMessage FROM bot_commands
                """.trimIndent())
                db.execSQL("DROP TABLE bot_commands")
                db.execSQL("ALTER TABLE bot_commands_new RENAME TO bot_commands")

                // 6. Migrate api_keys: remove plain apiKey, add maskedKey, keyPrefix, keyLastFour
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS api_keys_new (
                        id TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL DEFAULT 'user_default',
                        profileId TEXT NOT NULL,
                        maskedKey TEXT NOT NULL,
                        keyPrefix TEXT NOT NULL DEFAULT 'mpc_live_',
                        keyLastFour TEXT NOT NULL DEFAULT '',
                        apiKeyHash TEXT NOT NULL,
                        serverUrl TEXT NOT NULL,
                        status TEXT NOT NULL,
                        lastHeartbeat INTEGER NOT NULL,
                        botVersion TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                """.trimIndent())
                // For existing rows, safely mask old keys and retain last 4 characters
                db.execSQL("""
                    INSERT INTO api_keys_new (id, userId, profileId, maskedKey, keyPrefix, keyLastFour, apiKeyHash, serverUrl, status, lastHeartbeat, botVersion, createdAt)
                    SELECT id, userId, profileId,
                           'mpc_live_••••••••••••••••' || SUBSTR(apiKey, -4),
                           'mpc_live_',
                           SUBSTR(apiKey, -4),
                           apiKeyHash, serverUrl, status, lastHeartbeat, botVersion, createdAt
                    FROM api_keys
                """.trimIndent())
                db.execSQL("DROP TABLE api_keys")
                db.execSQL("ALTER TABLE api_keys_new RENAME TO api_keys")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Remove apiKeyHash from api_keys table for security compliance
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS api_keys_v3 (
                        id TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL DEFAULT 'user_default',
                        profileId TEXT NOT NULL,
                        maskedKey TEXT NOT NULL,
                        keyPrefix TEXT NOT NULL DEFAULT 'mpc_live_',
                        keyLastFour TEXT NOT NULL DEFAULT '',
                        serverUrl TEXT NOT NULL DEFAULT '',
                        status TEXT NOT NULL,
                        lastHeartbeat INTEGER NOT NULL,
                        botVersion TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT INTO api_keys_v3 (id, userId, profileId, maskedKey, keyPrefix, keyLastFour, serverUrl, status, lastHeartbeat, botVersion, createdAt)
                    SELECT id, userId, profileId, maskedKey, keyPrefix, keyLastFour, serverUrl, status, lastHeartbeat, botVersion, createdAt
                    FROM api_keys
                """.trimIndent())
                db.execSQL("DROP TABLE api_keys")
                db.execSQL("ALTER TABLE api_keys_v3 RENAME TO api_keys")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE chrome_profiles ADD COLUMN manuallyDisconnected INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "marketplace_companion.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
