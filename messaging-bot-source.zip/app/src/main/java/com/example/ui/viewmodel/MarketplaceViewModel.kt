package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.AutoReplyRule
import com.example.data.model.BotCommand
import com.example.data.model.BotConnection
import com.example.data.model.ChromeProfile
import com.example.data.model.ConversationWithDetails
import com.example.data.model.Listing
import com.example.data.model.Message
import com.example.data.model.ProfileStatus
import com.example.data.model.User
import com.example.data.preferences.AuthSession
import com.example.data.preferences.UserSessionManager
import com.example.data.repository.GeneratedKeyResult
import com.example.data.repository.MarketplaceRepository
import com.example.data.security.SecureCredentialStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MarketplaceViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val sessionManager = UserSessionManager(application)
    private val secureCredentialStore = SecureCredentialStore(application)
    private val repository = MarketplaceRepository(
        database = database,
        scope = viewModelScope,
        sessionManager = sessionManager,
        context = application
    )

    val authSession: StateFlow<AuthSession> = sessionManager.sessionFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AuthSession())

    val allProfiles: StateFlow<List<ChromeProfile>> = repository.allProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allListings: StateFlow<List<Listing>> = repository.allListings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allConversations: StateFlow<List<ConversationWithDetails>> = repository.conversationsWithDetails
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCommands: StateFlow<List<BotCommand>> = repository.allCommands
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allApiKeys: StateFlow<List<BotConnection>> = repository.allApiKeys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAutoReplies: StateFlow<List<AutoReplyRule>> = repository.allAutoReplies
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val currentUser: StateFlow<User?> = repository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val webSocketState: StateFlow<com.example.data.network.WebSocketState> =
        (repository.webSocketState ?: kotlinx.coroutines.flow.flowOf(com.example.data.network.WebSocketState.DISCONNECTED))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.example.data.network.WebSocketState.DISCONNECTED)

    fun reconnectWebSocket() {
        repository.reconnectWebSocket()
    }

    // Inbox Filter States
    private val _inboxSearchQuery = MutableStateFlow("")
    val inboxSearchQuery = _inboxSearchQuery.asStateFlow()

    private val _unreadOnlyFilter = MutableStateFlow(false)
    val unreadOnlyFilter = _unreadOnlyFilter.asStateFlow()

    private val _profileFilter = MutableStateFlow<String?>(null)
    val profileFilter = _profileFilter.asStateFlow()

    private val _listingFilter = MutableStateFlow<String?>(null)
    val listingFilter = _listingFilter.asStateFlow()

    val filteredConversations: StateFlow<List<ConversationWithDetails>> = combine(
        allConversations,
        _inboxSearchQuery,
        _unreadOnlyFilter,
        _profileFilter,
        _listingFilter
    ) { convs, query, unreadOnly, profileId, listId ->
        convs.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.customer.name.contains(query, ignoreCase = true) ||
                    item.listing.title.contains(query, ignoreCase = true) ||
                    item.conversation.lastMessage.contains(query, ignoreCase = true)

            val matchesUnread = !unreadOnly || item.conversation.unreadCount > 0
            val matchesProfile = profileId == null || item.profile.id == profileId
            val matchesListing = listId == null || item.listing.id == listId

            matchesQuery && matchesUnread && matchesProfile && matchesListing
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Chat State
    private val _selectedConversationId = MutableStateFlow<String?>(null)
    val selectedConversationId = _selectedConversationId.asStateFlow()

    private val _activeChatMessages = MutableStateFlow<List<Message>>(emptyList())
    val activeChatMessages = _activeChatMessages.asStateFlow()

    fun selectConversation(conversationId: String) {
        _selectedConversationId.value = conversationId
        viewModelScope.launch {
            repository.markConversationRead(conversationId)
            repository.getMessagesForConversation(conversationId).collect { msgs ->
                _activeChatMessages.value = msgs
            }
        }
    }

    fun setInboxSearchQuery(query: String) {
        _inboxSearchQuery.value = query
    }

    fun toggleUnreadFilter() {
        _unreadOnlyFilter.value = !_unreadOnlyFilter.value
    }

    fun setProfileFilter(profileId: String?) {
        _profileFilter.value = profileId
    }

    fun setListingFilter(listingId: String?) {
        _listingFilter.value = listingId
    }

    // Actions
    fun reopenChromeProfile(profileId: String) {
        viewModelScope.launch {
            repository.reopenChromeProfile(profileId)
        }
    }

    fun stopCurrentTask(profileId: String) {
        viewModelScope.launch {
            repository.stopCurrentTask(profileId)
        }
    }

    fun openCustomerChatInChrome(profileId: String, conversationId: String) {
        viewModelScope.launch {
            repository.openCustomerChatInChrome(profileId, conversationId)
        }
    }

    fun sendMessage(
        conversationId: String,
        text: String,
        stopTaskFirst: Boolean = false,
        reopenChromeFirst: Boolean = false
    ) {
        viewModelScope.launch {
            repository.sendMessage(conversationId, text, stopTaskFirst, reopenChromeFirst)
        }
    }

    fun generateApiKey(
        profileId: String,
        serverUrl: String,
        onResult: ((Boolean, String, String?) -> Unit)? = null
    ) {
        viewModelScope.launch {
            when (val res = repository.generateApiKey(profileId, serverUrl)) {
                is GeneratedKeyResult.Success -> {
                    // Keeps the full secret recoverable for later "copy" taps, encrypted via
                    // Android Keystore — separate from the Room DB, which only ever holds the
                    // hash + masked prefix (see ApiKeyScreen's "Zero Plaintext Key Storage" card).
                    secureCredentialStore.saveGeneratedSecret(res.connection.id, res.plaintextSecret)
                    onResult?.invoke(true, "Key generated", res.plaintextSecret)
                }
                is GeneratedKeyResult.Error -> {
                    onResult?.invoke(false, res.message, null)
                }
            }
        }
    }

    /** The full plaintext key if still recoverable from the encrypted local store, else null. */
    fun getFullApiKey(id: String): String? = secureCredentialStore.getSecret(id)

    fun revokeApiKey(id: String) {
        viewModelScope.launch {
            repository.revokeApiKey(id)
            secureCredentialStore.removeSecret(id)
        }
    }

    fun deleteApiKey(id: String) {
        viewModelScope.launch {
            repository.deleteApiKey(id)
            secureCredentialStore.removeSecret(id)
        }
    }

    fun createProfile(name: String, accountLabel: String) {
        viewModelScope.launch {
            repository.createProfile(name, accountLabel)
        }
    }

    fun updateProfileStatus(id: String, status: ProfileStatus, task: String) {
        viewModelScope.launch {
            repository.updateProfileStatus(id, status, task)
        }
    }

    fun disconnectProfile(id: String) {
        viewModelScope.launch {
            repository.disconnectProfile(id)
        }
    }

    fun connectProfile(id: String) {
        viewModelScope.launch {
            repository.connectProfile(id)
        }
    }

    fun deleteProfile(id: String) {
        viewModelScope.launch {
            repository.deleteProfile(id)
        }
    }

    fun createListing(title: String, price: Double, category: String, description: String, profileId: String) {
        viewModelScope.launch {
            repository.createListing(title, price, category, description, profileId)
        }
    }

    fun createAutoReplyRule(trigger: String, reply: String) {
        viewModelScope.launch {
            repository.createAutoReplyRule(trigger, reply)
        }
    }

    fun toggleAutoReplyRule(id: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleAutoReplyRule(id, enabled)
        }
    }

    fun deleteAutoReplyRule(id: String) {
        viewModelScope.launch {
            repository.deleteAutoReplyRule(id)
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun clearNotifications() {
        viewModelScope.launch {
            repository.clearNotifications()
        }
    }

    fun updateProfileNameAndEmail(name: String, email: String) {
        viewModelScope.launch {
            repository.updateUserName(name, email)
        }
    }

    fun login(email: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.login(email, pass)
            if (res.isSuccess) {
                onResult(true, res.getOrNull() ?: "Success")
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Login failed")
            }
        }
    }

    fun loginWithAppsCode(code: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.loginWithAppsCode(code)
            if (res.isSuccess) {
                onResult(true, res.getOrNull() ?: "Success")
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Login failed")
            }
        }
    }

    fun register(name: String, email: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.register(name, email, pass)
            if (res.isSuccess) {
                onResult(true, res.getOrNull() ?: "Success")
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Registration failed")
            }
        }
    }

    fun forgotPassword(email: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.forgotPassword(email)
            if (res.isSuccess) {
                onResult(true, res.getOrNull() ?: "Instructions sent")
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Failed")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    fun updateServerUrl(url: String) {
        viewModelScope.launch {
            repository.updateServerUrl(url)
        }
    }
}
