package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MessageStatus
import com.example.data.model.ProfileStatus
import com.example.ui.theme.StatusBusyYellow
import com.example.ui.theme.StatusBusyYellowContainer
import com.example.ui.theme.StatusOfflineRed
import com.example.ui.theme.StatusOfflineRedContainer
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.theme.StatusOnlineGreenContainer

@Composable
fun ProfileStatusDot(
    status: ProfileStatus,
    size: Dp = 10.dp,
    modifier: Modifier = Modifier
) {
    val color = when (status) {
        ProfileStatus.ONLINE -> StatusOnlineGreen
        ProfileStatus.BUSY -> StatusBusyYellow
        ProfileStatus.OFFLINE -> StatusOfflineRed
    }
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(color)
            .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
    )
}

@Composable
fun ProfileStatusChip(
    status: ProfileStatus,
    currentTask: String? = null,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when (status) {
        ProfileStatus.ONLINE -> Triple(StatusOnlineGreenContainer, StatusOnlineGreen, "Online")
        ProfileStatus.BUSY -> Triple(StatusBusyYellowContainer, StatusBusyYellow, "Busy")
        ProfileStatus.OFFLINE -> Triple(StatusOfflineRedContainer, StatusOfflineRed, "Offline")
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(textColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = if (status == ProfileStatus.BUSY && !currentTask.isNullOrBlank()) {
                "Busy: $currentTask"
            } else {
                label
            },
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun MessageStatusIndicator(
    status: MessageStatus,
    modifier: Modifier = Modifier
) {
    when (status) {
        MessageStatus.PENDING -> {
            Icon(
                imageVector = Icons.Default.AccessTime,
                contentDescription = "Pending",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = modifier.size(14.dp)
            )
        }
        MessageStatus.PROCESSING -> {
            Icon(
                imageVector = Icons.Default.Sync,
                contentDescription = "Processing via Bot",
                tint = MaterialTheme.colorScheme.primary,
                modifier = modifier.size(14.dp)
            )
        }
        MessageStatus.SENT -> {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = "Sent",
                tint = MaterialTheme.colorScheme.primary,
                modifier = modifier.size(14.dp)
            )
        }
        MessageStatus.FAILED -> {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = "Failed",
                tint = StatusOfflineRed,
                modifier = modifier.size(14.dp)
            )
        }
        MessageStatus.CANCELLED -> {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Cancelled",
                tint = MaterialTheme.colorScheme.outline,
                modifier = modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun UserAvatar(
    initials: String,
    backgroundColor: Color,
    size: Dp = 44.dp,
    status: ProfileStatus? = null,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.size(size)) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(backgroundColor)
        ) {
            Text(
                text = initials.take(2).uppercase(),
                color = Color.White,
                fontSize = (size.value * 0.38f).sp,
                fontWeight = FontWeight.Bold
            )
        }

        if (status != null) {
            ProfileStatusDot(
                status = status,
                size = size * 0.32f,
                modifier = Modifier.align(Alignment.BottomEnd)
            )
        }
    }
}
