package com.example.ui.profiles

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BotCommand
import com.example.data.model.CommandStatus
import com.example.data.model.CommandType
import com.example.data.model.ProfileStatus
import com.example.ui.components.ProfileStatusChip
import com.example.ui.theme.FbBlue
import com.example.ui.theme.StatusBusyYellow
import com.example.ui.theme.StatusOfflineRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.viewmodel.MarketplaceViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileDetailScreen(
    profileId: String,
    viewModel: MarketplaceViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToApiKeys: () -> Unit
) {
    val profiles by viewModel.allProfiles.collectAsState()
    val profile = profiles.firstOrNull { it.id == profileId }
    val commands by viewModel.allCommands.collectAsState()
    val profileCommands = commands.filter { it.profileId == profileId }
    val isReopenInFlight = profileCommands.any {
        it.type == CommandType.REOPEN_CHROME_PROFILE &&
            (it.status == CommandStatus.PENDING || it.status == CommandStatus.PROCESSING)
    }
    val apiKeys by viewModel.allApiKeys.collectAsState()
    val apiKey = apiKeys.firstOrNull { it.profileId == profileId }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Text(
                        text = profile?.name ?: "Profile Details",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        if (profile == null) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Text("Profile not found.")
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(
                    top = innerPadding.calculateTopPadding() + 16.dp,
                    bottom = innerPadding.calculateBottomPadding() + 24.dp,
                    start = 16.dp,
                    end = 16.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("profile_detail_screen")
            ) {
                // Identity & Status Card
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text(
                                        text = profile.id,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = profile.accountLabel,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                ProfileStatusChip(status = profile.status, currentTask = profile.currentTask)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Window Name: ${profile.chromeWindowName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            val heartbeatFormatted = remember(profile.lastHeartbeat) {
                                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(profile.lastHeartbeat))
                            }
                            Text(
                                text = "Last Heartbeat: $heartbeatFormatted",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.reopenChromeProfile(profile.id) },
                                    enabled = !isReopenInFlight,
                                    colors = ButtonDefaults.buttonColors(containerColor = FbBlue),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isReopenInFlight) "Reopening…" else "Reopen Chrome")
                                }

                                if (profile.status == ProfileStatus.BUSY) {
                                    Button(
                                        onClick = { viewModel.stopCurrentTask(profile.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusBusyYellow),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.StopCircle, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Stop Task", color = Color.Black)
                                    }
                                }
                            }
                        }
                    }
                }

                // Desktop Bot Connection Details Card
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.DesktopWindows,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Desktop Bot Connection",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                TextButton(onClick = onNavigateToApiKeys) {
                                    Text("Manage Keys")
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            if (apiKey != null) {
                                Text(
                                    text = "Bot Version: ${apiKey.botVersion}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "API Key: ${apiKey.maskedKey}",
                                    fontFamily = FontFamily.Monospace,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = "Server: ${apiKey.serverUrl}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Text(
                                    text = "No dedicated API key assigned to this profile yet.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(onClick = onNavigateToApiKeys) {
                                    Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Generate Bot API Key")
                                }
                            }
                        }
                    }
                }

                // Command Queue & Execution Log
                item {
                    Text(
                        text = "Bot Command Execution History (${profileCommands.size})",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                if (profileCommands.isEmpty()) {
                    item {
                        Text(
                            text = "No commands queued for this profile yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(profileCommands, key = { it.id }) { cmd ->
                        CommandQueueItem(command = cmd)
                    }
                }
            }
        }
    }
}

@Composable
fun CommandQueueItem(command: BotCommand) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (command.status) {
                            CommandStatus.COMPLETED -> Icons.Default.CheckCircle
                            CommandStatus.PROCESSING -> Icons.Default.Refresh
                            CommandStatus.PENDING -> Icons.Default.HourglassBottom
                            else -> Icons.Default.Terminal
                        },
                        contentDescription = null,
                        tint = when (command.status) {
                            CommandStatus.COMPLETED -> StatusOnlineGreen
                            CommandStatus.PROCESSING -> FbBlue
                            CommandStatus.PENDING -> StatusBusyYellow
                            else -> StatusOfflineRed
                        },
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = command.type.name,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (command.status) {
                        CommandStatus.COMPLETED -> StatusOnlineGreen.copy(alpha = 0.15f)
                        CommandStatus.PROCESSING -> FbBlue.copy(alpha = 0.15f)
                        CommandStatus.PENDING -> StatusBusyYellow.copy(alpha = 0.15f)
                        else -> StatusOfflineRed.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = command.status.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (command.status) {
                            CommandStatus.COMPLETED -> StatusOnlineGreen
                            CommandStatus.PROCESSING -> FbBlue
                            CommandStatus.PENDING -> Color(0xFFB45309)
                            else -> StatusOfflineRed
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (!command.resultMessage.isNullOrBlank()) {
                Text(
                    text = command.resultMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = "Payload: ${command.payload}",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                maxLines = 2
            )
        }
    }
}
