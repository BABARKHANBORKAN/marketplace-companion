package com.example.ui.navigation

object NavRoutes {
    const val SPLASH = "splash"
    const val DASHBOARD = "dashboard"
    const val INBOX = "inbox"
    const val LISTINGS = "listings"
    const val PROFILES = "profiles"
    const val SETTINGS = "settings"

    const val CHAT = "chat/{conversationId}"
    fun chatRoute(conversationId: String) = "chat/$conversationId"

    const val PROFILE_DETAILS = "profile_details/{profileId}"
    fun profileDetailsRoute(profileId: String) = "profile_details/$profileId"

    const val LISTING_DETAILS = "listing_details/{listingId}"
    fun listingDetailsRoute(listingId: String) = "listing_details/$listingId"

    const val API_KEYS = "api_keys"
    const val API_KEYS_PATTERN = "api_keys?targetProfileId={targetProfileId}"
    fun apiKeysRoute(targetProfileId: String? = null): String =
        if (targetProfileId != null) "api_keys?targetProfileId=$targetProfileId" else API_KEYS
    const val AUTO_REPLIES = "auto_replies"
    const val NOTIFICATIONS = "notifications"
    const val SUBSCRIPTION = "subscription"
    const val SECURITY = "security"
    const val ACCOUNT = "account"
    const val ABOUT = "about"
    const val AUTH = "auth"
    const val FORGOT_PASSWORD = "forgot_password"
}
