package com.example.ui.profiles

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChromeProfile
import com.example.data.model.ProfileStatus
import com.example.ui.components.ProfileStatusChip
import com.example.ui.theme.FbBlue
import com.example.ui.theme.StatusBusyYellow
import com.example.ui.theme.StatusOfflineRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.viewmodel.MarketplaceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesScreen(
    viewModel: MarketplaceViewModel,
    onNavigateToProfileDetails: (String) -> Unit,
    onNavigateToInboxWithFilter: (String) -> Unit,
    onNavigateToListingsWithFilter: (String) -> Unit
) {
    val profiles by viewModel.allProfiles.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Chrome & Bot Profiles",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${profiles.size} configured Desktop browser instances",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = FbBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_profile_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Chrome Profile")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 16.dp,
                bottom = innerPadding.calculateBottomPadding() + 80.dp,
                start = 16.dp,
                end = 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("profiles_screen")
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Profile Status Protocol",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(StatusOnlineGreen))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("GREEN = Online & Idle", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(14.dp))
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(StatusBusyYellow))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("YELLOW = Busy", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(14.dp))
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(StatusOfflineRed))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RED = Offline", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            items(profiles, key = { it.id }) { profile ->
                ChromeProfileCard(
                    profile = profile,
                    onOpenProfileDetails = { onNavigateToProfileDetails(profile.id) },
                    onReopenChrome = { viewModel.reopenChromeProfile(profile.id) },
                    onStopTask = { viewModel.stopCurrentTask(profile.id) },
                    onViewConversations = { onNavigateToInboxWithFilter(profile.id) },
                    onViewListings = { onNavigateToListingsWithFilter(profile.id) },
                    onDisconnect = { viewModel.disconnectProfile(profile.id) },
                    onConnect = { viewModel.connectProfile(profile.id) },
                    onDeleteProfile = { viewModel.deleteProfile(profile.id) }
                )
            }
        }
    }

    if (showAddDialog) {
        var profileName by remember { mutableStateOf("") }
        var accountLabel by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Chrome / Bot Profile") },
            text = {
                Column {
                    Text(
                        text = "Assign a designated Chrome profile on the Desktop Bot host for isolated Marketplace sessions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = profileName,
                        onValueChange = { profileName = it },
                        label = { Text("Profile Name (e.g. Sales Chrome 4)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = accountLabel,
                        onValueChange = { accountLabel = it },
                        label = { Text("Facebook Account Label") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (profileName.isNotBlank()) {
                            viewModel.createProfile(
                                name = profileName.trim(),
                                accountLabel = accountLabel.ifBlank { "Personal Marketplace" }.trim()
                            )
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FbBlue)
                ) {
                    Text("Add Profile")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChromeProfileCard(
    profile: ChromeProfile,
    onOpenProfileDetails: () -> Unit,
    onReopenChrome: () -> Unit,
    onStopTask: () -> Unit,
    onViewConversations: () -> Unit,
    onViewListings: () -> Unit,
    onDisconnect: () -> Unit,
    onConnect: () -> Unit,
    onDeleteProfile: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onOpenProfileDetails,
                onLongClick = { showMenu = true }
            )
            .testTag("profile_card_${profile.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                when (profile.status) {
                                    ProfileStatus.ONLINE -> StatusOnlineGreen.copy(alpha = 0.15f)
                                    ProfileStatus.BUSY -> StatusBusyYellow.copy(alpha = 0.15f)
                                    ProfileStatus.OFFLINE -> StatusOfflineRed.copy(alpha = 0.15f)
                                }
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.DesktopWindows,
                            contentDescription = null,
                            tint = when (profile.status) {
                                ProfileStatus.ONLINE -> StatusOnlineGreen
                                ProfileStatus.BUSY -> StatusBusyYellow
                                ProfileStatus.OFFLINE -> StatusOfflineRed
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = profile.id,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${profile.name} • ${profile.accountLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (profile.manuallyDisconnected) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StatusOfflineRed.copy(alpha = 0.15f),
                            modifier = Modifier.testTag("disconnected_badge_${profile.id}")
                        ) {
                            Text(
                                text = "Disconnected",
                                color = StatusOfflineRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Profile Options")
                    }

                    // Three-dot menu implementing section 10 & 11
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        if (profile.status == ProfileStatus.OFFLINE) {
                            DropdownMenuItem(
                                text = { Text("Reopen Chrome") },
                                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = StatusOfflineRed) },
                                onClick = {
                                    onReopenChrome()
                                    showMenu = false
                                }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Open Profile") },
                                leadingIcon = { Icon(Icons.Default.OpenInBrowser, contentDescription = null) },
                                onClick = {
                                    onOpenProfileDetails()
                                    showMenu = false
                                }
                            )
                            if (profile.status == ProfileStatus.BUSY) {
                                DropdownMenuItem(
                                    text = { Text("Stop Current Task") },
                                    leadingIcon = { Icon(Icons.Default.StopCircle, contentDescription = null, tint = StatusBusyYellow) },
                                    onClick = {
                                        onStopTask()
                                        showMenu = false
                                    }
                                )
                            }
                        }

                        DropdownMenuItem(
                            text = { Text("View Conversations (${profile.conversationCount})") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null) },
                            onClick = {
                                onViewConversations()
                                showMenu = false
                            }
                        )

                        DropdownMenuItem(
                            text = { Text("View Listings (${profile.listingCount})") },
                            leadingIcon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
                            onClick = {
                                onViewListings()
                                showMenu = false
                            }
                        )

                        DropdownMenuItem(
                            text = { Text("Profile Details") },
                            leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                            onClick = {
                                onOpenProfileDetails()
                                showMenu = false
                            }
                        )

                        if (profile.manuallyDisconnected) {
                            DropdownMenuItem(
                                text = { Text("Connect") },
                                leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                                onClick = {
                                    onConnect()
                                    showMenu = false
                                }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Disconnect") },
                                leadingIcon = { Icon(Icons.Default.LinkOff, contentDescription = null) },
                                onClick = {
                                    onDisconnect()
                                    showMenu = false
                                }
                            )
                        }

                        DropdownMenuItem(
                            text = { Text("Delete Profile", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                showMenu = false
                                showDeleteConfirm = true
                            }
                        )
                    }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Status chip & current activity
            ProfileStatusChip(status = profile.status, currentTask = profile.currentTask)

            Spacer(modifier = Modifier.height(12.dp))

            // Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Listings", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${profile.listingCount}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Chats", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${profile.conversationCount}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Unread", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${profile.unreadCount}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Profile?") },
            text = {
                Text(
                    "This permanently deletes \"${profile.name}\" and all of its local data. " +
                        "This cannot be undone."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteProfile()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
