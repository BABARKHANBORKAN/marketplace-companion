package com.example.ui

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.auth.AuthScreen
import com.example.ui.chat.ChatScreen
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.inbox.InboxScreen
import com.example.ui.listings.ListingDetailScreen
import com.example.ui.listings.ListingsScreen
import com.example.ui.navigation.NavRoutes
import com.example.ui.notifications.NotificationsScreen
import com.example.ui.profiles.ProfileDetailScreen
import com.example.ui.profiles.ProfilesScreen
import com.example.ui.settings.AboutScreen
import com.example.ui.settings.AccountScreen
import com.example.ui.settings.ApiKeyScreen
import com.example.ui.settings.AutoRepliesScreen
import com.example.ui.settings.SecurityScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SubscriptionScreen
import com.example.ui.splash.SplashScreen
import com.example.ui.theme.FbBlue
import com.example.ui.viewmodel.MarketplaceViewModel

sealed class BottomNavItem(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : BottomNavItem(NavRoutes.DASHBOARD, "Dashboard", Icons.Default.Dashboard)
    object Inbox : BottomNavItem(NavRoutes.INBOX, "Inbox", Icons.AutoMirrored.Filled.Chat)
    object Listings : BottomNavItem(NavRoutes.LISTINGS, "Listings", Icons.Default.ShoppingBag)
    object Profiles : BottomNavItem(NavRoutes.PROFILES, "Profiles", Icons.Default.DesktopWindows)
    object Settings : BottomNavItem(NavRoutes.SETTINGS, "Settings", Icons.Default.Settings)
}

@Composable
fun MainApp(
    viewModel: MarketplaceViewModel = viewModel()
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val conversations by viewModel.allConversations.collectAsState()
    val totalUnreadMessages = conversations.sumOf { it.conversation.unreadCount }

    val bottomNavItems = listOf(
        BottomNavItem.Dashboard,
        BottomNavItem.Inbox,
        BottomNavItem.Listings,
        BottomNavItem.Profiles,
        BottomNavItem.Settings
    )

    val showBottomBar = currentRoute in listOf(
        NavRoutes.DASHBOARD,
        NavRoutes.INBOX,
        NavRoutes.LISTINGS,
        NavRoutes.PROFILES,
        NavRoutes.SETTINGS
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    bottomNavItems.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                if (item == BottomNavItem.Inbox && totalUnreadMessages > 0) {
                                    BadgedBox(
                                        badge = {
                                            Badge { Text("$totalUnreadMessages") }
                                        }
                                    ) {
                                        Icon(item.icon, contentDescription = item.title)
                                    }
                                } else {
                                    Icon(item.icon, contentDescription = item.title)
                                }
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier.testTag("nav_item_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavRoutes.SPLASH,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            enterTransition = { EnterTransition.None },
            exitTransition = { ExitTransition.None }
        ) {
            // Splash / Session Router
            composable(NavRoutes.SPLASH) {
                SplashScreen(
                    viewModel = viewModel,
                    onNavigateToDashboard = {
                        navController.navigate(NavRoutes.DASHBOARD) {
                            popUpTo(NavRoutes.SPLASH) { inclusive = true }
                        }
                    },
                    onNavigateToAuth = {
                        navController.navigate(NavRoutes.AUTH) {
                            popUpTo(NavRoutes.SPLASH) { inclusive = true }
                        }
                    }
                )
            }

            composable(NavRoutes.DASHBOARD) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToInbox = { navController.navigate(NavRoutes.INBOX) },
                    onNavigateToProfiles = { navController.navigate(NavRoutes.PROFILES) },
                    onNavigateToListings = { navController.navigate(NavRoutes.LISTINGS) },
                    onNavigateToApiKeys = { navController.navigate(NavRoutes.API_KEYS) },
                    onNavigateToNotifications = { navController.navigate(NavRoutes.NOTIFICATIONS) },
                    onNavigateToChat = { convId -> navController.navigate(NavRoutes.chatRoute(convId)) }
                )
            }

            composable(NavRoutes.INBOX) {
                InboxScreen(
                    viewModel = viewModel,
                    onNavigateToChat = { convId -> navController.navigate(NavRoutes.chatRoute(convId)) }
                )
            }

            composable(NavRoutes.LISTINGS) {
                ListingsScreen(
                    viewModel = viewModel,
                    onNavigateToListingDetails = { listingId ->
                        navController.navigate(NavRoutes.listingDetailsRoute(listingId))
                    }
                )
            }

            composable(NavRoutes.PROFILES) {
                ProfilesScreen(
                    viewModel = viewModel,
                    onNavigateToProfileDetails = { profileId ->
                        navController.navigate(NavRoutes.profileDetailsRoute(profileId))
                    },
                    onNavigateToInboxWithFilter = { profileId ->
                        viewModel.setProfileFilter(profileId)
                        navController.navigate(NavRoutes.INBOX)
                    },
                    onNavigateToListingsWithFilter = { profileId ->
                        viewModel.setProfileFilter(profileId)
                        navController.navigate(NavRoutes.LISTINGS)
                    }
                )
            }

            composable(NavRoutes.SETTINGS) {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToAccount = { navController.navigate(NavRoutes.ACCOUNT) },
                    onNavigateToApiKeys = { navController.navigate(NavRoutes.API_KEYS) },
                    onNavigateToAutoReplies = { navController.navigate(NavRoutes.AUTO_REPLIES) },
                    onNavigateToSubscription = { navController.navigate(NavRoutes.SUBSCRIPTION) },
                    onNavigateToSecurity = { navController.navigate(NavRoutes.SECURITY) },
                    onNavigateToAbout = { navController.navigate(NavRoutes.ABOUT) },
                    onNavigateToAuth = { navController.navigate(NavRoutes.AUTH) }
                )
            }

            // Detailed and Modal Routes
            composable(
                route = NavRoutes.CHAT,
                arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
            ) { backStackEntry ->
                val convId = backStackEntry.arguments?.getString("conversationId") ?: ""
                ChatScreen(
                    conversationId = convId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToProfileDetails = { profileId ->
                        navController.navigate(NavRoutes.profileDetailsRoute(profileId))
                    },
                    onNavigateToListingDetails = { listingId ->
                        navController.navigate(NavRoutes.listingDetailsRoute(listingId))
                    }
                )
            }

            composable(
                route = NavRoutes.PROFILE_DETAILS,
                arguments = listOf(navArgument("profileId") { type = NavType.StringType })
            ) { backStackEntry ->
                val profileId = backStackEntry.arguments?.getString("profileId") ?: ""
                ProfileDetailScreen(
                    profileId = profileId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToApiKeys = { navController.navigate(NavRoutes.apiKeysRoute(profileId)) }
                )
            }

            composable(
                route = NavRoutes.LISTING_DETAILS,
                arguments = listOf(navArgument("listingId") { type = NavType.StringType })
            ) { backStackEntry ->
                val listingId = backStackEntry.arguments?.getString("listingId") ?: ""
                ListingDetailScreen(
                    listingId = listingId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToChat = { convId ->
                        navController.navigate(NavRoutes.chatRoute(convId))
                    }
                )
            }

            composable(
                route = NavRoutes.API_KEYS_PATTERN,
                arguments = listOf(navArgument("targetProfileId") { type = NavType.StringType; nullable = true; defaultValue = null })
            ) { backStackEntry ->
                val targetProfileId = backStackEntry.arguments?.getString("targetProfileId")
                ApiKeyScreen(
                    viewModel = viewModel,
                    targetProfileId = targetProfileId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.AUTO_REPLIES) {
                AutoRepliesScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.NOTIFICATIONS) {
                NotificationsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToChat = { convId -> navController.navigate(NavRoutes.chatRoute(convId)) },
                    onNavigateToProfiles = { navController.navigate(NavRoutes.PROFILES) }
                )
            }

            composable(NavRoutes.ACCOUNT) {
                AccountScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onLogout = {
                        navController.navigate(NavRoutes.AUTH) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                )
            }

            composable(NavRoutes.SUBSCRIPTION) {
                SubscriptionScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.SECURITY) {
                SecurityScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.ABOUT) {
                AboutScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.AUTH) {
                AuthScreen(
                    viewModel = viewModel,
                    onAuthSuccess = {
                        navController.navigate(NavRoutes.DASHBOARD) {
                            popUpTo(NavRoutes.AUTH) { inclusive = true }
                        }
                    },
                    onNavigateBack = if (navController.previousBackStackEntry != null) {
                        { navController.popBackStack() }
                    } else null
                )
            }
        }
    }
}
