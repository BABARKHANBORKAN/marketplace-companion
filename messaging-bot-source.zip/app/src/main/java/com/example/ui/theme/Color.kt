package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val FbBlue = Color(0xFF1877F2)
val FbBlueDark = Color(0xFF0D5FCE)
val FbBlueLight = Color(0xFFE7F3FF)

// Status Colors
val StatusOnlineGreen = Color(0xFF10B981)
val StatusOnlineGreenContainer = Color(0xFFD1FAE5)
val StatusBusyYellow = Color(0xFFF59E0B)
val StatusBusyYellowContainer = Color(0xFFFEF3C7)
val StatusOfflineRed = Color(0xFFEF4444)
val StatusOfflineRedContainer = Color(0xFFFEE2E2)

// Dark Theme Surfaces
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
