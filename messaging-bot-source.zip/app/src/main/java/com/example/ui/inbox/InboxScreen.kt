package com.example.ui.inbox

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConversationWithDetails
import com.example.data.model.ProfileStatus
import com.example.ui.components.ProfileStatusDot
import com.example.ui.components.UserAvatar
import com.example.ui.theme.FbBlue
import com.example.ui.theme.StatusBusyYellow
import com.example.ui.theme.StatusOfflineRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.viewmodel.MarketplaceViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    viewModel: MarketplaceViewModel,
    onNavigateToChat: (String) -> Unit
) {
    val conversations by viewModel.filteredConversations.collectAsState()
    val allProfiles by viewModel.allProfiles.collectAsState()
    val allListings by viewModel.allListings.collectAsState()
    val searchQuery by viewModel.inboxSearchQuery.collectAsState()
    val unreadOnly by viewModel.unreadOnlyFilter.collectAsState()
    val selectedProfileId by viewModel.profileFilter.collectAsState()
    val selectedListingId by viewModel.listingFilter.collectAsState()
    val wsState by viewModel.webSocketState.collectAsState()

    var showProfileDropdown by remember { mutableStateOf(false) }
    var showListingDropdown by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Marketplace Inbox",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${conversations.size} active customer inquiries",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    val (statusColor, statusText) = when (wsState) {
                        com.example.data.network.WebSocketState.CONNECTED -> StatusOnlineGreen to "Live"
                        com.example.data.network.WebSocketState.CONNECTING -> StatusBusyYellow to "Connecting"
                        com.example.data.network.WebSocketState.RECONNECTING -> StatusBusyYellow to "Reconnecting"
                        com.example.data.network.WebSocketState.FAILED -> StatusOfflineRed to "Failed"
                        com.example.data.network.WebSocketState.DISCONNECTED -> MaterialTheme.colorScheme.outline to "Offline"
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = statusColor.copy(alpha = 0.12f),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable {
                                if (wsState != com.example.data.network.WebSocketState.CONNECTED) {
                                    viewModel.reconnectWebSocket()
                                }
                            }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = statusText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = statusColor
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("inbox_screen")
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setInboxSearchQuery(it) },
                placeholder = { Text("Search customers, listings, messages...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setInboxSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("inbox_search_field")
            )

            // Horizontal Filter Chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = !unreadOnly && selectedProfileId == null && selectedListingId == null,
                        onClick = {
                            if (unreadOnly) viewModel.toggleUnreadFilter()
                            viewModel.setProfileFilter(null)
                            viewModel.setListingFilter(null)
                        },
                        label = { Text("All") }
                    )
                }

                item {
                    FilterChip(
                        selected = unreadOnly,
                        onClick = { viewModel.toggleUnreadFilter() },
                        label = { Text("Unread Only") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FbBlue.copy(alpha = 0.15f),
                            selectedLabelColor = FbBlue
                        )
                    )
                }

                // Profile Filter
                item {
                    Box {
                        FilterChip(
                            selected = selectedProfileId != null,
                            onClick = { showProfileDropdown = true },
                            label = {
                                Text(
                                    text = if (selectedProfileId != null) "Profile: $selectedProfileId" else "All Profiles"
                                )
                            },
                            trailingIcon = {
                                if (selectedProfileId != null) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear Profile Filter",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable { viewModel.setProfileFilter(null) }
                                    )
                                }
                            }
                        )

                        DropdownMenu(
                            expanded = showProfileDropdown,
                            onDismissRequest = { showProfileDropdown = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Chrome Profiles") },
                                onClick = {
                                    viewModel.setProfileFilter(null)
                                    showProfileDropdown = false
                                }
                            )
                            allProfiles.forEach { profile ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            ProfileStatusDot(profile.status, size = 8.dp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("${profile.id} (${profile.name})")
                                        }
                                    },
                                    onClick = {
                                        viewModel.setProfileFilter(profile.id)
                                        showProfileDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Listing Filter
                item {
                    Box {
                        FilterChip(
                            selected = selectedListingId != null,
                            onClick = { showListingDropdown = true },
                            label = {
                                val currentListing = allListings.firstOrNull { it.id == selectedListingId }
                                Text(
                                    text = if (currentListing != null) "Listing: ${currentListing.title.take(15)}..." else "Filter Listing"
                                )
                            },
                            trailingIcon = {
                                if (selectedListingId != null) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear Listing Filter",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable { viewModel.setListingFilter(null) }
                                    )
                                }
                            }
                        )

                        DropdownMenu(
                            expanded = showListingDropdown,
                            onDismissRequest = { showListingDropdown = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Listings") },
                                onClick = {
                                    viewModel.setListingFilter(null)
                                    showListingDropdown = false
                                }
                            )
                            allListings.forEach { listing ->
                                DropdownMenuItem(
                                    text = { Text(listing.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    onClick = {
                                        viewModel.setListingFilter(listing.id)
                                        showListingDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Conversation List
            if (conversations.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No conversations found",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Try adjusting your search or active filters.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(conversations, key = { it.conversation.id }) { item ->
                        InboxConversationItem(
                            item = item,
                            onClick = {
                                onNavigateToChat(item.conversation.id)
                            },
                            onMarkAsRead = {
                                viewModel.selectConversation(item.conversation.id)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InboxConversationItem(
    item: ConversationWithDetails,
    onClick: () -> Unit,
    onMarkAsRead: () -> Unit
) {
    val unread = item.conversation.unreadCount > 0
    val timeFormatted = remember(item.conversation.lastMessageAt) {
        val diff = System.currentTimeMillis() - item.conversation.lastMessageAt
        when {
            diff < 60 * 1000 -> "Just now"
            diff < 60 * 60 * 1000 -> "${diff / (60 * 1000)}m ago"
            diff < 24 * 60 * 60 * 1000 -> "${diff / (60 * 60 * 1000)}h ago"
            else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(item.conversation.lastMessageAt))
        }
    }

    val profileStatusColor = when (item.profile.status) {
        ProfileStatus.ONLINE -> StatusOnlineGreen
        ProfileStatus.BUSY -> StatusBusyYellow
        ProfileStatus.OFFLINE -> StatusOfflineRed
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (unread) {
                MaterialTheme.colorScheme.surface
            } else {
                MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (unread) 2.dp else 0.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("inbox_item_${item.conversation.id}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            // Customer Avatar with Profile Status Dot
            UserAvatar(
                initials = item.customer.avatarInitials,
                backgroundColor = Color(android.graphics.Color.parseColor(item.customer.avatarColorHex)),
                size = 48.dp,
                status = item.profile.status
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Body
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = item.customer.name,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = if (unread) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = timeFormatted,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (unread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                // Related Listing & Profile metadata pills
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Text(
                            text = "🏷️ ${item.listing.title} • $${String.format(Locale.US, "%.0f", item.listing.price)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Chrome Profile badge
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = profileStatusColor.copy(alpha = 0.15f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(profileStatusColor)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = item.profile.id,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = profileStatusColor
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Last Message Preview
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = item.conversation.lastMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (unread) FontWeight.Medium else FontWeight.Normal,
                        color = if (unread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (unread) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Badge(containerColor = FbBlue) {
                            Text("${item.conversation.unreadCount}")
                        }
                    }
                }
            }
        }
    }
}
