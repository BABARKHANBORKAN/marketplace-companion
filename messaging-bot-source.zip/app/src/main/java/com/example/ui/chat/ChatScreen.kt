package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Message
import com.example.data.model.MessageSender
import com.example.data.model.ProfileStatus
import com.example.ui.components.MessageStatusIndicator
import com.example.ui.components.ProfileStatusChip
import com.example.ui.components.ProfileStatusDot
import com.example.ui.components.UserAvatar
import com.example.ui.theme.FbBlue
import com.example.ui.theme.StatusBusyYellow
import com.example.ui.theme.StatusOfflineRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.viewmodel.MarketplaceViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    conversationId: String,
    viewModel: MarketplaceViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToProfileDetails: (String) -> Unit,
    onNavigateToListingDetails: (String) -> Unit
) {
    LaunchedEffect(conversationId) {
        viewModel.selectConversation(conversationId)
    }

    val conversations by viewModel.allConversations.collectAsState()
    val convDetails = conversations.firstOrNull { it.conversation.id == conversationId }
    val messages by viewModel.activeChatMessages.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var showBusyDialog by remember { mutableStateOf(false) }
    var showOfflineDialog by remember { mutableStateOf(false) }
    var pendingSendText by remember { mutableStateOf("") }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val profile = convDetails?.profile
    val customer = convDetails?.customer
    val listing = convDetails?.listing

    // Dialog for Busy Profile (Req #13 & #32)
    if (showBusyDialog && profile != null) {
        AlertDialog(
            onDismissRequest = { showBusyDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = StatusBusyYellow,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(text = "Profile is Currently Busy", fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "${profile.id} (${profile.name}) is currently busy executing:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusBusyYellow.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Currently: ${profile.currentTask}",
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFB45309),
                            modifier = Modifier.padding(10.dp),
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "To send this reply now, the Desktop Bot will pause/stop the active task and focus on Messenger.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBusyDialog = false
                        viewModel.sendMessage(
                            conversationId = conversationId,
                            text = pendingSendText,
                            stopTaskFirst = true
                        )
                        inputText = ""
                        pendingSendText = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusBusyYellow),
                    modifier = Modifier.testTag("stop_task_and_send_button")
                ) {
                    Text("Stop Task & Send", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBusyDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog for Offline Profile (Req #11 & #32)
    if (showOfflineDialog && profile != null) {
        AlertDialog(
            onDismissRequest = { showOfflineDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    tint = StatusOfflineRed,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(text = "Chrome Profile is Offline", fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "${profile.id} is currently closed on the desktop computer.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Would you like to send a REOPEN_CHROME_PROFILE command to the Desktop Bot now, or queue this message for when it reconnects?",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showOfflineDialog = false
                        viewModel.sendMessage(
                            conversationId = conversationId,
                            text = pendingSendText,
                            reopenChromeFirst = true
                        )
                        inputText = ""
                        pendingSendText = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FbBlue),
                    modifier = Modifier.testTag("reopen_chrome_and_send_button")
                ) {
                    Text("Reopen Chrome & Send")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showOfflineDialog = false
                        viewModel.sendMessage(
                            conversationId = conversationId,
                            text = pendingSendText,
                            reopenChromeFirst = false
                        )
                        inputText = ""
                        pendingSendText = ""
                    }
                ) {
                    Text("Queue Only")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    if (customer != null && profile != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            UserAvatar(
                                initials = customer.avatarInitials,
                                backgroundColor = Color(android.graphics.Color.parseColor(customer.avatarColorHex)),
                                size = 38.dp,
                                status = profile.status
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = customer.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    ProfileStatusDot(profile.status, size = 8.dp)
                                }
                                Text(
                                    text = "${profile.id} • ${if (profile.status == ProfileStatus.BUSY) profile.currentTask else profile.status.name.lowercase().replaceFirstChar { it.uppercase() }}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = when (profile.status) {
                                        ProfileStatus.ONLINE -> StatusOnlineGreen
                                        ProfileStatus.BUSY -> StatusBusyYellow
                                        ProfileStatus.OFFLINE -> StatusOfflineRed
                                    },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Chat Options")
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Open Customer Chat in Chrome") },
                            leadingIcon = { Icon(Icons.Default.DesktopWindows, contentDescription = null) },
                            onClick = {
                                if (profile != null) {
                                    viewModel.openCustomerChatInChrome(profile.id, conversationId)
                                }
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Reopen Chrome Profile") },
                            leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) },
                            onClick = {
                                if (profile != null) {
                                    viewModel.reopenChromeProfile(profile.id)
                                }
                                showMenu = false
                            }
                        )
                        if (profile?.status == ProfileStatus.BUSY) {
                            DropdownMenuItem(
                                text = { Text("Stop Current Task") },
                                leadingIcon = { Icon(Icons.Default.StopCircle, contentDescription = null) },
                                onClick = {
                                    viewModel.stopCurrentTask(profile.id)
                                    showMenu = false
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Profile Details") },
                            leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                            onClick = {
                                if (profile != null) {
                                    onNavigateToProfileDetails(profile.id)
                                }
                                showMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Listing Details") },
                            leadingIcon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
                            onClick = {
                                if (listing != null) {
                                    onNavigateToListingDetails(listing.id)
                                }
                                showMenu = false
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .testTag("chat_screen")
        ) {
            // Product context banner at the top of chat
            if (listing != null && profile != null) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToListingDetails(listing.id) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = listing.title,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "$${String.format(Locale.US, "%.0f", listing.price)} • Profile: ${profile.id} (${profile.accountLabel})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.clickable {
                                viewModel.openCustomerChatInChrome(profile.id, conversationId)
                            }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInBrowser,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Desktop",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Message stream
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatMessageBubble(message = message)
                }
            }

            // Quick reply suggestion chips
            val quickReplies = listOf(
                "Is this available?",
                "Yes, it is still available!",
                "What is your best offer?",
                "Can meet at public location today",
                "Clean title and works perfectly"
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quickReplies) { reply ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.clickable {
                            inputText = reply
                        }
                    ) {
                        Text(
                            text = reply,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Composer bar
            Surface(
                tonalElevation = 3.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Reply on Facebook Messenger...") },
                        maxLines = 4,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            val textToSend = inputText.trim()
                            if (textToSend.isEmpty()) return@IconButton

                            pendingSendText = textToSend

                            when (profile?.status) {
                                ProfileStatus.BUSY -> {
                                    showBusyDialog = true
                                }
                                ProfileStatus.OFFLINE -> {
                                    showOfflineDialog = true
                                }
                                else -> {
                                    viewModel.sendMessage(
                                        conversationId = conversationId,
                                        text = textToSend
                                    )
                                    inputText = ""
                                }
                            }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(if (inputText.isNotBlank()) FbBlue else MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("send_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (inputText.isNotBlank()) Color.White else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageBubble(message: Message) {
    val isFromMe = message.sender == MessageSender.USER_APP
    val isAutoReply = message.sender == MessageSender.BOT_AUTO
    val timeFormatted = remember(message.timestamp) {
        SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(message.timestamp))
    }

    val bubbleColor = when {
        isFromMe -> FbBlue
        isAutoReply -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    val textColor = when {
        isFromMe -> Color.White
        isAutoReply -> MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Column(
        horizontalAlignment = if (isFromMe) Alignment.End else Alignment.Start,
        modifier = Modifier.fillMaxWidth()
    ) {
        if (isAutoReply) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = "Auto Reply",
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Desktop Bot Auto-Reply",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.tertiary
                )
            }
        }

        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isFromMe) 16.dp else 4.dp,
                        bottomEnd = if (isFromMe) 4.dp else 16.dp
                    )
                )
                .background(bubbleColor)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = message.text,
                color = textColor,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(3.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (isFromMe) Arrangement.End else Arrangement.Start,
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            Text(
                text = timeFormatted,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )

            if (isFromMe) {
                Spacer(modifier = Modifier.width(4.dp))
                MessageStatusIndicator(status = message.status)
            }
        }
    }
}
