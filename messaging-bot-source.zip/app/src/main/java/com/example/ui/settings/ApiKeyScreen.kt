package com.example.ui.settings

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BotConnection
import com.example.ui.theme.FbBlue
import com.example.ui.theme.StatusOfflineRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.ui.viewmodel.MarketplaceViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeyScreen(
    viewModel: MarketplaceViewModel,
    targetProfileId: String? = null,
    onNavigateBack: () -> Unit
) {
    val allApiKeys by viewModel.allApiKeys.collectAsState()
    val profiles by viewModel.allProfiles.collectAsState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Arriving from a specific profile (its "Generate Bot API Key" / "Manage Keys" button) scopes
    // this screen to that profile's own key only — never the account-wide list, which is what
    // made every profile look like it shared all keys. The unscoped, all-profiles list is still
    // available via Settings/Dashboard's generic "Manage Keys" entry (no targetProfileId).
    val apiKeys = if (targetProfileId != null) {
        allApiKeys.filter { it.profileId == targetProfileId }
    } else {
        allApiKeys
    }

    // Arrived via a specific profile's "Generate Bot API Key" button — open the dialog
    // pre-targeted at that profile instead of silently defaulting to whichever profile happens
    // to sort first, which previously caused keys to get generated for the wrong profile.
    var showCreateDialog by remember { mutableStateOf(targetProfileId != null) }
    var newlyGeneratedSecret by remember { mutableStateOf<String?>(null) }
    var isGenerating by remember { mutableStateOf(false) }
    var generationErrorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Text(
                        text = if (targetProfileId != null) "This Profile's Bot Key" else "Desktop Bot API Keys",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    generationErrorMessage = null
                    showCreateDialog = true
                },
                containerColor = FbBlue,
                contentColor = Color.White,
                modifier = Modifier.testTag("generate_key_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Generate New API Key")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(
                top = innerPadding.calculateTopPadding() + 16.dp,
                bottom = innerPadding.calculateBottomPadding() + 80.dp,
                start = 16.dp,
                end = 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("api_key_screen")
        ) {
            // Security Architecture Notice
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Zero Plaintext Key Storage",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Full API secret tokens are displayed exactly once at creation and cached in Android Keystore during active session. The local database stores only SHA-256 validation hashes and masked prefixes.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Quick Setup Guide Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Desktop Bot CLI Pairing",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "1. Generate a secure bot key below.\n2. Copy the token immediately.\n3. Run: npx marketplace-bot --api-key <YOUR_KEY>\n4. Bot will begin reporting live heartbeats every 30s.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Arriving via a profile's "Generate Bot API Key" button opens the create dialog
            // immediately, but the dialog's own Android window can take a moment to attach —
            // showing the (unrelated, pre-existing) key list underneath during that gap reads as
            // "a key already exists" even though nothing has been generated yet. Hide the list
            // until that pending dialog is resolved (generated or cancelled) to avoid the flash.
            val suppressListForPendingTargetedGenerate = targetProfileId != null && showCreateDialog
            if (!suppressListForPendingTargetedGenerate) {
                // Keys list header
                item {
                    Text(
                        text = if (targetProfileId != null) "Assigned Key" else "Configured Bot Keys (${apiKeys.size})",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                items(apiKeys, key = { it.id }) { botKey ->
                    ApiKeyCard(
                        botKey = botKey,
                        onCopy = {
                            val fullKey = viewModel.getFullApiKey(botKey.id)
                            if (fullKey != null) {
                                clipboardManager.setText(AnnotatedString(fullKey))
                                Toast.makeText(context, "API key copied to clipboard", Toast.LENGTH_SHORT).show()
                            } else {
                                clipboardManager.setText(AnnotatedString(botKey.maskedKey))
                                Toast.makeText(context, "Full secret unavailable on this device — masked key copied. Revoke and generate a new key to get a copyable secret.", Toast.LENGTH_LONG).show()
                            }
                        },
                        onRevoke = { viewModel.revokeApiKey(botKey.id) },
                        onDelete = { viewModel.deleteApiKey(botKey.id) }
                    )
                }
            }
        }
    }

    // Modal: Generate New Key Dialog
    if (showCreateDialog) {
        var selectedProfileId by remember { mutableStateOf(targetProfileId ?: profiles.firstOrNull()?.id ?: "profile_01") }
        var serverUrl by remember { mutableStateOf("http://13.60.48.34:8080/") }
        var showProfileDropdown by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isGenerating) showCreateDialog = false },
            title = { Text("Generate Desktop Bot Key") },
            text = {
                Column {
                    Text(
                        text = "Assign which Chrome Profile this Bot daemon pairs with.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (generationErrorMessage != null) {
                        Text(
                            text = generationErrorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    Box {
                        TextButton(onClick = { showProfileDropdown = true }) {
                            Text("Assigned Profile: $selectedProfileId")
                        }
                        DropdownMenu(
                            expanded = showProfileDropdown,
                            onDismissRequest = { showProfileDropdown = false }
                        ) {
                            profiles.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text("${p.id} (${p.name})") },
                                    onClick = {
                                        selectedProfileId = p.id
                                        showProfileDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = { serverUrl = it },
                        label = { Text("Server URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isGenerating = true
                        generationErrorMessage = null
                        viewModel.generateApiKey(selectedProfileId, serverUrl) { success, message, secret ->
                            isGenerating = false
                            if (success && secret != null) {
                                showCreateDialog = false
                                newlyGeneratedSecret = secret
                            } else {
                                generationErrorMessage = message
                            }
                        }
                    },
                    enabled = !isGenerating,
                    colors = ButtonDefaults.buttonColors(containerColor = FbBlue)
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                    } else {
                        Text("Generate Key")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCreateDialog = false },
                    enabled = !isGenerating
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Modal: One-Time Key Secret Display
    newlyGeneratedSecret?.let { secret ->
        AlertDialog(
            onDismissRequest = { newlyGeneratedSecret = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = FbBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Copy Your Secret Key")
                }
            },
            text = {
                Column {
                    Text(
                        text = "Make sure to copy your API key now. For your security, this complete secret will not be displayed again.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = secret,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(secret))
                                    Toast.makeText(context, "API Key copied to clipboard", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy Key", tint = FbBlue)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(secret))
                        Toast.makeText(context, "API Key copied! Store it securely.", Toast.LENGTH_SHORT).show()
                        newlyGeneratedSecret = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FbBlue)
                ) {
                    Text("Done & Copied")
                }
            }
        )
    }
}

@Composable
fun ApiKeyCard(
    botKey: BotConnection,
    onCopy: () -> Unit,
    onRevoke: () -> Unit,
    onDelete: () -> Unit
) {
    val isActive = botKey.status == "ACTIVE"

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("api_key_card_${botKey.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isActive) StatusOnlineGreen else StatusOfflineRed)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = botKey.profileId,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isActive) StatusOnlineGreen.copy(alpha = 0.12f) else StatusOfflineRed.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = botKey.status,
                        color = if (isActive) StatusOnlineGreen else StatusOfflineRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Masked Key container
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = botKey.maskedKey,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Masked API Key",
                            tint = FbBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Server URL & Version
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Endpoint: ${botKey.serverUrl}",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = botKey.botVersion,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Last Heartbeat
            val heartbeatText = if (botKey.lastHeartbeat > 0) {
                val fmt = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault())
                "Heartbeat: ${fmt.format(Date(botKey.lastHeartbeat))}"
            } else {
                "No heartbeat recorded yet"
            }

            Text(
                text = heartbeatText,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Actions: Revoke & Delete
            Row(
                horizontalArrangement = Arrangement.End,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isActive) {
                    TextButton(onClick = onRevoke) {
                        Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Revoke", color = StatusOfflineRed, fontSize = 12.sp)
                    }
                }

                TextButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
            }
        }
    }
}
