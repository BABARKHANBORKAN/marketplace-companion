package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.bot.CommandStateMachine
import com.example.data.bot.DispatchResult
import com.example.data.bot.RealBotCommandDispatcher
import com.example.data.local.AppDatabase
import com.example.data.model.ChromeProfile
import com.example.data.model.CommandStatus
import com.example.data.model.Conversation
import com.example.data.model.Customer
import com.example.data.model.Listing
import com.example.data.model.MessageStatus
import com.example.data.model.ProfileStatus
import com.example.data.network.ApiClientProvider
import com.example.data.network.InboundEventDto
import com.example.data.preferences.UserSessionManager
import com.example.data.security.SecureCredentialStore
import com.example.data.sync.SyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var sessionManager: UserSessionManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext<Context>()
        database = AppDatabase.getDatabase(context)
        sessionManager = UserSessionManager(context)
    }

    @Test
    fun `read string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Marketplace Companion", appName)
    }

    @Test
    fun `insert and retrieve chrome profile with user isolation`() = runBlocking {
        val testProfile = ChromeProfile(
            id = "Test_Profile_99",
            userId = "user_test_42",
            name = "Test Browser Profile",
            accountLabel = "Test Account",
            status = ProfileStatus.ONLINE,
            currentTask = "Testing",
            chromeWindowName = "Chrome Test Window"
        )
        database.chromeProfileDao().insertProfile(testProfile)
        val loaded = database.chromeProfileDao().getProfileById("Test_Profile_99").first()
        assertNotNull(loaded)
        assertEquals(ProfileStatus.ONLINE, loaded?.status)
        assertEquals("user_test_42", loaded?.userId)

        val userProfiles = database.chromeProfileDao().getProfilesByUser("user_test_42").first()
        assertEquals(1, userProfiles.size)
        assertEquals("Test_Profile_99", userProfiles[0].id)

        val otherUserProfiles = database.chromeProfileDao().getProfilesByUser("user_other").first()
        assertTrue(otherUserProfiles.isEmpty())
    }

    @Test
    fun `session manager persists authentication tokens and server url`() = runBlocking {
        sessionManager.saveAuthToken(
            token = "jwt_test_token_abc",
            refreshToken = "refresh_xyz",
            userId = "user_42",
            email = "tester@marketpro.com",
            name = "Test User"
        )
        val session = sessionManager.sessionFlow.first()
        assertEquals("jwt_test_token_abc", session.token)
        assertEquals("tester@marketpro.com", session.email)
        assertEquals("user_42", session.userId)
        assertTrue(session.isAuthenticated)

        sessionManager.updateServerUrl("https://custom-backend.domain.com/")
        val updatedSession = sessionManager.sessionFlow.first()
        assertEquals("https://custom-backend.domain.com/", updatedSession.serverUrl)
    }

    @Test
    fun `real bot command dispatcher queues commands offline when backend is unreachable`() = runBlocking {
        val dummyApi = ApiClientProvider.createService("http://127.0.0.1:9999/", tokenProvider = { null })
        val dispatcher = RealBotCommandDispatcher(database) { dummyApi }

        val cmdId = "cmd_offline_" + UUID.randomUUID().toString().take(6)
        val result = dispatcher.reopenChromeProfile("Profile 01", cmdId)

        // Since 127.0.0.1:9999 is offline in test, it must queue cleanly
        assertTrue(result is DispatchResult.Queued)
    }

    // --- State Machine Tests ---
    @Test
    fun `command state machine allows valid transitions and rejects invalid ones`() {
        // Valid forward transitions
        assertTrue(CommandStateMachine.isValidTransition(CommandStatus.PENDING, CommandStatus.PROCESSING))
        assertTrue(CommandStateMachine.isValidTransition(CommandStatus.PENDING, CommandStatus.CANCELLED))
        assertTrue(CommandStateMachine.isValidTransition(CommandStatus.PROCESSING, CommandStatus.COMPLETED))
        assertTrue(CommandStateMachine.isValidTransition(CommandStatus.PROCESSING, CommandStatus.FAILED))
        assertTrue(CommandStateMachine.isValidTransition(CommandStatus.FAILED, CommandStatus.PENDING))

        // Invalid transitions
        assertFalse(CommandStateMachine.isValidTransition(CommandStatus.PENDING, CommandStatus.COMPLETED))
        assertFalse(CommandStateMachine.isValidTransition(CommandStatus.COMPLETED, CommandStatus.PENDING))
        assertFalse(CommandStateMachine.isValidTransition(CommandStatus.CANCELLED, CommandStatus.PROCESSING))

        // Assert throws on invalid transition
        assertThrows(IllegalStateException::class.java) {
            CommandStateMachine.assertValidTransition("cmd_err_1", CommandStatus.PENDING, CommandStatus.COMPLETED)
        }
    }

    @Test
    fun `message state machine enforces delivery lifecycle`() {
        // PENDING -> PROCESSING -> SENT
        assertTrue(CommandStateMachine.isValidMessageTransition(MessageStatus.PENDING, MessageStatus.PROCESSING))
        assertTrue(CommandStateMachine.isValidMessageTransition(MessageStatus.PROCESSING, MessageStatus.SENT))
        assertTrue(CommandStateMachine.isValidMessageTransition(MessageStatus.PROCESSING, MessageStatus.FAILED))
        assertTrue(CommandStateMachine.isValidMessageTransition(MessageStatus.FAILED, MessageStatus.PENDING))

        // Cannot skip directly from PENDING to SENT without bot processing
        assertFalse(CommandStateMachine.isValidMessageTransition(MessageStatus.PENDING, MessageStatus.SENT))
        // Terminal state cannot transition
        assertFalse(CommandStateMachine.isValidMessageTransition(MessageStatus.SENT, MessageStatus.PENDING))

        assertThrows(IllegalStateException::class.java) {
            CommandStateMachine.assertValidMessageTransition("msg_err_1", MessageStatus.PENDING, MessageStatus.SENT)
        }
    }

    // --- Security & Masking Tests ---
    @Test
    fun `secure credential store masks api keys safely`() {
        val rawKey = "mpc_live_9876543210abcdef12345678"
        val masked = SecureCredentialStore.maskApiKey(rawKey)

        assertTrue(masked.startsWith("mpc_live_"))
        assertTrue(masked.endsWith("5678"))
        assertTrue(masked.contains("••••"))
        assertFalse(masked.contains("9876543210"))
    }

    // --- SyncManager Deduplication Tests ---
    @Test
    fun `sync manager deduplicates inbound events idempotently`() = runBlocking {
        val dummyApi = ApiClientProvider.createService("http://127.0.0.1:9999/", tokenProvider = { null })
        val dispatcher = RealBotCommandDispatcher(database) { dummyApi }
        val syncManager = SyncManager(
            database = database,
            sessionManager = sessionManager,
            apiServiceProvider = { dummyApi },
            realDispatcher = dispatcher,
            scope = CoroutineScope(Dispatchers.Unconfined)
        )

        // Ensure authenticated user session so SyncManager attributes data correctly
        sessionManager.saveAuthToken(
            token = "jwt_sync_token",
            refreshToken = null,
            userId = "user_sync_test",
            email = "sync@example.com",
            name = "Sync User"
        )

        // Seed customer, profile, and listing required for foreign keys
        val profile = ChromeProfile(
            id = "prof_sync_test",
            userId = "user_sync_test",
            name = "Profile Sync",
            accountLabel = "Acc 1",
            status = ProfileStatus.ONLINE,
            currentTask = "Idle"
        )
        database.chromeProfileDao().insertProfile(profile)
        val customer = Customer(
            id = "cust_sync_test",
            userId = "user_sync_test",
            name = "Alice Buyer",
            externalCustomerId = "ext_123"
        )
        database.customerDao().insertCustomer(customer)
        val listing = Listing(
            id = "list_sync_test",
            userId = "user_sync_test",
            profileId = "prof_sync_test",
            title = "Vintage Camera",
            price = 150.0
        )
        database.listingDao().insertListing(listing)
        val conv = Conversation(
            id = "conv_sync_test",
            userId = "user_sync_test",
            profileId = "prof_sync_test",
            customerId = "cust_sync_test",
            listingId = "list_sync_test",
            unreadCount = 0,
            lastMessage = "Hello",
            lastMessageAt = System.currentTimeMillis()
        )
        database.conversationDao().insertConversation(conv)

        val event = InboundEventDto(
            eventId = "evt_dedup_unique_123",
            eventType = "NEW_MESSAGE",
            timestamp = System.currentTimeMillis(),
            payload = """{"id":"msg_inbound_abc_1","conversationId":"conv_sync_test","text":"Is this camera still available?","sender":"CUSTOMER"}"""
        )

        // First ingestion must succeed
        syncManager.processInboundEvent(event)
        val messagesFirst = database.messageDao().getMessagesForConversation("conv_sync_test").first()
        assertEquals(1, messagesFirst.size)
        assertEquals("Is this camera still available?", messagesFirst[0].text)

        // Second ingestion of identical event ID must be deduplicated and ignored
        syncManager.processInboundEvent(event)
        val messagesSecond = database.messageDao().getMessagesForConversation("conv_sync_test").first()
        assertEquals(1, messagesSecond.size)
    }

    // --- WebSocketManager Unit Tests ---
    @Test
    fun `websocket manager computes correct wss and ws urls without query token leakage`() {
        val wsManager = com.example.data.network.WebSocketManager(
            serverUrlProvider = { "https://api.marketplace.example.com/" },
            tokenProvider = { "test_token_123" },
            onEventReceived = {}
        )

        val httpsUrl = wsManager.getWebSocketUrl("https://api.marketplace.example.com/")
        assertEquals("wss://api.marketplace.example.com/api/v1/events", httpsUrl)

        val httpUrl = wsManager.getWebSocketUrl("http://192.168.1.50:8080/")
        assertEquals("ws://192.168.1.50:8080/api/v1/events", httpUrl)

        assertEquals(com.example.data.network.WebSocketState.DISCONNECTED, wsManager.connectionState.value)
    }

    @Test
    fun `auth response and delta sync models deserialize both standard and legacy formats`() {
        val moshi = ApiClientProvider.moshi
        val authAdapter = moshi.adapter(com.example.data.network.AuthResponse::class.java)

        // RFC Standard camelCase JSON
        val standardJson = """
            {
                "accessToken": "standard_jwt_token",
                "refreshToken": "standard_refresh_token",
                "expiresIn": 3600,
                "user": {
                    "id": "u_standard_1",
                    "name": "Standard User",
                    "email": "user@example.com",
                    "plan": "Enterprise"
                }
            }
        """.trimIndent()
        val standardAuth = authAdapter.fromJson(standardJson)
        assertNotNull(standardAuth)
        assertEquals("standard_jwt_token", standardAuth?.token)
        assertEquals("standard_refresh_token", standardAuth?.effectiveRefreshToken)
        assertEquals(3600L, standardAuth?.expiresIn)

        // Inbound event envelope test
        val eventAdapter = moshi.adapter(com.example.data.network.InboundEventDto::class.java)
        val eventJson = """
            {
                "eventId": "evt_9988",
                "eventType": "NEW_MESSAGE",
                "payload": "{\"test\":true}",
                "timestamp": 1700000000000
            }
        """.trimIndent()
        val parsedEvent = eventAdapter.fromJson(eventJson)
        assertNotNull(parsedEvent)
        assertEquals("evt_9988", parsedEvent?.id)
        assertEquals("NEW_MESSAGE", parsedEvent?.type)
    }
}
